import sys
import datetime
import time
from collections import OrderedDict
from pyspark.sql import Row
from pyspark.sql.types import *
from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext
from pyspark.sql import HiveContext
from pyspark.sql.functions import *

print("Starting spark")
sconf = SparkConf().setAppName("CDN Billing Usage").setMaster("yarn-cluster")
sconf.set("spark.shuffle.service.enabled", "true")
sconf.set("spark.dynamicAllocation.enabled", "true")
sconf.set("spark.dynamicAllocation.minExecutors", "35")
sconf.set("spark.dynamicAllocation.maxExecutors", "200")
sconf.set("spark.dynamicAllocation.initialExecutors", "10")
sconf.set("spark.yarn.maxAppAttempts", "1")
sconf.set("spark.yarn.executor.memoryOverhead", "500")
sc = SparkContext.getOrCreate(conf=sconf)
sqlContext = HiveContext(sc)

# Get the date value
curr_hr = datetime.datetime.now().strftime ("%Y%m%d%H")
get_date = sqlContext.sql("select date_format(date_add(current_date, -2),'yyyyMMdd') as get_date").collect()[0][0]
print(get_date)

# Run Query and create CSV file
all_start_time = time.time()
myStart = time.time()
cdn_billing_data = sqlContext.sql("select coserver_id, cast(round((distr_id/100),0)as INT) as distr_id,scheme, sum(sum_bytes) as bytes_summary ,sum(counter) as counter_summary from  asl_cdn.five_min_aggregated_cdn_logs where dt_hr like '{}%' group by  coserver_id,round((distr_id/100),0),scheme".format(get_date))
cdn_billing_data.coalesce(1).write.format('csv').mode('overwrite').save("hdfs://nameservice1/data/CTL/encrypt/data/asl_cdn/", header='true')

#Calculate End Time
End_time = ("Query_Run_Time : " + time.strftime("%H:%M:%S", time.gmtime(time.time()-myStart)))
print("Query Completed")
print (End_time)
schema = StructType([StructField('Query_Run_Time', StringType())])
rows = [Row(Query_Run_Time = End_time)]
Elapsed_time = sqlContext.createDataFrame(rows, schema)
Elapsed_time.coalesce(1).write.format('text').mode('append').save("hdfs://nameservice1/data/CTL/encrypt/data/asl_cdn/",header='true')
print("Complete")
