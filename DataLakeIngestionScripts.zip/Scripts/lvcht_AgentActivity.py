#!/opt/tools/python/bin python

import avro.schema
from avro.datafile import DataFileReader, DataFileWriter
from avro.io import DatumReader, DatumWriter
import json
import sys
import logging
from argparse import ArgumentParser
from datetime import datetime
import os


def main(argv=None):
        #Get script name
        script_name = "lvchtAgentActivity.py"

        #Logging
        log_dir = '/data/CTL/ingest/lvcht/log/'
        timestamp = datetime.utcnow().strftime('%Y.%m.%d.%H.%M.%S')
        log_name = script_name+'_{}.log'.format(timestamp)
        log_file = os.path.join(log_dir, log_name)
        logging.basicConfig(filename=log_file,level=logging.DEBUG)

        #Path and files
        stage_avro_dir = '/data/CTL/ingest/lvcht/staging/avro/AgentActivity'
        stage_csv_dir = '/data/CTL/ingest/lvcht/staging/CSV/AgentActivity_src'

        #Clear the CSV Dir
        os.system('rm -rf %s/*' % '/data/CTL/ingest/lvcht/staging/CSV/AgentActivity_src')

        for infile_name in os.listdir(stage_avro_dir):
        # Parse Arguments
                input_file = os.path.join(stage_avro_dir,infile_name)
                logging.info("Avro file being processed: "+input_file)

                #create output file to write the csv data
                filepart = infile_name[-13:-5]
                outfile_name = "AgentActivity_"+filepart+".csv"
                output_file =  os.path.join(stage_csv_dir,outfile_name)
                logging.info("csv out file: "+output_file)
                outFile = open(output_file,"w")

                #load the schema and write out the csv text file
                schema = avro.schema.Parse(open("/data/CTL/ingest/lvcht/schema/livePerson.avsc").read())
                reader = DataFileReader(open(input_file, "rb"), DatumReader())
                for items in reader:
                        x = 0
                        while x < len(items['recordCollection'][0]['body']['agentSessionsData']):
                                dataType = json.dumps(items['dataType'])
                                header =  json.dumps(list(items['recordCollection'][0]['body']['header'].values()), ensure_ascii=False)
                                body = json.dumps(list(items['recordCollection'][0]['body']['agentSessionsData'][x].values()), ensure_ascii=False)
                                metaData = json.dumps(list(items['metaData'].values()), ensure_ascii=False)
                                x = x+1
                                outFile.write(dataType+', '+header.strip("[]")+', '+body.strip("[]")+', '+metaData.strip("[]")+', '+filepart+'\n')
        logging.info("Script Complete.")

def parse_args(argv):
        """
        Parse command line options.
        """
        if argv is None:  # No arguments supplied. Likely called from terminal.
                argv = sys.argv
        parser = ArgumentParser(prog=argv[0], description='Process the live chat tag file for the table')
        parser.add_argument(
                'file_name',
                help='The file_name to process.'
        )
        args = vars(parser.parse_args(args=argv[1:]))
        file_name= args['file_name']
        return (file_name)

def create_output_file(output_dir, file_name):
        """
        Create the output file and directory.
        """
        # Create the directory if it does not exist
        if not os.path.exists(output_dir):
                os.makedirs(output_dir)

        # Make sure the directory is really a directory
        if not os.path.isdir(output_dir):
                print('ERROR: {} is not a directory.'.format(output_dir))
                sys.exit(2)

        # We want to generate a timestamp in the file name so multiple runs don't overwrite each other.
        timestamp = datetime.utcnow().strftime('%Y.%m.%d.%H.%M.%S')
        file_name = file_name+'_{}.csv'.format(timestamp)
        output_file = os.path.join(output_dir, file_name)

# Actually run the script if calling from the command line
if __name__ == '__main__':
        sys.exit(main())
