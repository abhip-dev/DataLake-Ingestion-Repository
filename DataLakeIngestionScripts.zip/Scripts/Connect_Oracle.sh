#!/bin/bash
username="cdlora"
password="Ctlap2019q4"
db_ip="podclodm-scan"
port="1521"
sid="DWBS01DU1"
schema="servenow"


echo "

var=select * from $schema.cmdb_ci_service ;
echo $var;
exit
" | sqlplus -s "$username/$password@$db_ip:$port/$sid"
