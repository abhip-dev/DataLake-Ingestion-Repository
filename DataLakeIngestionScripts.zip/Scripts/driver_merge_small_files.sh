#!/bin/bash
#*****************************************************************************************************************************
# Program Name           : driver_merge_small_files
# Shell Objective        : This script is to invoke merge_small_files.py in background. It runs n parallel processes at a time.
#			   This script takes a param file and n (number of processes to execute in parallel) as argument.
# OR we can pass 2 arguments (param file, number of parallel processes)
# Example 1:  ./merge_small_files.sh table_metadata.parm 10
# Argument 1: Connection parameter file (please place the file  /home/$APPID/masterIngestion/connections/)
# Argument 2: Number of processes to execute in parallel
# --------------------------------------------------------------------
# 05/24/2017 Navneet Kaur Initial Draft
# --------------------------------------------------------------------
#*****************************************************************************************************************************

# Reading table metadata from parameter file.
table_metadata_parmfile=$1
parallel_Count=$2
echo "parallel count :"$parallel_Count

#Temporary log file
tempLog=/tmp/driver_merge_small_files_$(date -d "today" +"%Y%m%d%H%M").log
touch $tempLog
echo "temporary log file at : $tempLog"

# Check if the No. of required arguments have been provided.
if [ "$#" -ne 2 ]
then
	echo "Input is missing" >> $tempLog 2>&1
	exit 1
fi


# Check if the required table metadata (param file) has been provided.
if [ -f "$table_metadata_parmfile" ]
then
	echo "Found the table metadata param file"
        echo "Found the table metadata param file" >> $tempLog 2>&1
else
	echo "Missing table metadata param file"
        echo "Missing table metadata param file" >> $tempLog 2>&1
        exit 1
fi

# Invoke merge_small_files.py script in background for merging files in n tables at a time
IFS=$'\n'
for record in `cat $table_metadata_parmfile`;
do
	db_name=$(echo $record | cut -d" " -f1)
        tbl_name=$(echo $record | cut -d" " -f2)
	db_dir=$(echo $record | cut -d" " -f3)
	part_columns=$(echo $record | cut -d" " -f4)
	bucket_columns=$(echo $record | cut -d" " -f5)
	num_buckets=$(echo $record | cut -d" " -f6)

        echo " $(date +"%r") : Initiating load for $tbl_name " # >> $tempLog 2>&1

        until [ `ps -ef | grep merge_small_files.py |wc -l` -lt $parallel_Count ]
        do
		echo "Sleeping for 20 sec" # >> $tempLog 2>&1
		sleep 20
        done
	echo " $(date +"%r") : Initiation started for $tbl_name "
        echo " $(date +"%r") : Initiation started for $tbl_name " >> $tempLog 2>&1
        #(spark2-submit /home/cdlapp/ac47816/merge_small_files.py $db_name $tbl_name $db_dir $part_columns $bucket_columns $num_buckets --master yarn --deploy-mode cluster) >> $tempLog 2>&1 &
                sleep 5
        done

