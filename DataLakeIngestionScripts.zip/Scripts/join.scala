package aaaacom.ctl

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.execution.datasources.SQLHadoopMapReduceCommitProtocol

object Process {

def main(args: Array[String]): Unit = {
val sparkSession = SparkSession.builder.master("yarn").appName("join").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()

import sparkSession.implicits._

val input = args(0)
val input_i =input.toInt

val v_path = "/data/CTL/encrypt/db/ingest/raw/asl_mes/tax_event_trans/rpt_dt=" + s"$input"
val tax_event = "/data/CTL/encrypt/db/ingest/raw/asl_mes/tax_event/rpt_dt=" + s"$input"

val large_Trans = sparkSession.sqlContext.read.format("parquet").option("header", "true").option("inferSchema", "true").load(v_path).repartition(20)

val R1 = large_Trans.rdd

val ref_DF_F = sparkSession.sqlContext.read.format("parquet").option("header", "true").option("inferSchema", "true").load(tax_event).groupBy($"file_name",$"file_record_id").agg(max("invoice_dt")).withColumnRenamed("file_name","fl_nm").withColumnRenamed("file_record_id","record_id").withColumnRenamed("max(invoice_dt)","meta_load_dt").cache


for (idx <- 0 to 19 ){
var mpdindx_x = R1.mapPartitionsWithIndex((index: Int, it: Iterator[org.apache.spark.sql.Row]) => if(index == idx) it else Iterator(), false)
var df_Trans_s = sparkSession.createDataFrame(mpdindx_x, large_Trans.schema).withColumn("rpt_dt", lit(input_i))
df_Trans_s.join(ref_DF_F, (df_Trans_s("file_name") === ref_DF_F("fl_nm")) && (df_Trans_s("file_record_id") === ref_DF_F("record_id")),"left_outer").drop($"fl_nm").drop($"record_id").write.partitionBy("rpt_dt").format("parquet").mode("append").saveAsTable("asl_mes.taxevent_meta_load_dt")
}

        sparkSession.stop()

        }

           }





build.sbt:

name := "Ingestion"

version := "0.1"

scalaVersion := "2.11.8"

libraryDependencies += "org.apache.spark" %% "spark-sql" % "2.1.0"

libraryDependencies += "org.apache.spark" %% "spark-core" % "2.1.0"



#! /bin/bash
home_dir=/home/cdlapp/test1
part_file=partition_file

cat ${home_dir}/$part_file | while read line
do

log_file=${home_dir}/log/test_ingestion_$line.log
spark2-submit --class aaaacom.ctl.Process --master yarn --deploy-mode cluster --executor-cores 5 --executor-memory 30g --num-executors 5 --driver-memory 10g --conf spark.yarn.executor.memoryOverhead=10g file:///home/cdlapp/test1/target/scala-2.11/ingestion_2.11-0.1.jar $line  >> ${log_file} 2>&1




RC=`egrep -i 'KILLED|ERROR' ${log_file} | wc -l`

if [ $RC -eq 0 ]
then
     echo `date` - "Script $0 Successfully completed LOOP $line." >> ${log_file}

     else
      echo `date` - "Script Killed or Error" >> ${log_file}
      exit 10
fi

done
exit 0

