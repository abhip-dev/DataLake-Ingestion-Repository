#!/usr/bin/env python

#########################################################################################################################################################
### pyspark script to merge multiple small files or split large files to approximately the size of avg hdfs block                                     ###
### size.                                                                                                                                             ###
### Author --> NAVNEET KAUR                                                                                                                           ###
### Input parameters --> This script takes five input params                                                                                          ###
### 1. HIVE_SCHEMA: This is the name of concerned database                                                                                            ###
### 2. HIVE_TABLE: This is the name of concerned table                                                                                                ###
### 3. DB_DIR: The location of concerned table on hdfs                                                                                                ###
### 4. PARTITION_COLS: Name of partition columns if concerned table has any( This parameter will be passed as NULL if no partitioning is there)       ###
### 5. BUCKET_COLS :Name of bucketing columns if concerned table has any( This parameter will be passed as NULL if no bucketing is there)             ###
### 6. NUM_BUCKETS : Number of buckets                                                                                                                ###
###                                                                                                                                                   ###
### Example 1(Table with no partition no bucketing): spark2-submit merge-small-files.py ilm document /data/CTL/encrypt/db/ingest/raw/ilm/document     ###
###           null null null                                                                                                                          ###
### Example 2(Table with just partition columns) : spark2-submit merge-small-files.py ilm document /data/CTL/encrypt/db/ingest/raw/ilm/document       ###
###           [part_col1,part_col2.... part_coln] null null                                                                                           ###
### Example 3(Table with partition and bucketing) :  spark2-submit merge-small-files.py ilm document /data/CTL/encrypt/db/ingest/raw/ilm/document     ###
###           [part_col1,part_col2,......partcoln] [bucket_col1,bucket_col2....bucket_coln] 256                                                       ###
#########################################################################################################################################################

from __future__ import division
from pyspark.sql import SparkSession
import sys
import pyspark
from pyspark.conf import SparkConf
from pyspark import SparkContext
from pyspark.sql.functions import *
from pyspark.sql import HiveContext
import datetime
import commands
import math
import subprocess

HIVE_SCHEMA=sys.argv[1]
HIVE_TABLE=sys.argv[2]
DB_DIR=sys.argv[3]
PARTITION_COLS=sys.argv[4].strip('[]')
BUCKET_COLS=sys.argv[5].strip('[]')
NUM_BUCKETS=sys.argv[6]
sconf = pyspark.SparkConf()

###############################################################################################################
### -*- setting required configs for hive, spark sql and yarn in sparkContext and initializing SparkSession -*-
###############################################################################################################

sconf.set("hive.metastore.uris", "thrift://poldcdhmn003.dev.intranet:9083")
sconf.set("spark.shuffle.service.enabled", "true")
sconf.set("yarn.nodemanager.pmem-check-enabled", "false")
sconf.set("yarn.nodemanager.vmem-check-enabled", "false")
sconf.set("spark.dynamicAllocation.enabled", "true")
sconf.set("spark.dynamicAllocation.minExecutors", "1")
sconf.set("spark.dynamicAllocation.maxExecutors", "500")
sconf.set("spark.dynamicAllocation.initialExecutors", "10")
sconf.set("spark.yarn.executor.memoryOverhead", "10G")
sconf.set("spark.sql.warehouse.dir", "/user/hive/warehouse")
sconf.set("hive.metastore.execute.setugi", "true")
sconf.set("spark.sql.parquet.compression.codec", "snappy")
sconf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
sconf.set("spark.sql.inMemoryColumnarStorage.compressed", "true")
sconf.set("spark.hadoop.parquet.enable.summary-metadata", "false")
sconf.set("spark.hadoop.mapreduce.fileoutputcommitter.marksuccessfuljobs", "false")
sconf.set("spark.network.timeout","60s")

sconf.set("hive.exec.dynamic.partition", "true")
sconf.set("hive.exec.dynamic.partition.mode", "nonstrict")
#sconf.set("mapred.max.split.size","104857600")
#sconf.set("mapred.min.split.size","104857600")
sconf.set("mapred.max.split.size","512857600")
sconf.set("mapred.min.split.size","512857600")
sconf.set("hive.merge.mapfiles", "true")
sconf.set("hive.merge.mapredfiles", "true")
#sconf.set("hive.merge.sparkfiles","true")
sconf.set("hive.merge.size.per.task","512715200")
sconf.set("hive.merge.smallfiles.avgsize","512857600")

spark = SparkSession.builder.appName('mergeSmallFiles').config(conf=sconf).getOrCreate()

temp_table = "_temp_" + str(datetime.datetime.today().strftime('%Y_%m_%d'))

spark.catalog.refreshTable("asl_core.entity_notif_stage")

spark.sql("INSERT OVERWRITE TABLE asl_core.entity_notif_stage PARTITION(meta_current_ind) SELECT * FROM  asl_core.entity_notif_stage")
#spark.sql("CREATE TABLE telenium.connection_history_1 AS from telenium.connection_history where load_date='20170418'")
#spark.sql("INSERT OVERWRITE TABLE telenium.connection_history PARTITION(load_date) SELECT * FROM  telenium.connection_history_1")

#df =spark.table("telenium.connection_history_1")
#subprocess.call(["hadoop", "fs", "-rm", "-R", "/data/CTL/encrypt/db/ingest/raw/telenium/connection_history/load_date=20170418"])
#df.repartition(1).write.format("parquet").mode("overwrite").insertInto("telenium.connection_history")

exit()
