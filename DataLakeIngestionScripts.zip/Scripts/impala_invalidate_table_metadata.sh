#!/bin/bash

# Argument Count Check
if [[ "$#" -ne 2 ]]; then
    echo "Incorrect number of arguments."
    echo "USAGE: $(basename $0) DATABASE_NAME TABLE_NAME"
    exit 1
fi

# Get arguments

########## BELOW RANDOM_NUMBER GENERATION CHANGE DONE BECAUSE OF Tech Debt: Invalid Metadata - EMS (Production failures) -- START ############

RANDOM_NUMBER=$(shuf -i 11-20 -n 1)
IMPALA_HOST=poldcdhdn0$RANDOM_NUMBER.dev.intranet

##########  END  ################

HIVE_DATABASE=$1
HIVE_TABLE_NAME=$2
DB_DOT_TABLE_NAME="${HIVE_DATABASE}.${HIVE_TABLE_NAME}"


#print what database and tablename will have the metadata invalidated
echo "Database and Table to have metadata invalidated: ${DB_DOT_TABLE_NAME}"

# Fix error regarding Impala refresh not having access to /home/.python-eggs
# Directory should be cleaned up with the job
export PYTHON_EGG_CACHE=./eggs

# Get kerberos ticket
/usr/bin/kinit -V -kt cdlapp.keytab cdlapp@CTL.INTRANET
RC=$?
if [[ $RC -ne 0 ]]; then
    echo "KINIT ERROR RC: $RC"
    exit 2
fi

# Impala Refresh table, it was just updated via Hive...
# Invalidate vs. refresh so that Impala sees the table on first run
impala-shell -k --ssl -i $IMPALA_HOST -B --output_delimiter=, -q "INVALIDATE METADATA $DB_DOT_TABLE_NAME"
RC=$?
if [[ $RC -ne 0 ]]; then
    echo "IMPALA ERROR RC: $RC"
    exit 3
fi

exit 0
