use lvcht;

-------------------------------------------
-- lvcht.interaction_json_work table creation
-------------------------------------------

CREATE TABLE `lvcht.interaction_json_work`(
  `interactionhistoryrecords` array<struct<campaign:struct<behaviorsystemdefault:boolean,campaignengagementid:string,campaignengagementname:string,campaignid:string,campaignname:string,goalid:string,goalname:string,lobid:bigint,lobname:string,profilesystemdefault:boolean,visitorbehaviorid:string,visitorbehaviorname:string,visitorprofileid:string,visitorprofilename:string>,info:struct<accountid:string,agentdeleted:boolean,agentfullname:string,agentgroupid:bigint,agentgroupname:string,agentid:string,agentname:string,agentloginname:string,agentnickname:string,alertedmcs:bigint,channel:bigint,chatdataenriched:boolean,chatmcs:bigint,chatrequestedtime:string,chatrequestedtimel:string,chatstartpage:string,chatstarturl:string,duration:bigint,ended:boolean,endreason:string,endreasondesc:string,endtime:string,endtimel:bigint,engagementid:string,engagementsequence:bigint,engagementset:bigint,interactive:boolean,isagentsurvey:boolean,isinteractive:boolean,ispartial:boolean,ispostchatsurvey:boolean,isprechatsurvey:boolean,mcs:bigint,sharkengagementid:string,skillid:bigint,skillname:string,startreason:string,startreasondesc:string,starttime:string,starttimel:bigint,visitorid:string,visitorname:string>,linescores:array<struct<linerawscore:bigint,lineseq:string,mcs:bigint>>,surveys:struct<operator:array<struct<displayname:string,name:string,questionid:bigint,scope:string,source:string,surveyid:bigint,time:string,timel:bigint,value:string,values:array<string>>>,postchat:array<struct<displayname:string,name:string,questionid:bigint,scope:string,source:string,surveyid:bigint,time:string,timel:bigint,value:string,values:array<string>>>,prechat:array<struct<displayname:string,name:string,questionid:bigint,scope:string,source:string,surveyid:bigint,time:string,timel:bigint,value:string,values:array<string>>>>,transcript:struct<lines:array<struct<agentid:bigint,by:string,cannedanswertype:bigint,controltype:bigint,lineseq:string,source:string,subtype:string,text:string,texttype:string,time:string,timel:bigint>>>,cobrowsesessions:struct<cobrowsesessionslist:array<struct<duration:bigint,endreason:string,endtime:string,endtimel:bigint,interactive:boolean,interactivetime:string,interactivetimel:bigint,sessionid:string,starttime:string,starttimel:bigint>>>,visitorinfo:struct<browser:string,browsertype:string,city:string,country:string,countrycode:string,device:string,ipaddress:string,isp:string,operatingsystem:string,org:string,state:string>>>)
ROW FORMAT SERDE
  'org.openx.data.jsonserde.JsonSerDe'
STORED AS INPUTFORMAT
  'org.apache.hadoop.mapred.TextInputFormat'
OUTPUTFORMAT
  'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION
  '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_json_work'


-------------------------------------------
-- info related table creation
-------------------------------------------


CREATE EXTERNAL TABLE IF NOT EXISTS `lvcht.interaction_info`(
  `starttime` timestamp,
  `starttimel` bigint,
  `endtime` timestamp,
  `endtimel` bigint,
  `duration` bigint,
  `visitorid` string,
  `visitorname` string,
  `engagementid` string,
  `sharkengagementid` string,
  `isinteractive` boolean,
  `accountid` string,
  `agentid` string,
  `agentname` string,
  `agentnickname` string,
  `agentloginname` string,
  `agentdeleted` boolean,
  `agentfullname` string,
  `skillid` bigint,
  `skillname` string,
  `isagentsurvey` boolean,
  `ispostchatsurvey` boolean,
  `isprechatsurvey` boolean,
  `channel` bigint,
  `startreason` string,
  `startreasondesc` string,
  `endreason` string,
  `endreasondesc` string,
  `engagementset` bigint,
  `engagementsequence` bigint,
  `agentgroupid` bigint,
  `agentgroupname` string,
  `mcs` bigint,
  `alertedmcs` bigint,
  `chatmcs` bigint,
  `chatrequestedtime` timestamp,
  `chatrequestedtimel` string,
  `chatstarturl` string,
  `chatstartpage` string,
  `ispartial` boolean,
  `chatdataenriched` boolean,
  `interactive` boolean,
  `ended` boolean,
  `meta_load_dt` timestamp)
PARTITIONED BY (`year_month` STRING)
STORED AS PARQUET
LOCATION '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_info'
;


-------------------------------------------
-- transcript related table creation
-------------------------------------------

CREATE TABLE `lvcht.interaction_unwind_json_transcript`(
`engagementid` string,
`visitorid` string,
`agentid` string,
`transcript` struct<lines:array<struct<agentid:bigint,by:string,cannedanswertype:bigint,controltype:bigint,lineseq:string,source:string,subtype:string,text:string,texttype:string,time:string,timel:bigint>>>)
STORED AS PARQUET
LOCATION
  '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_unwind_json_transcript'
;

 CREATE TABLE if not exists `lvcht.interaction_work_transcript`(
  `engagementid` string,
  `visitorid` string,
  `time` string,
  `timel` bigint,
  `controltype` bigint,
  `text` string,
  `by` string,
  `source` string,
  `subtype` string,
  `texttype` string,
  `cannedanswertype` bigint,
  `trans_agentid` bigint,
  `lineseq` string)
STORED AS PARQUET
LOCATION '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_work_transcript';


CREATE EXTERNAL TABLE `lvcht.interaction_transcript`(
  `engagementid` string,
  `visitorid` string,
  `time` timestamp,
  `timel` bigint,
  `controltype` string,
  `text` string,
  `by` string,
  `source` string,
  `subtype` string,
  `texttype` string,
  `cannedanswertype` string,
  `trans_agentid` string,
  `lineseq` string,
  `meta_load_dt` timestamp )
PARTITIONED BY (`year_month` STRING)
STORED AS PARQUET
LOCATION '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_transcript'
;


-------------------------------------------
-- survey_prechat related table creation
-------------------------------------------


CREATE TABLE `lvcht.interaction_unwind_json_survey_prechat`(
  `engagementid` string,
  `visitorid` string,
  `agentid` string,
  `prechat` array<struct<displayname:string,name:string,questionid:bigint,scope:string,source:string,surveyid:bigint,time:string,timel:bigint,value:string,values:array<string>>>)
STORED AS PARQUET
LOCATION
  '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_unwind_json_survey_prechat'
;


CREATE TABLE `lvcht.interaction_unwind_json_survey_prechat_1`(
  `engagementid` string,
  `visitorid` string,
  `agentid` string,
  `displayname` string,
  `name` string,
  `questionid` bigint,
  `scope` string,
  `source` string,
  `surveyid` bigint,
  `time` string,
  `timel` bigint,
  `value` string,
  `values` array<string>)
STORED AS PARQUET
LOCATION
 '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_unwind_json_survey_prechat_1';


 CREATE EXTERNAL TABLE `lvcht.interaction_survey_prechat`(
  `engagementid` string,
  `visitorid` string,
  `agentid` string,
  `displayname` string,
  `name` string,
  `questionid` bigint,
  `scope` string,
  `source` string,
  `surveyid` bigint,
  `time` timestamp,
  `timel` bigint,
  `value` string,
  `values` string,
  `meta_load_dt` timestamp)
PARTITIONED BY (
  `year_month` string)
STORED AS PARQUET
LOCATION
  '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_survey_prechat'
;

-------------------------------------------
-- survey_postchat related table creation
-------------------------------------------


CREATE TABLE `lvcht.interaction_unwind_json_survey_postchat`(
  `engagementid` string,
  `visitorid` string,
  `agentid` string,
  `postchat` array<struct<displayname:string,name:string,questionid:bigint,scope:string,source:string,surveyid:bigint,time:string,timel:bigint,value:string,values:array<string>>>)
STORED AS PARQUET
LOCATION
  '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_unwind_json_survey_postchat'
 ;


 CREATE TABLE `lvcht.interaction_unwind_json_survey_postchat_1`(
  `engagementid` string,
  `visitorid` string,
  `agentid` string,
  `displayname` string,
  `name` string,
  `questionid` bigint,
  `scope` string,
  `source` string,
  `surveyid` bigint,
  `time` string,
  `timel` bigint,
  `value` string,
  `values` array<string>)
STORED AS PARQUET
LOCATION
 '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_unwind_json_survey_postchat_1'
 ;

 CREATE EXTERNAL TABLE `lvcht.interaction_survey_postchat`(
  `engagementid` string,
  `visitorid` string,
  `agentid` string,
  `displayname` string,
  `name` string,
  `questionid` bigint,
  `scope` string,
  `source` string,
  `surveyid` bigint,
  `time` timestamp,
  `timel` bigint,
  `value` string,
  `values` string,
  `meta_load_dt` timestamp)
PARTITIONED BY (
  `year_month` string)
STORED AS PARQUET
LOCATION
'/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_survey_postchat'
;


-------------------------------------------
-- survey_operator related table creation
-------------------------------------------

CREATE TABLE `lvcht.interaction_unwind_json_survey_operator`(
  `engagementid` string,
  `visitorid` string,
  `agentid` string,
  `operator` array<struct<displayname:string,name:string,questionid:bigint,scope:string,source:string,surveyid:bigint,time:string,timel:bigint,value:string,values:array<string>>>)
STORED AS PARQUET
LOCATION
  '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_unwind_json_survey_operator'
 ;


CREATE TABLE `lvcht.interaction_unwind_json_survey_operator_1`(
  `engagementid` string,
  `visitorid` string,
  `agentid` string,
  `displayname` string,
  `name` string,
  `questionid` bigint,
  `scope` string,
  `source` string,
  `surveyid` bigint,
  `time` string,
  `timel` bigint,
  `value` string,
  `values` array<string>)
STORED AS PARQUET
LOCATION
 '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_unwind_json_survey_operator_1'
 ;


 CREATE EXTERNAL TABLE `lvcht.interaction_survey_operator`(
  `engagementid` string,
  `visitorid` string,
  `agentid` string,
  `displayname` string,
  `name` string,
  `questionid` bigint,
  `scope` string,
  `source` string,
  `surveyid` bigint,
  `time` timestamp,
  `timel` bigint,
  `value` string,
  `values` string,
  `meta_load_dt` timestamp)
PARTITIONED BY (
  `year_month` string)
STORED AS PARQUET
LOCATION
  '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_survey_operator'
 ;

-------------------------------------------
-- campaign related table creation
-------------------------------------------

CREATE EXTERNAL TABLE `lvcht.interaction_campaign`(
  `engagementid` string,
  `visitorid` string,
  `agentid` string,
  `campaignengagementid` string,
  `campaignengagementname` string,
  `campaignid` string,
  `campaignname` string,
  `goalid` string,
  `goalname` string,
  `visitorbehaviorid` string,
  `visitorbehaviorname` string,
  `visitorprofileid` string,
  `visitorprofilename` string,
  `lobid` bigint,
  `lobname` string,
  `behaviorsystemdefault` boolean,
  `profilesystemdefault` boolean,
  `meta_load_dt` timestamp)
PARTITIONED BY (
  `year_month` string)
STORED AS PARQUET
LOCATION
'/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_campaign'
 ;

-------------------------------------------
-- campaign related table creation
-------------------------------------------

 CREATE EXTERNAL TABLE `lvcht.interaction_visitorInfo`(
  `engagementid` string,
  `visitorid` string,
  `agentid` string,
  `country` string,
  `countrycode` string,
  `state` string,
  `city` string,
  `isp` string,
  `org` string,
  `device` string,
  `ipaddress` string,
  `browser` string,
  `operatingsystem` string,
  `browsertype` string,
  `meta_load_dt` timestamp)
PARTITIONED BY (
  `year_month` string)
STORED AS PARQUET
LOCATION
  '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_visitorInfo'


-------------------------------------------
-- linescore related table creation
-------------------------------------------

create table if not exists lvcht.interaction_unwind_json_linescores
(engagementId string,
visitorId string,
agentid string,
starttime string,
linescores array<struct<linerawscore:bigint,lineseq:string,mcs:bigint>>
)
STORED AS PARQUET
LOCATION '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_unwind_json_linescores';


create external table if not exists lvcht.interaction_linescores
(engagementId string,
visitorId string,
agentid string,
linerawscore bigint,
lineseq string,
mcs bigint,
meta_load_dt timestamp
)
PARTITIONED BY (`year_month` STRING)
STORED AS PARQUET
LOCATION '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_linescores'
;


-------------------------------------------
-- sdes related table creation
-------------------------------------------

CREATE TABLE if not exists`interaction_json_work_sdes`(
  `interactionhistoryrecords` array<struct<info:struct<accountid:string,agentdeleted:boolean,agentfullname:string,agentgroupid:bigint,agentgroupname:string,agentid:string,agentname:string,agentloginname:string,agentnickname:string,alertedmcs:bigint,channel:bigint,chatdataenriched:boolean,chatmcs:bigint,chatrequestedtime:string,chatrequestedtimel:string,chatstartpage:string,chatstarturl:string,duration:bigint,ended:boolean,endreason:string,endreasondesc:string,endtime:string,endtimel:bigint,engagementid:string,engagementsequence:bigint,engagementset:bigint,interactive:boolean,isagentsurvey:boolean,isinteractive:boolean,ispartial:boolean,ispostchatsurvey:boolean,isprechatsurvey:boolean,mcs:bigint,sharkengagementid:string,skillid:bigint,skillname:string,startreason:string,startreasondesc:string,starttime:string,starttimel:bigint,visitorid:string,visitorname:string>,sdes:struct<events:array<struct<cartstatus:struct<currency:string,numitems:string,originaltimestamp:string,products:array<struct<product:struct<category:string,name:string,price:string,sku:string>,quantity:string>>,servertimestamp:string,total:string>,customerinfo:struct<customerinfo:struct<accountname:string,balance:string,companybranch:string,companysize:string,currency:string,customerid:string,customerstatus:string,customertype:string,imei:string,lastpaymentdate:struct<day:string,month:string,year:string>,registrationdate:struct<day:string,month:string,year:string>,role:string,socialid:bigint,storenumber:string,storezipcode:string,username:string>,originaltimestamp:string,servertimestamp:string>,lead:struct<lead:struct<currency:string,leadid:string,topic:string,value:string>,originaltimestamp:string,servertimestamp:string>,marketingcampaigninfo:struct<marketingcampaigninfo:struct<affiliate:string,campaignid:string,originatingchannel:string>,originaltimestamp:string,servertimestamp:string>,personalinfo:struct<originaltimestamp:string,personalinfo:struct<company:string,contacts:array<struct<personalcontact:struct<email:string,phone:string>>>,customerage:struct<customerageinyears:string,customerdateofbirth:string,customermonthofbirth:string,customeryearofbirth:string>,gender:string,language:string,name:string,surname:string>,servertimestamp:string>,purchase:struct<cart:struct<currency:string,numitems:string,products:array<struct<product:struct<category:string,name:string,price:string,sku:string>,quantity:string>>,total:string>,orderid:string,originaltimestamp:string,servertimestamp:string,total:string>,searchcontent:struct<keywords:array<string>,originaltimestamp:string,servertimestamp:string>,serviceactivity:struct<originaltimestamp:string,servertimestamp:string,serviceactivity:struct<category:string,serviceid:string,status:string,topic:string>>,viewedproduct:struct<currency:string,originaltimestamp:string,products:array<struct<product:struct<category:string,name:string,price:string,sku:string>>>,servertimestamp:string>,visitorerror:struct<originaltimestamp:string,servertimestamp:string,visitorerror:struct<code:string,contextid:string,level:string,message:string,resolved:string>>>>>,linescores:array<struct<linerawscore:bigint,lineseq:string,mcs:bigint>>>> COMMENT 'from deserializer')
ROW FORMAT SERDE
  'org.openx.data.jsonserde.JsonSerDe'
STORED AS INPUTFORMAT
  'org.apache.hadoop.mapred.TextInputFormat'
OUTPUTFORMAT
  'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION
'/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_json_work_sdes'
;

create table if not exists lvcht.interaction_unwind_json_sdes_events (
engagementId string,
visitorId string,
agentid string,
starttime string,
events array<struct<
cartstatus:struct<currency:string, numitems:string, originaltimestamp:string, products:array<struct<product:struct<category:string, name:string, price:string, sku:string>, quantity:string>>, servertimestamp:string, total:string>,
customerinfo:struct<customerinfo:struct<accountname:string, balance:string, companybranch:string, companysize:string, currency:string, customerid:string, customerstatus:string, customertype:string, imei:string, lastpaymentdate:struct<day:string, month:string, year:string>, registrationdate:struct<day:string, month:string, year:string>, role:string, socialid:bigint, storenumber:string, storezipcode:string, username:string>, originaltimestamp:string, servertimestamp:string>,
lead:struct<lead:struct<currency:string, leadid:string, topic:string, value:string>, originaltimestamp:string, servertimestamp:string>,
marketingcampaigninfo:struct<marketingcampaigninfo:struct<affiliate:string, campaignid:string, originatingchannel:string>, originaltimestamp:string, servertimestamp:string>,
personalinfo:struct<originaltimestamp:string,personalinfo:struct<company:string, contacts:array<struct<personalcontact:struct<email:string, phone:string>>>, customerage:struct<customerageinyears:string, customerdateofbirth:string, customermonthofbirth:string, customeryearofbirth:string>, gender:string, language:string, name:string, surname:string>, servertimestamp:string>,
purchase:struct<cart:struct<currency:string, numitems:string, products:array<struct<product:struct<category:string, name:string, price:string, sku:string>, quantity:string>>, total:string>, orderid:string, originaltimestamp:string, servertimestamp:string, total:string>,
searchcontent:struct<keywords:array<string>, originaltimestamp:string, servertimestamp:string>,
serviceactivity:struct<originaltimestamp:string, servertimestamp:string, serviceactivity:struct<category:string, serviceid:string, status:string, topic:string>>,
viewedproduct:struct<currency:string, originaltimestamp:string, products:array<struct<product:struct<category:string, name:string, price:string, sku:string>>>, servertimestamp:string>,
visitorerror:struct<originaltimestamp:string, servertimestamp:string, visitorerror:struct<code:string, contextid:string, level:string, message:string, resolved:string>>>>
)
ROW FORMAT SERDE 'org.openx.data.jsonserde.JsonSerDe'
WITH SERDEPROPERTIES ("hive.serialization.extend.nesting.levels"="true")
STORED AS INPUTFORMAT 'org.apache.hadoop.mapred.TextInputFormat'
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_unwind_json_sdes_events';


create table if not exists lvcht.interaction_unwind_json_sdes_events_cartStatus
(
engagementId string,
visitorId string,
agentid string,
starttime string,
servertimestamp string,
originaltimestamp string,
total string,
currency string,
numItems string,
products array<struct<product:struct<category:string, name:string, price:string, sku:string>, quantity:string>>
)
STORED AS PARQUET
LOCATION '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_unwind_json_sdes_events_cartStatus';


create external table if not exists lvcht.interaction_sdes_cartStatus
(
engagementId string,
visitorId  string,
agentId string,
serverTimeStamp string,
originalTimeStamp string,
total string,
currency string,
numItems string,
quantity string,
name string,
category string,
sku string,
price string,
meta_load_dt timestamp
)
PARTITIONED BY (`year_month` STRING)
STORED AS PARQUET
LOCATION '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_cartStatus'
;


create external table if not exists lvcht.interaction_sdes_serviceActivity
(engagementId string,
visitorId string,
agentid string,
servertimestamp string,
originaltimestamp string,
topic string,
status string,
category string,
serviceId string,
meta_load_dt timestamp
)
PARTITIONED BY (`year_month` STRING)
STORED AS PARQUET
LOCATION '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_serviceActivity'
;


create table if not exists lvcht.interaction_unwind_json_sdes_events_searchContent
(engagementId string,
visitorId string,
agentid string,
starttime string,
servertimestamp string,
originaltimestamp string,
keywords array<string>
)
STORED AS PARQUET
LOCATION '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_unwind_json_sdes_events_searchContent';


create external table if not exists lvcht.interaction_sdes_searchContent
(engagementId string,
visitorId string,
agentid string,
servertimestamp string,
originaltimestamp string,
keywords string,
meta_load_dt timestamp
)
PARTITIONED BY (`year_month` STRING)
STORED AS PARQUET
LOCATION '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_searchContent'
;

create table if not exists lvcht.interaction_unwind_json_sdes_events_personalInfo
(engagementId string,
visitorId string,
agentid string,
starttime string,
servertimestamp string,
originaltimestamp string,
name string,
surname string,
gender string,
company string,
language string,
customerAgeInYears string,
customerYearOfBirth string,
customerMonthOfBirth string,
customerDateOfBirth string,
contacts array<struct<personalcontact:struct<email:string, phone:string>>>
)
STORED AS PARQUET
LOCATION '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_unwind_json_sdes_events_personalInfo';



create external table if not exists lvcht.interaction_sdes_personalInfo
(engagementId string,
visitorId string,
agentid string,
servertimestamp string,
originaltimestamp string,
name string,
surname string,
gender string,
company string,
language string,
customerAgeInYears string,
customerYearOfBirth string,
customerMonthOfBirth string,
customerDateOfBirth string,
email string,
phone string,
meta_load_dt timestamp
)
PARTITIONED BY (`year_month` STRING)
STORED AS PARQUET
LOCATION '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_personalInfo'
;


create external table if not exists lvcht.interaction_sdes_marketingCampaignInfo
(
engagementId string,
visitorId string,
agentid string,
serverTimeStamp string,
originalTimeStamp string,
originatingChannel string,
affiliate string,
campaignId string,
meta_load_dt timestamp
)
PARTITIONED BY (`year_month` STRING)
STORED AS PARQUET
LOCATION '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_marketingCampaignInfo'
;

create external table if not exists lvcht.interaction_sdes_lead
(
engagementId string,
visitorId string,
agentid string,
serverTimeStamp string,
originalTimeStamp string,
topic string,
value string,
currency string,
leadId string,
meta_load_dt timestamp
)
PARTITIONED BY (`year_month` STRING)
STORED AS PARQUET
LOCATION '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_lead'
;

create external table if not exists lvcht.interaction_sdes_customerInfo
(
engagementId string,
visitorId string,
agentid string,
servertimestamp string,
originaltimestamp string,
customerStatus string,
customerType string,
Currency string,
socialId BIGINT,
imei string,
userName string,
accountName string,
role string,
companyBranch string,
storeNumber string,
storeZipCode string,
lastPaymentDate_year string,
lastPaymentDate_month string,
lastPaymentDate_day string,
registrationDate_year string,
registrationDate_month string,
registrationDate_day string,
companySize string,
meta_load_dt timestamp
)
PARTITIONED BY (`year_month` STRING)
STORED AS PARQUET
LOCATION '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_customerInfo'
;


create external table if not exists lvcht.interaction_sdes_visitorError
(
engagementId string,
visitorId string,
agentid string,
servertimestamp string,
originaltimestamp string,
contextId string,
message string,
level string,
resolved string,
meta_load_dt timestamp
)
PARTITIONED BY (`year_month` STRING)
STORED AS PARQUET
LOCATION '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_visitorError'
;

create table if not exists lvcht.interaction_unwind_json_sdes_events_purchase
(
engagementId string,
visitorId string,
agentid string,
starttime string,
servertimestamp string,
originaltimestamp string,
total string,
cart_total string,
cart_currency string,
cart_numItems string,
orderId string,
products array<struct<product:struct<category:string, name:string, price:string, sku:string>, quantity:string>>
)
STORED AS PARQUET
LOCATION '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_unwind_json_sdes_events_personalInfo';



create external table lvcht.interaction_sdes_purchase
(
engagementId string,
visitorId string,
agentid string,
servertimestamp string,
originaltimestamp string,
total string,
cart_total string,
cart_currency string,
cart_numItems string,
orderId string,
quantity string,
name string,
category string,
sku string,
price string,
meta_load_dt timestamp
)
PARTITIONED BY (`year_month` STRING)
STORED AS PARQUET
LOCATION '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_purchase'
;



create table if not exists lvcht.interaction_unwind_json_sdes_events_viewedProduct
(
engagementId string,
visitorId string,
agentid string,
starttime string,
servertimestamp string,
originaltimestamp string,
currency string,
products array<struct<product:struct<category:string, name:string, price:string, sku:string>>>
)
STORED AS PARQUET
LOCATION '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_unwind_json_sdes_events_viewedProduct';


create external table lvcht.interaction_sdes_viewedProduct
(
engagementId string,
visitorId string,
agentid string,
servertimestamp string,
originaltimestamp string,
currency string,
name string,
category string,
sku string,
price string,
meta_load_dt timestamp
)
PARTITIONED BY (`year_month` STRING)
STORED AS PARQUET
LOCATION '/data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_viewedProduct'
;
