#########################################################################################################################################################
### pyspark script to merge multiple small files or split large files to approximately the size of avg hdfs block 				      ###
### size.																	      ###
### Author --> NAVNEET KAUR														              ###
### Input parameters --> This script takes five input params   											      ###
### 1. HIVE_SCHEMA: This is the name of concerned database  											      ###
### 2. HIVE_TABLE: This is the name of concerned table  											      ###
### 3. DB_DIR: The location of concerned table on hdfs   											      ###
### 4. PARTITION_COLS: Name of partition columns if concerned table has any( This parameter will be passed as NULL if no partitioning is there)       ###
### 5. BUCKET_COLS :Name of bucketing columns if concerned table has any( This parameter will be passed as NULL if no bucketing is there)	      ###
### 6. NUM_BUCKETS : Number of buckets														      ###
###																		      ###
### Example 1(Table with no partition no bucketing): spark2-submit merge-small-files.py ilm document /data/CTL/encrypt/db/ingest/raw/ilm/document     ###
###           null null null															      ###
### Example 2(Table with just partition columns) : spark2-submit merge-small-files.py ilm document /data/CTL/encrypt/db/ingest/raw/ilm/document       ###
###           [part_col1,part_col2.... part_coln] null null										              ###
### Example 3(Table with partition and bucketing) :  spark2-submit merge-small-files.py ilm document /data/CTL/encrypt/db/ingest/raw/ilm/document     ###
###           [part_col1,part_col2,......partcoln] [bucket_col1,bucket_col2....bucket_coln] 256                                                       ###
#########################################################################################################################################################

#!/usr/bin/env python

from __future__ import division
from pyspark.sql import SparkSession
import sys
import pyspark
from pyspark.conf import SparkConf
from pyspark import SparkContext
from pyspark.sql.functions import *
from pyspark.sql import HiveContext
import datetime
import commands
import math
import subprocess

HIVE_SCHEMA=sys.argv[1]
HIVE_TABLE=sys.argv[2]
DB_DIR=sys.argv[3]
PARTITION_COLS=sys.argv[4].strip('[]')
BUCKET_COLS=sys.argv[5].strip('[]')
NUM_BUCKETS=sys.argv[6]
sconf = pyspark.SparkConf()

###############################################################################################################
### -*- setting required configs for hive, spark sql and yarn in sparkContext and initializing SparkSession -*-
###############################################################################################################

sconf.set("hive.metastore.uris", "thrift://poldcdhmn003.dev.intranet:9083")
sconf.set("spark.shuffle.service.enabled", "true")
sconf.set("yarn.nodemanager.pmem-check-enabled", "false")
sconf.set("yarn.nodemanager.vmem-check-enabled", "false")
sconf.set("spark.dynamicAllocation.enabled", "true")
sconf.set("spark.dynamicAllocation.minExecutors", "0")
sconf.set("spark.dynamicAllocation.maxExecutors", "200")
sconf.set("spark.dynamicAllocation.initialExecutors", "20") 
sconf.set("spark.yarn.executor.memoryOverhead", "10G")
sconf.set("spark.sql.warehouse.dir", "/user/hive/warehouse")
sconf.set("hive.metastore.execute.setugi", "true")
sconf.set("hive.exec.dynamic.partition", "true")
sconf.set("hive.exec.dynamic.partition.mode", "nonstrict")
sconf.set("hive.merge.mapfiles", "true")
sconf.set("hive.merge.mapredfiles", "true")
sconf.set("hive.merge.sparkfiles", "true")
sconf.set("spark.sql.parquet.compression.codec", "snappy")
sconf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
sconf.set("spark.sql.inMemoryColumnarStorage.compressed", "true") 
sconf.set("spark.sql.hive.verifyPartitionPath", "false")

#sconf.set("spark.default.parallelism","23")
#sconf.set("spark.network.timeout","60s")
#sconf.set("spark.executor.memory", "12G") 
#sconf.set("spark.executor.cores", "3")
#sconf.set("spark.cores.max", "5")
sconf.set("spark.hadoop.parquet.enable.summary-metadata", "false")
sconf.set("spark.hadoop.mapreduce.fileoutputcommitter.marksuccessfuljobs", "false")

spark = SparkSession.builder.appName('mergeSmallFiles').config(conf=sconf).getOrCreate()

temp_table = "_temp_" + str(datetime.datetime.today().strftime('%Y_%m_%d'))

##############################################
### -*- selecting data from original table -*-
##############################################
spark.sql("DROP TABLE IF EXISTS "+HIVE_SCHEMA + "." + HIVE_TABLE + temp_table);

def merge_partitioned_table():
	all_partitions = spark.sql("SHOW PARTITIONS "+ HIVE_SCHEMA+"."+HIVE_TABLE)
	count=0;
	for partition in all_partitions.collect():
		current_dir = DB_DIR + "/" + str(partition).replace("Row(partition=u'","").replace("')","")
		proc = subprocess.Popen(['hadoop', 'fs', '-test', '-e', current_dir])
		proc.communicate()

		if proc.returncode != 0:
			print '%s does not exist' % current_dir
		else :
			print '%s exist' % current_dir
	        	current_part = str(partition).replace("Row(partition=u'","").replace("=","='").replace(r"/","' AND ").replace("')","'")
			part_df = spark.sql("SELECT * from "+ HIVE_SCHEMA + "." + HIVE_TABLE +" WHERE "+ current_part)
			part_df_numrows = part_df.count()
			
			if part_df_numrows > 0 :
				part_df.write.format("parquet").saveAsTable(HIVE_SCHEMA + "." + HIVE_TABLE + temp_table)
				part_df_temp = spark.table(HIVE_SCHEMA + "." + HIVE_TABLE + temp_table)
				part_df_temp_numrows = part_df_temp.count()

				if part_df_numrows != part_df_temp_numrows :
					print("************Row count for partition did not match. Org row count =" + str(part_df_numrows) + ", Temp row count =" + str(part_df_temp_numrows) + ". So skipping file merge.")
				else :
					print("************Row count for partition match. Original row count =" + str(part_df_numrows) + ", Temp row count =" + str(part_df_temp_numrows))
					part_hdir_size = commands.getoutput("hdfs dfs -du -s " + current_dir + " |awk \'{print $1}\'")
					part_num_files = math.ceil(int(part_hdir_size)/115000000);
			
					part_df_temp.repartition(int(part_num_files)).write.format("parquet").mode("overwrite").save(current_dir)
					count = count+1;
					print ("Total partitions processed : " + str(count))

				spark.sql("DROP TABLE IF EXISTS "+HIVE_SCHEMA + "." + HIVE_TABLE + temp_table);
			else :
				print ("No data in partition")

merge_partitioned_table()
		
#Hive_DF=spark.table(HIVE_SCHEMA+"."+HIVE_TABLE)
#org_row_count = Hive_DF.count()

########################################################################################################
### -*- write data from sql_table dataframe to a temp location,
### then read data from temp location and overwrite at original location.
### We are doing this because spark does not allow to overwrite a path that is also being read from -*-
########################################################################################################

#Hive_DF.write.format("parquet").mode("overwrite").saveAsTable(HIVE_SCHEMA + "." + HIVE_TABLE + temp_table)
#Hive_DF_temp = spark.table(HIVE_SCHEMA + "." + HIVE_TABLE + temp_table)
#temp_row_count = Hive_DF_temp.count()

#######################################################################################################
### -*- Compare row count of original and temp table drop and stop processing if it does not match -*-
#######################################################################################################

#if org_row_count != temp_row_count :
#	print("************Row count for temp and original table did not match. Original row count =" + str(org_row_count) + ", Temp row count =" + str(temp_row_count))
#	exit()
#else :
#	print("************Row count for temp and original table match. Original row count =" + str(org_row_count) + ", Temp row count =" + str(temp_row_count))

#hdir_size = commands.getoutput("hdfs dfs -du -s " + DB_DIR + temp_table + " |awk \'{print $1}\'")
#print hdir_size
#num_files = math.ceil(int(hdir_size)/95000000);

#if PARTITION_COLS!="" and PARTITION_COLS!="null" and BUCKET_COLS!="" and BUCKET_COLS!="null" :
#        print "**********Overwriting partition-bucketed table with partition cols:" + PARTITION_COLS +" ,bucketing cols:" + BUCKET_COLS + " ,num_buckets:" + NUM_BUCKETS
#        Hive_DF_temp.repartition(int(NUM_BUCKETS),BUCKET_COLS).write.format("parquet").mode("overwrite").partitionBy(PARTITION_COLS).saveAsTable(HIVE_SCHEMA + "." + HIVE_TABLE )
#elif PARTITION_COLS!="" and PARTITION_COLS!="null" and (BUCKET_COLS=="" or BUCKET_COLS=="null") :
#	print "***************Overwriting partitioned table with partition cols:" + PARTITION_COLS
#        Hive_DF_temp.coalesce(int(num_files)).write.format("parquet").mode("overwrite").partitionBy(PARTITION_COLS).saveAsTable(HIVE_SCHEMA + "." + HIVE_TABLE )
#elif  BUCKET_COLS!="" and BUCKET_COLS!="null" and (PARTITION_COLS=="" or PARTITION_COLS=="null") :
#	print "***************Overwriting bucketed table with bucketing cols:" + BUCKET_COLS + " ,num_buckets:" + NUM_BUCKETS
#	Hive_DF_temp.repartition(int(NUM_BUCKETS),BUCKET_COLS).write.format("parquet").mode("overwrite").saveAsTable(HIVE_SCHEMA + "." + HIVE_TABLE )
#else :
#        print "*****************Overwriting flat table"
#        Hive_DF_temp.repartition(int(num_files)).write.format("parquet").mode("overwrite").saveAsTable(HIVE_SCHEMA + "." + HIVE_TABLE )

#########################################################################
### -*- refresh catalog cache for loading fresh partition and values -*-
########################################################################

#spark.catalog.refreshTable(HIVE_SCHEMA + "." + HIVE_TABLE )

#Hive_DF_final = spark.table(HIVE_SCHEMA + "." + HIVE_TABLE )
#final_row_count = Hive_DF_final.count()

########################################################################################################
### -*- Compare row count of original and final table drop and stop processing if it does not match -*-
########################################################################################################

#if org_row_count != final_row_count :
#	print("****************Row count for final and original table did not match. Original row count =" + str(org_row_count) + ", Final table row count =" + str(final_row_count))
#	exit()
#else :
#        print("****************Row count for final and original table match. Original row count =" + str(org_row_count) + ", Final table row count =" + str(final_row_count))

######################################
### -*- delete the temp location  -*-
######################################

#print "deleting temp table"
#spark.sql("DROP TABLE IF EXISTS "+ HIVE_SCHEMA + "." + HIVE_TABLE+ temp_table)
#print "temp table deleted"

#print "Overwrite Successful"
#spark.stop()
exit()

