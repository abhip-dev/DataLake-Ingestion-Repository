#############################################################################################################################################################
#  Script Shell : bash
#  Script       : process_pdf.sh
#
#  Description  : The script parses pdf files by calling python scripts.
#                 It then store the pdf files into HDFS and wirte the parsed csv data into Hive table(s) in data lake.
#  Author       : Liping Zhang
#
#############################################################################################################################################################

#!/bin/bash
script=`basename "$0"`
DATETIME=`date '+%y%m%d_%H%M%S'`
year_month_cur=`date '+%Y-%m'`
year_month_pre=`date -d 'last month' '+%Y-%m'`

############################################## This section controls all local paths, local file names, and hdfs dir ########################################################
app_dir=/data/CTL/ingest/q2b_qtcpdf
source ${app_dir}/config/config.properties

local_pdf_dir=${app_dir}/pdf
err_pdf_dir=${app_dir}/err_pdf
err_pdf_dir_inv=${app_dir}/err_pdf_investigate
local_data_dir=${app_dir}/data
local_archive_dir=${app_dir}/archive
config_dir=${app_dir}/config
impala_sql_dir=${app_dir}/impala
merge_pdf_file=$app_dir/script/pdf_merge.sh

script_log_dir=${app_dir}/log/script_log
python_code_dir=${app_dir}/python_code

hdfs_ensarc_dir=/data/CTL/encrypt/db/ingest/raw/ensarc
hdfs_pdf_dir=${hdfs_ensarc_dir}/quote_pdf_file
hdfs_csv_dir=${hdfs_ensarc_dir}/src_quote_pdf_csv

log=${script_log_dir}/${script}_${DATETIME}.log

#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
check_status () {
    lastCommandStatus=$?
        echo "Exit status from last command '$1' - $lastCommandStatus" >> ${log}
  if [ $lastCommandStatus -ne 0 ]; then
     err_msg="Error occurred in ${script}, in step: $1. please check the log in ${log}"
     subject_msg="${script} FAILED During Execution"
     echo "$subject_msg" >> ${log}
     echo "$err_msg" >> ${log}
     mail -s "$subject_msg"  ${Email_List} <<< "$err_msg"
     sleep 10s

     cat ${log}
     exit 1
  fi
}


#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
check_status_nolog () {
    lastCommandStatus=$?
  if [ $lastCommandStatus -ne 0 ]; then
     echo "Exit status from last command '$1' - $lastCommandStatus" >> ${log}
     err_msg="Error occurred in ${script}, in step: $1. please check the log in ${log}"
     subject_msg="${script} FAILED During Execution"
     echo "$subject_msg" >> ${log}
     echo "$err_msg" >> ${log}
     mail -s "$subject_msg"  ${Email_List} <<< "$err_msg"
     sleep 10s

     cat ${log}
     exit 1
  fi
}


#-----------------------------------------------------------------
# Function to send the appropriate email message
#-----------------------------------------------------------------
send_email () {
    lastCommandStatus=$?
        echo "Exit status from last command '$1' - $lastCommandStatus" >> ${log}
  sub=$1
  msg=$2
     echo "$sub" >> ${log}
     echo "$msg" >> ${log}
     mail -s "$sub"  ${Email_List} <<< "$msg"
     sleep 10s
}

#-----------------------------------------------------------------
# Function to check the return status and move the pdf files if status not 0
#-----------------------------------------------------------------
check_status_move_file () {
    lastCommandStatus=$?
  if [ $lastCommandStatus -ne 0 ]; then
     echo "status from last command '$1' - $lastCommandStatus" >> ${log}
     err_msg="cannot parse PDF file, move file ${pdf_file_name} to ${err_pdf_dir}."
     echo "$err_msg" >> ${log}
     mv ${pdf_file} ${err_pdf_dir}/
  fi
}



######################################## cleanup data files from previous execution ###################################################

rm -f ${local_data_dir}/*.txt ${local_data_dir}/*.csv ${local_data_dir}/*.txttemp

#cd ${local_data_dir}

#find . -name '*.csv'| xargs rm
#find . -name '*.txt'| xargs rm
#find . -name '*.txttemp'| xargs rm

check_status "rm -f ${local_data_dir}/*.txt ${local_data_dir}/*.csv ${local_data_dir}/*.txttemp"
rm -f ${local_archive_dir}/*.pdf
check_status "rm -f ${local_archive_dir}/*.pdf"



cd ${err_pdf_dir}
num_of_err_pdf="$(ls -1 | wc -l)"
if [ $num_of_err_pdf -ne 0 ]
then
    echo "Move previous errored pdf files from ${err_pdf_dir} to ${err_pdf_dir_inv}" >> ${log}
    mv -f ${err_pdf_dir}/*.pdf ${err_pdf_dir_inv}/
    check_status "mv -f ${err_pdf_dir}/*.pdf ${err_pdf_dir_inv}/"
fi

echo "Starting execution of ${script} @ ${DATETIME}" > ${log}



####################################### process PDF files ###############################################

cd ${local_pdf_dir}
num_of_pdf="$(ls -1 | wc -l)"
if [ $num_of_pdf -eq 0 ]
then
  send_email "${script}" "NO PDF file to process, please check ${local_pdf_dir} and the prerequisite job."
  exit 0
fi


part_name="gen_year_month=${year_month_cur}"
hdfs_pdf_part_dir=${hdfs_pdf_dir}/${part_name}
hdfs dfs -test -d ${hdfs_pdf_part_dir}
if [ $? != 0 ]; then
    hdfs dfs -mkdir -p ${hdfs_pdf_part_dir}
fi


pdf_files=${local_pdf_dir}/*.pdf

csv_file_name=quote_${DATETIME}.csv
csv_file=${local_data_dir}/quote_${DATETIME}.csv
touch ${csv_file}
check_status "touch ${csv_file}"


echo "Start parsing PDF files ..." >> ${log}
for pdf_file in ${pdf_files} ; do

    pdf_file_name=`basename ${pdf_file}`

    text_file=${local_data_dir}/${pdf_file_name%.*}.txt
    ${python_code_dir}/pdf2txt.py -A -F +1.0  -M 100 -L 0.5 -o ${text_file} ${pdf_file}
    check_status_nolog "${python_code_dir}/pdf2txt.py -A -F +1.0  -M 100 -L 0.5 -o ${text_file} ${pdf_file}"

    pdf_parser_err=`${python_code_dir}/quotepdfparser.py ${text_file} ${csv_file} 2>&1`
    check_status_move_file "${python_code_dir}/quotepdfparser.py ${text_file} ${csv_file} 2>&1"
    if [ ! -z "${pdf_parser_err}" ]
    then
        echo "${pdf_parser_err}" >> ${log}
    fi

done


#load ${csv_file} into ensarc.quote_pdf_csv, final ensemble quote data table
hdfs dfs -rm -f ${hdfs_csv_dir}/*.csv
check_status "hdfs dfs -rm -f ${hdfs_csv_dir}/*.csv"
hdfs dfs -put -f ${csv_file} ${hdfs_csv_dir}
check_status "hdfs dfs -put -f ${csv_file} ${hdfs_csv_dir}"

impala_stg_log=`impala-shell -k --ssl -i ${impala_server} -B -f ${impala_sql_dir}/stage_table.sql 2>&1`
check_status "impala-shell -k --ssl -i ${impala_server} -B -f ${impala_sql_dir}/stage_table.sql 2>&1"
echo "${impala_stg_log}" >> ${log}

impala_ins_log=`impala-shell -k --ssl -i ${impala_server} -B -f ${impala_sql_dir}/insert_into_final.sql 2>&1`
check_status "impala-shell -k --ssl -i ${impala_server} -B -f ${impala_sql_dir}/insert_into_final.sql 2>&1"
echo "${impala_ins_log}" >> ${log}


echo "Start loading PDF files into HDFS ..." >> ${log}

cd ${local_pdf_dir}
if [ -n "$(find . -name "*${year_month_pre}*" | head -1)" ]
then
    part_pre="gen_year_month=${year_month_pre}"
    hdfs dfs -put -f ${local_pdf_dir}/*${year_month_pre}*.pdf  ${hdfs_pdf_dir}/${part_pre}
    check_status "hdfs dfs -put -f ${local_pdf_dir}/*${year_month_pre}*.pdf  ${hdfs_pdf_dir}/${part_pre}"
fi

if [ -n "$(find . -name "*${year_month_cur}*" | head -1)" ]
then
    part_cur="gen_year_month=${year_month_cur}"
    hdfs dfs -put -f ${local_pdf_dir}/*${year_month_cur}*.pdf  ${hdfs_pdf_dir}/${part_cur}
    check_status "hdfs dfs -put -f ${local_pdf_dir}/*${year_month_cur}*.pdf  ${hdfs_pdf_dir}/${part_cur}"
fi

echo "Running merge script :" >> ${log}
#### merge pdf files####
$merge_pdf_file
check_status "ksh $merge_pdf_file"

if [ -n "$(find . -name '*.pdf' | head -1)" ]
then
    mv -f ${local_pdf_dir}/*.pdf  ${local_archive_dir}
    check_status "mv -f ${local_pdf_dir}/*.pdf  ${local_archive_dir}"
fi

cat ${config_dir}/FH_quote_csv ${csv_file} > ${local_archive_dir}/${csv_file_name}
check_status "cat ${config_dir}/FH_quote_csv ${csv_file} > ${local_archive_dir}/${csv_file_name}"

rm ${csv_file}
check_status "rm ${csv_file}"

cd ${err_pdf_dir}
num_of_err_pdf="$(ls -1 | wc -l)"
if [ $num_of_err_pdf -ne 0 ]
then
  send_email "${script}" "${num_of_err_pdf} PDF files cannot be parsed, please investigate. Files can be found at ${err_pdf_dir} or ${err_pdf_dir_inv}. "
fi


echo "${script} completed succesfully." >> ${log}
cat ${log}
exit 0
