#!/bin/bash
###############################################################################
# Author : Srivatsa K Nagaraja
# Date  :  08/09/2019
#
#################################################################################

script=`basename "$0"| cut -d "." -f 1`
DATETIME=`date '+%y%m%d_%H%M%S'`
app_dir='/data/CTL/ingest/lvcht_interaction/scripts'
log_dir='/data/CTL/ingest/lvcht_interaction/logs'
log_file=${log_dir}/${script}_${DATETIME}.log
txt_file='/data/CTL/ingest/lvcht_interaction/config/last_ext_date.txt'
config_dir='/data/CTL/ingest/lvcht_interaction/config/'

#-----------------------------------------------------------------
# Function to log
#-----------------------------------------------------------------
function printMsg ()
{
  echo "<${DATETIME}>: $@" >> ${log_file}
  echo "<${DATETIME}>: $@"
  return
}

#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
function sendEmail ()
{
    EMAIL_SUB="CDH_PROD_${script}_failed_@_${DATETIME}"
   # EMAIL_ID="ab09507@centurylink.com"
    EMAIL_ID="IT-DATALAKE-DEV@centurylink.com"
    echo "Failed Processing: Please check log file for further details." | mail -s ${EMAIL_SUB} -a ${log_file} ${EMAIL_ID}
    sleep 1s
    return
}

function sendMailToUsers ()
{
    EMAIL_SUB="CDH_PROD_Interactions_Data_Mismatch"
#    EMAIL_ID="ab09507@centurylink.com"
    EMAIL_ID="IT-DATALAKE-DEV@centurylink.com, Jeffrey.S.Halbrook@centurylink.com , Jose.Longoria@CenturyLink.com "
    printf "Hi All,\n\nData validation failed for $validation_date\n\nAPI counts: $api_count\nDatalake counts :$impala_count\n\nPlease check if data load is completed for $validation_date parm_date.\nNeed to check the data if there are any count mismactch after data load is complete.\n\nHappy Data Validation..!\n" | mail -s ${EMAIL_SUB} ${EMAIL_ID}
    sleep 1s
    exit 1;
}

#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
function check_status()
{
    lastCommandStatus=$?

  if [ $lastCommandStatus -ne 0 ]; then
     printMsg $1
         printMsg "FAILED"
         echo "Script FAILED"
     sendEmail
     exit 1
  else
          printMsg $1
          printMsg "Command Successful."
          sleep 1s
          return
  fi
}


current_date=`date +'%m/%d/%Y'`
#p_date=`date -d $1 +'%m/%d/%Y'`
p_date=$(date -d "$current_date -1 days" +"%Y%m%d")
validation_date=$(date -d "$p_date -1 days" +"%Y%m%d")
#echo "Previous date:$p_date"
t_epoc=$(TZ="UTC" date -d $p_date +"%s")
end_time=$t_epoc'000'
tmp_date=$(TZ="UTC" date -d"$(date -d @$t_epoc) -24 hours" +'%Y-%m-%d %H:%M:%S')
start_time1=`date -d "$tmp_date UTC" +%s`
start_time=$start_time1'000'
echo "Previous date:$tmp_date"

RANDOM_NUMBER=$(shuf -i 11-20 -n 1)
echo $RANDOM_NUMBER

impala_host=polpcdhdn0$RANDOM_NUMBER.corp.intranet
echo $impala_host

api_count=$(/opt/tools/python/bin/python $app_dir/lvcht_interactions_data_validate.py $start_time $end_time)
check_status "/opt/tools/python/bin/python $app_dir/lvcht_interactions_data_validate.py $start_time $end_time"

echo ${api_count}

impala_count=$(impala-shell -k --ssl -i $impala_host -B -q "select count(*) from lvcht.interaction_info where starttimel >= $start_time and starttimel < $end_time" 2>1)
check_status "impala-shell -k --ssl -i ${impala_host} -B -q 'select count(*) from lvcht.interaction_info where starttimel >= $start_time and starttimel < $end_time'"

echo "Impala count : $impala_count"
echo "api_count : $api_count"

if [ $impala_count -ne $api_count ] ; then
        printf "Data validation failed for $p_date\n\nAPI counts: $api_count\nDatalake counts :$impala_count\n\nPlease check if data load is completed for $p_date parm_date.\nNeed to check the data if there are any count mismactch after data load is complete.\n\nHappy Data Validation..!\n" >> ${log_file}
        sendMailToUsers;
else
        printMsg "Data validation completed"
fi
