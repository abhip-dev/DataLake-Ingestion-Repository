import sys
import pyspark
from pyspark import SparkContext
from pyspark.sql.functions import *
from pyspark.sql import HiveContext

sqlContext = HiveContext(pyspark.SparkContext())
#sc =SparkContext()
from pyspark.sql import SQLContext
#sqlContext = SQLContext(sc)

import pyspark.sql.functions as f
sqlContext.setConf("hive.exec.dynamic.partition", "true")
sqlContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict")
sqlContext.setConf("mapred.output.compression.codec", "org.apache.hadoop.io.compress.SnappyCodec") 

location="/data/CTL/encrypt/db/ingest/raw/asl_mes/"
databasename_list = sqlContext.read.text("/data/CTL/data/ingest/test3/databasename.txt").rdd.flatMap(lambda x: x).collect()
tablename_list = sqlContext.read.text("/data/CTL/data/ingest/test3/tablename1.txt").rdd.flatMap(lambda x: x).collect()

#databasename_list = sqlContext.read.text("/data/CTL/data/ingest/test3/databasename.txt").collect()
#tablename_list = sqlContext.read.text("/data/CTL/data/ingest/test3/tablename1.txt").collect()
ingest_db="asl_mes"

for tablename in tablename_list:
	count=0
	counter=0
	list_mismatchschema=[]
	for index in range(len(databasename_list)-1):                  
		df1 = sqlContext.sql("SELECT * FROM "+str(databasename_list[index])+"."+str(tablename)) 
		df2 = sqlContext.sql("SELECT * FROM "+str(databasename_list[index+1])+"."+str(tablename))
		schemadf1=df1.dtypes
		schemadf2=df2.dtypes
		k = schemadf1==schemadf2
		if k and counter==0:
			count=count+1
			if count==9:
				table=[tablename]
				print index
				index=index+1
				print index
				df1 = sqlContext.sql("SELECT * FROM "+databasename_list[index-9]+"."+tablename)
				df2 = sqlContext.sql("SELECT * FROM "+databasename_list[index-8]+"."+tablename)
				first_df=df1.unionAll(df2)
				for tableInAllDatabase in table:
					for dbname in range(len(databasename_list)-2):
						df3 = sqlContext.sql("SELECT * FROM "+databasename_list[dbname+2]+"."+tableInAllDatabase)
						first_df=first_df.unionAll(df3)
                
				first_df.write.mode("overwrite").format("parquet").option("compression", "snappy").saveAsTable(ingest_db+"."+str(tableInAllDatabase)+"_process")
				
				Table_exist= tableInAllDatabase in sqlContext.tableNames(ingest_db)
				if Table_exist is True:
					sqlContext.sql("DROP TABLE IF EXISTS "+ingest_db+"."+tableInAllDatabase)
					
				
				sqlContext.sql("ALTER TABLE "+ingest_db+"."+str(tableInAllDatabase)+"_process  RENAME to "+ingest_db+"."+str(tableInAllDatabase))
				
				

		else:
			counter=counter+1
			list_mismatchschema.extend([schemadf1,schemadf2])
			if index==8:
			
				def flatten(d): return {i for b in [[i] if not isinstance(i, list) else flatten(i) for i in d] for i in b} 
				z=list(flatten(list_mismatchschema))
				c_t=''
				c_t="sqlContext.sql(\"create external table "+ingest_db+"."+tablename+"_mismatch"+"("
				for i in z:
					c_t=c_t+i[0]+"  "+i[1]+" ,"
				c_t=c_t.rstrip(',')
				c_t=c_t+")STORED as PARQUET \" )"
				exec(c_t)
				
				
				
				df=sqlContext.sql("select * from "+ingest_db+"."+tablename+"_mismatch")
				final_tbl_cols=df.columns
				table=[tablename]
				
				
				
				for tableInAllDatabase in table:
					for dbname in range(len(databasename_list)-1):
						df4 = sqlContext.sql("SELECT * FROM "+databasename_list[dbname]+"."+tableInAllDatabase)
						src_tbl_cols=df4.columns
						extra_cols = list(set(final_tbl_cols) - set(src_tbl_cols))
						to_be_written_df = reduce(lambda temp_df, col_name: temp_df.withColumn(col_name, f.lit('NULL')), extra_cols, df4)
						to_be_written_df.write.format("parquet").mode("append").saveAsTable(ingest_db+"."+str(tableInAllDatabase)+"_process")
						
				Table_exist= table in sqlContext.tableNames(ingest_db)
				if Table_exist is True:
					sqlContext.sql("DROP TABLE IF EXISTS "+ingest_db+"."+tableInAllDatabase)
					
					
				sqlContext.sql("ALTER TABLE "+ingest_db+"."+str(tableInAllDatabase)+"_process  RENAME to "+ingest_db+"."+str(tableInAllDatabase))
				
				sqlContext.sql("DROP TABLE IF EXISTS "+ingest_db+"."+tablename+"_mismatch")
