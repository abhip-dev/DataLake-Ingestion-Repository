##################################################################################################################################
#  Script Shell : bash
#  Script       : asl_intrado_ingest.sh
#  Description  : The script process all the incoming intrado files on /sftp/asl_intrado/incoming/ directory(For More Information See CR7608)
#  Author       : AC38815 - Kumar Abhishek
##################################################################################################################################

#!/bin/sh
kinit -kt /home/cdlapp/cdlapp.keytab cdlapp@CTL.INTRANET

script=`basename "$0"| cut -d "." -f1`
DATETIME=`date '+%Y%m%d_%H%M%S'`
curr_year=`date '+%Y'`
flag=notFound

#-----------------------------------------------------------------
# This section controls all local paths and file names
#-----------------------------------------------------------------
home_dir=/data/CTL/ingest
landing_dir=/sftp/intrdcdl/incoming
log_dir=${home_dir}/asl_intrado/log
archive_dir=${home_dir}/asl_intrado/archive
staging_dir=${home_dir}/asl_intrado/staging
duplicate_files_dir=${home_dir}/asl_intrado/duplicate_files
log=${log_dir}/${script}_${DATETIME}.log
echo "Access the log file here: "${log}

#-----------------------------------------------------------------
# Final Table HDFS Directory(to keep the history file)
#-----------------------------------------------------------------
hdfs_home_dir=/data/CTL/encrypt/db/ingest/raw

#-----------------------------------------------------------------
# HDFS Processed Directory(to keep all files as backup)
#-----------------------------------------------------------------
hdfs_processed_dir=/data/CTL/encrypt/data/ingest/processed/asl_intrado/${curr_year}
hdfs dfs -test -d ${hdfs_processed_dir}
if [ $? != 0 ]; then
    hdfs dfs -mkdir -p ${hdfs_processed_dir}
fi

#-----------------------------------------------------------------
# Setting Variables to support sendEmail functionality
#-----------------------------------------------------------------
EMAIL_SUB="${script}_failed_@_${DATETIME}"
EMAIL_ID="IT-DATALAKE-DEV@centurylink.com"
#EMAIL_ID="abhishek.kumar2@centurylink.com"

#-----------------------------------------------------------------
# Function to append messages in log files.
#-----------------------------------------------------------------
function printMsg ()
{
        echo "<`date '+%Y%m%d_%H%M%S'`>: $@" >> ${log}
        return
}

#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
function sendEmail()
{
        echo "Failed Processing: Please check log file for further details." | mail -s ${EMAIL_SUB} -a ${log} ${EMAIL_ID}
        sleep 10s
        return
}

#-----------------------------------------------------------------
# Function to check the status and send the appropriate email message
#-----------------------------------------------------------------
function check_status()
{
        lastCommandStatus=$?
        printMsg "Exit status from last command '$1' - $lastCommandStatus"
        if [ $lastCommandStatus -ne 0 ]; then
                printMsg "Error occurred in ${script} in step: $1"
                printMsg "SCRIPT Execution FAILED"
                sendEmail;
                exit 1
        fi
}

# -----------------------------------------------------------------
# Find log files older than 30 days to be purged
# -----------------------------------------------------------------
function purgeLogs()
{
        printMsg "Log files older than 30 days"
        cd ${log_dir}
        logfileCount=$(find *.log -mtime +30 | wc -l)

        if [ ${logfileCount} -ne 0 ]; then
                printMsg "Number of log files older than 30 days:" ${logfileCount}
                find *.log -mtime +30 -exec rm {} \;
                check_status "find *.log -mtime +30 -exec rm {} \;"
                printMsg "${logfileCount} Log files purged"
        else
                printMsg "No log file older than 30 days."
        fi
}

# -----------------------------------------------------------------
# Find Archive files older than 60 days to be purged
# -----------------------------------------------------------------
function purgeArchive()
{
        printMsg "Archive files older than 60 days"
        cd ${archive_dir}
        ArchivefileCount=$(find * -mtime +60 | wc -l)

        if [ ${ArchivefileCount} -ne 0 ]; then
                printMsg "Number of Archive files older than 60 days:" ${ArchivefileCount}
                find * -mtime +60 -exec rm {} \;
                check_status "find * -mtime +60 -exec rm {} \;"
                printMsg "${ArchivefileCount} files purged"
        else
                printMsg "No Archive file older than 60 days."
        fi
}

echo "Starting execution of ${script} @ ${DATETIME}" >> ${log}
echo ${log}
printMsg "================================================================="

#-----------------------------------------------------------------
# Clearing all the processed files from staging directory if present
# File count under staging dir should be 0.
#-----------------------------------------------------------------
STG_FILE_CNT=$(find ${staging_dir}/* -printf "%f\n" | wc -l)
printMsg "Number of Files not processed for previous day/run is : "${STG_FILE_CNT}

#-----------------------------------------------------------------
# Removing Files from HDFS Directory before creating stage Hive table
#-----------------------------------------------------------------
printMsg "Clearing files from HDFS work Directory: ${hdfs_home_dir}/asl_intrado/work/"
if hdfs dfs -test -f ${hdfs_home_dir}/asl_intrado/work/src_decc/*;
then
        hdfs dfs -rm ${hdfs_home_dir}/asl_intrado/work/src_decc/*
        check_status "hdfs dfs -rm ${hdfs_home_dir}/asl_intrado/work/src_decc/*"
fi

if hdfs dfs -test -f ${hdfs_home_dir}/asl_intrado/work/src_lnp/*;
then
        hdfs dfs -rm ${hdfs_home_dir}/asl_intrado/work/src_lnp/*
        check_status "hdfs dfs -rm ${hdfs_home_dir}/asl_intrado/work/src_lnp/*"
fi

if hdfs dfs -test -f ${hdfs_home_dir}/asl_intrado/work/src_ref/*;
then
        hdfs dfs -rm ${hdfs_home_dir}/asl_intrado/work/src_ref/*
        check_status "hdfs dfs -rm ${hdfs_home_dir}/asl_intrado/work/src_ref/*"
fi

if hdfs dfs -test -f ${hdfs_home_dir}/asl_intrado/work/src_oe/*;
then
        hdfs dfs -rm ${hdfs_home_dir}/asl_intrado/work/src_oe/*
        check_status "hdfs dfs -rm ${hdfs_home_dir}/asl_intrado/work/src_oe/*"
fi

if hdfs dfs -test -f ${hdfs_home_dir}/asl_intrado/work/src_v911_inventory/*;
then
        hdfs dfs -rm ${hdfs_home_dir}/asl_intrado/work/src_v911_inventory/*
        check_status "hdfs dfs -rm ${hdfs_home_dir}/asl_intrado/work/src_v911_inventory/*"
fi

if hdfs dfs -test -f ${hdfs_home_dir}/asl_intrado/work/src_v911_error/*;
then
        hdfs dfs -rm ${hdfs_home_dir}/asl_intrado/work/src_v911_error/*
        check_status "hdfs dfs -rm ${hdfs_home_dir}/asl_intrado/work/src_v911_error/*"
fi


#-----------------------------------------------------------------
# This part of script executes daily to validate and process intrado west File,
# Also move all the files from landing dir to staging directory to load hive table.
#-----------------------------------------------------------------

TOT_FILE_CNT=$(find ${landing_dir}/* -printf "%f\n" | wc -l)
printMsg "Total Number of Files to be processed: "${TOT_FILE_CNT}
if [ ${TOT_FILE_CNT} -ne 0 ];
then
        #listing all the files in landing directory
        ls ${landing_dir}/* | cut -d "/" -f5 | while read fileName;
        do
                printMsg "Check if file ${fileName} is already ingested"
                hdfs dfs -test -e ${hdfs_processed_dir}/${fileName}
                if [ $? -eq 0 ]
                then
                                printMsg "${fileName} is already ingested, Thus moving it to duplicate_files directory: ${duplicate_files_dir}"
                                mv ${landing_dir}/${fileName} ${duplicate_files_dir}/
                                printMsg "================================================================="
                                continue

                fi

                printMsg "================================================================="
                printMsg "Begin processing file : ${fileName}"
                fileName_SIZE=$(stat -c%s "${landing_dir}/${fileName}")

                if [ ${fileName_SIZE} -ne 0 ]
                then

                                if [[ ${fileName} == D* ]];
                                then
                                        #Moving the intrado/west files to HDFS
                                        printMsg "moving ${fileName} to HDFS directory ${hdfs_home_dir}/asl_intrado/work/src_decc : "${fileName}
                                        hdfs dfs -put -f ${landing_dir}/${fileName} ${hdfs_home_dir}/asl_intrado/work/src_decc/
                                        #check_status "hdfs dfs -put -f ${landing_dir}/${fileName} ${hdfs_home_dir}/asl_intrado/work/src_decc/"
                                        if [[ $? != 0 ]]; then
                                                sendEmail
                                                flag=error
                                                break;
                                        fi

                                elif [[ ${fileName} == L* ]];
                                then
                                        #Moving the intrado/west files to HDFS
                                        printMsg "moving ${fileName} to HDFS directory ${hdfs_home_dir}/asl_intrado/work/src_lnp : "${fileName}
                                        hdfs dfs -put -f ${landing_dir}/${fileName} ${hdfs_home_dir}/asl_intrado/work/src_lnp/
                                        #check_status "hdfs dfs -put -f ${landing_dir}/${fileName} ${hdfs_home_dir}/asl_intrado/work/src_lnp/"
                                        if [[ $? -ne 0 ]]; then
                                                sendEmail
                                                flag=error
                                                break;
                                        fi

                                elif [[ ${fileName} == R* ]];
                                then
                                        #Moving the intrado/west files to HDFS
                                        printMsg "moving ${fileName} to HDFS directory ${hdfs_home_dir}/asl_intrado/work/src_ref : "${fileName}
                                        hdfs dfs -put -f ${landing_dir}/${fileName} ${hdfs_home_dir}/asl_intrado/work/src_ref/
                                        #check_status "hdfs dfs -put -f ${landing_dir}/${fileName} ${hdfs_home_dir}/asl_intrado/work/src_ref/"
                                        if [[ $? -ne 0 ]]; then
                                                sendEmail
                                                flag=error
                                                break;
                                        fi

                                elif [[ ${fileName} == O* ]];
                                then
                                        #Moving the intrado/west files to HDFS
                                        printMsg "moving ${fileName} to HDFS directory ${hdfs_home_dir}/asl_intrado/work/src_oe : "${fileName}
                                        hdfs dfs -put -f ${landing_dir}/${fileName} ${hdfs_home_dir}/asl_intrado/work/src_oe/
                                        #check_status "hdfs dfs -put -f ${landing_dir}/${fileName} ${hdfs_home_dir}/asl_intrado/work/src_oe/"
                                        if [[ $? -ne 0 ]]; then
                                                sendEmail
                                                flag=error
                                                break;
                                        fi

                                elif [[ ${fileName} == VOIP_SEMI_DELIMITED_TN* ]];
                                then
                                        #Moving the intrado/west files to HDFS
                                        printMsg "moving ${fileName} to HDFS directory ${hdfs_home_dir}/asl_intrado/work/src_v911_inventory : "${fileName}
                                        hdfs dfs -put -f ${landing_dir}/${fileName} ${hdfs_home_dir}/asl_intrado/work/src_v911_inventory/
                                        #check_status "hdfs dfs -put -f ${landing_dir}/${fileName} ${hdfs_home_dir}/asl_intrado/work/src_v911_inventory/"
                                        if [[ $? -ne 0 ]]; then
                                                sendEmail
                                                flag=error
                                                break;
                                        fi

                                elif [[ ${fileName} == VOIP_SEMI_DELIMITED_ERROR* ]];
                                then
                                        #Moving the intrado/west files to HDFS
                                        printMsg "moving ${fileName} to HDFS directory ${hdfs_home_dir}/asl_intrado/work/src_v911_error : "${fileName}
                                        hdfs dfs -put -f ${landing_dir}/${fileName} ${hdfs_home_dir}/asl_intrado/work/src_v911_error/
                                        #check_status "hdfs dfs -put -f ${landing_dir}/${fileName} ${hdfs_home_dir}/asl_intrado/work/src_v911_error/"
                                        if [[ $? -ne 0 ]]; then
                                                sendEmail
                                                flag=error
                                                break;
                                        fi

                                else
                                        printMsg "${fileName} is not expected, Moving it to archive directory: "${fileName}
                                        #move the file to archive dir##
                                        mv ${landing_dir}/${fileName} ${archive_dir}/
                                fi

                else

                        printMsg "${fileName} is of 0 Byte, Moving it to archive directory: "${fileName}
                        #move the data files to archive dir##
                        mv ${landing_dir}/${fileName} ${archive_dir}/
                        printMsg "Moved file ${fileName} to HDFS Processed Directory : "${fileName}
                        hdfs dfs -put ${archive_dir}/${fileName} ${hdfs_processed_dir}/
                        #check_status "hdfs dfs -put ${archive_dir}/${fileName} ${hdfs_processed_dir}/"
                        if [[ $? -ne 0 ]]; then
                            sendEmail
                            flag=error
                            break;
                        fi

                fi

                #Move file from landing directory to data directory
                printMsg "Moved file ${fileName} to ${staging_dir} directory: "${fileName}
                mv ${landing_dir}/${fileName} ${staging_dir}/

        done

        if [ ${flag} = "error" ];
        then
                exit 1;
        fi
fi

printMsg "================================================================="
# -----------------------------------------------------------------
# Purging Old Archive files older than 60 days
# -----------------------------------------------------------------
purgeArchive

printMsg "================================================================="
# -----------------------------------------------------------------
# Purging Old Log files older than 30 days
# -----------------------------------------------------------------
purgeLogs


printMsg "All the Incoming Files landed under ${landing_dir} has been processed for Date: " ${DATETIME}
printMsg "Script Processing Completed for Date: " ${DATETIME}
exit 0;
