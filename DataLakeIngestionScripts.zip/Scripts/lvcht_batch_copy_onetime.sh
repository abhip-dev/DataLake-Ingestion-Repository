
#!/bin/bash
export PATH=/opt/cloudera/parcels/Anaconda/bin:$PATH

script=`basename "$0"| cut -d "." -f1`
DATETIME=`date '+%y%m%d_%H%M%S'`
#home_dir=/data/CTL/ingest
home_dir=/data/CTL/ingest
# TABLE_NAME=$1
typeset -i START_DATE=$1
typeset -i END_DATE=$2
if [ -z ${START_DATE} ];
then
        echo "Table name is NULL"
        echo "Invalid. Pass table name and date as input variable"
        echo "Example: lvcht_file_ingest.sh TABLE_NAME YYYYMMDD YYYYMMDD"
        exit 1
fi

if [ -z ${END_DATE} ];
then
        echo "Table name is NULL"
        echo "Invalid. Pass table name and date as input variable"
        echo "Example: lvcht_file_ingest.sh TABLE_NAME YYYYMMDD YYYYMMDD"
        exit 1
fi

#-----------------------------------------------------------------
# The incoming directory
#-----------------------------------------------------------------
incoming_data_dir=${home_dir}/lvcht/archive
copy_data_dir=/sftp/lvchtcdl/incoming

#-----------------------------------------------------------------
#This section controls all local paths, local file names, and hdfs dir
#-----------------------------------------------------------------
script_dir=${home_dir}/lvcht/script
archive_dir=${home_dir}/lvcht/archive
staging_dir=${home_dir}/lvcht/staging
script_log_dir=${home_dir}/lvcht/log
config_dir=${home_dir}/lvcht/config
temp_dir=${home_dir}/lvcht/temp

# hdfsDirName=${TABLE_NAME}
hdfs_dir=/data/CTL/encrypt/db/ingest/raw/lvcht

typeset -i EPOCH_START_TIME

echo "<"$DATETIME"> "$START_DATE $END_DATE > ${home_dir}/lvcht/log/"onetime_prod_copy_${START_TIME}_${END_TIME}"_$DATETIME.log

#-----------------------------------------------------------------
# Look for .gz files and .tag files for given month
#-----------------------------------------------------------------
fileCount=$(find ${incoming_data_dir}/*.gz | wc -l)

if [ ${fileCount} -ne 0 ];
then
  ls -t ${incoming_data_dir}/*.gz | while read gz_file
  do
                 epoch_start_date=$(echo ${gz_file}| cut -d "/" -f7 | sort -t "." -k2 | cut -d "." -f2 | cut -c1-10 | sort)
                 file_date=$(date -d @${epoch_start_date} +"%Y%m%d")
                 echo ${file_date}
                 if [[ "${file_date}" -lt ${END_DATE} && "${file_date}" -ge ${START_DATE} ]] ;
                 then
                         echo "copy ${gz_file}"
                         cp ${gz_file} ${copy_data_dir}
                 fi
         done

        ls -t ${incoming_data_dir}/*.tag | while read tag_file
        do
                epoch_start_date=$(echo ${tag_file}| cut -d "/" -f5 | sort -t "_" -k2 | cut -d "_" -f2 | cut -c1-10)
                # echo ${gz_file} + ${epoch_start_date}
                file_date=$(date -d @${epoch_start_date} +"%Y%m%d")
                if [[ "${file_date}" -lt ${END_DATE} && "${file_date}" -ge ${START_DATE} ]] ;
                then
                        echo "copy ${tag_file}"
                        cp ${tag_file} ${copy_data_dir}
                fi
        done
fi
exit 0
