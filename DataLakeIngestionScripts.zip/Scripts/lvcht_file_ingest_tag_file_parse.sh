#############################################################################################################################################################
#  Script Shell : bash
#  Script       : lvcht_file_ingest_tag_file_parse.sh
#  Authors              : Pasupathy, Satish
#
#  Description  : US236827: CR7186 Speech Analytics - Ingest Redacted Livechat Chat Logs into Data Lake
#                                 The script will process live chat files into the hdfs
#  10/01/2018, SPASUPA: convert the JSON text files into AVRO binary.
#                       process files in the tag file.
#                                               process files prior to tag file.
#  11/15/2018, SPASUPA: This script will only look at tag files, and then make sure we have the associated files.
#                                               If file is missing, it will send an API request
#
#############################################################################################################################################################
#!/bin/bash
export PATH=/opt/cloudera/parcels/Anaconda/bin:$PATH
kinit -kt /home/cdlapp/cdlapp.keytab cdlapp@CTL.INTRANET

script=`basename "$0"| cut -d "." -f 1`
DATETIME=`date '+%y%m%d_%H%M%S'`
home_dir=/data/CTL/ingest
TABLE_NAME=$1

        if [ -z ${TABLE_NAME} ]
        then
        echo "Table name is NULL"
        echo "Invalid. Pass table name as input variable"
        echo "Example: lvcht_file_ingest.sh TABLE_NAME"
        exit 1
        fi
#-----------------------------------------------------------------
# The incoming directory
#-----------------------------------------------------------------
incoming_data_dir=/sftp/lvchtcdl/incoming

#-----------------------------------------------------------------
# endPointUrl
#-----------------------------------------------------------------
endPointUrl=https://cxg7i.corp.intranet/rest/liveEngage

#-----------------------------------------------------------------
#This section controls all local paths, local file names, and hdfs dir
#-----------------------------------------------------------------
script_dir=${home_dir}/lvcht/script
archive_dir=${home_dir}/lvcht/archive
staging_dir=${home_dir}/lvcht/staging
script_log_dir=${home_dir}/lvcht/log
config_dir=${home_dir}/lvcht/config
temp_dir=${home_dir}/lvcht/temp


log_file=${script_log_dir}/${script}_${DATETIME}_${TABLE_NAME}.log
echo "Access the log file here: "${log_file}

#-----------------------------------------------------------------
# Function to log
#-----------------------------------------------------------------
function printMsg ()
{
  echo "<${DATETIME}>: $@" >> ${log_file}
  echo "<${DATETIME}>: $@"
  return
}

#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
function sendEmail ()
{
        EMAIL_SUB="CDH_DEV_${script}_failed_@_${DATETIME}"
    EMAIL_ID="spasupa@centurylink.com"
        # EMAIL_ID="IT-DATALAKE-DEV@centurylink.com"
    echo "Failed Processing: Please check log file for further details." | mail -s ${EMAIL_SUB} -a ${log_file} ${EMAIL_ID}
    sleep 1s
        return
}

#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
function check_status()
{
    lastCommandStatus=$?

  if [ $lastCommandStatus -ne 0 ]; then
     printMsg $1
         printMsg "FAILED"
         echo "Script FAILED"
     sendEmail
     exit 1
  else
          printMsg $1
          printMsg "Command Successful."
          sleep 1s
          return
  fi

}

# -----------------------------------------------------------------
# Find log files to be purged
# Input: number if days to retain logs
# -----------------------------------------------------------------
function purgeLogs()
{
printMsg "Log files older than 30 days"
cd ${script_log_dir}
logfileCount=$(find ${script}_file*${TABLE_NAME}*.log -mtime +30 | wc -l)

if [ ${logfileCount} -ne 0 ]; then
        printMsg "Number of log files older than 30 days:" ${logfileCount}
        find *.log -mtime +30 -exec rm {} \;
        check_status "find ${script}_file*${TABLE_NAME}*.log -mtime +30 -exec rm {} \;"
        printMsg "${logfileCount} Logs purged"
        else
        printMsg "No log files older than 30 days."
        printMsg "End Script."
fi
}

printMsg "Start script execution:" ${script}

#-----------------------------------------------------------------
# Check for incoming files
#-----------------------------------------------------------------
printMsg "Incoming directory: "${incoming_data_dir}
fileCount=$(find ${incoming_data_dir}/${TABLE_NAME}*.tag | wc -l)

printMsg "Number of tag files:" ${fileCount}

#-----------------------------------------------------------------
# Remove all temp files
#-----------------------------------------------------------------
if [ ${fileCount} -ne 0 ];
then
#Clear the temp Directory
rm -f ${temp_dir}/${TABLE_NAME}*_MISSING_GZ_FILE_LIST.lst

        #-----------------------------------------------------------------
        # process JSON tag file and makes calls for missing GZ files
        #-----------------------------------------------------------------
        ls -l ${incoming_data_dir}/${TABLE_NAME}*.tag | cut -d "/" -f5 |sort -t "." -k2 | while read tag_file
        do
                printMsg "Begin processing tag file: "${tag_file}
                #Capturing all the valid gz files associated with tag_file and writing gz files name in VALID_GZ_FILE_LIST, writing all invalid gz files name in MISSING_GZ_FILE_LIST
                grep ".gz" ${incoming_data_dir}/${tag_file} | cut -d ":" -f2 | sed '1,$s/\"//g' | sed '1,$s/\,//g' | while read gz_file
                do
                        echo "${incoming_data_dir}/${gz_file}"
                        if [ ! -e ${incoming_data_dir}/${gz_file} ];
                        then
                        #writing all the invalid gz files associated to each tag file in MISSING_GZ_FILE_LIST
                        printMsg "Datafile not found: "${gz_file}
                        echo ${gz_file} >> ${temp_dir}/${TABLE_NAME}_MISSING_GZ_FILE_LIST.lst
                        fi
                done
        mv ${incoming_data_dir}/${tag_file} ${archive_dir}
        done
fi
