#!/opt/tools/python/bin python

import avro.schema
from avro.datafile import DataFileReader, DataFileWriter
from avro.io import DatumReader, DatumWriter
import json
import sys
import logging
from argparse import ArgumentParser
from datetime import datetime
import os


def main(argv=None):
        #Get script name
        script_name = "lvcht_Engagement.py"

        #Logging
        log_dir = '/data/CTL/ingest/lvcht/log/'
        timestamp = datetime.utcnow().strftime('%Y.%m.%d.%H.%M.%S')
        log_name = script_name+'_{}.log'.format(timestamp)
        log_file = os.path.join(log_dir, log_name)
        logging.basicConfig(filename=log_file,level=logging.DEBUG)
        logging.info("Starting script: "+script_name)


        #Path and files
        stage_avro_dir = '/data/CTL/ingest/lvcht/staging/avro/Engagement'


        #Clear the CSV Dir
        os.system('rm -rf %s/*' % '/data/CTL/ingest/lvcht/staging/CSV/EngagementTrans_src')
        os.system('rm -rf %s/*' % '/data/CTL/ingest/lvcht/staging/CSV/EngagementBase_src')

        for infile_name in os.listdir(stage_avro_dir):
                # Parse Arguments
                input_file = os.path.join(stage_avro_dir,infile_name)
                logging.info("Avro file being processed: "+input_file)

                schema = avro.schema.Parse(open("/data/CTL/ingest/lvcht/schema/livePerson.avsc").read())
                reader = DataFileReader(open(input_file, "rb"), DatumReader())

                #Process the engagement Transcripts data
                stage_csv_dir = '/data/CTL/ingest/lvcht/staging/CSV/EngagementTrans_src'
                logging.info("Processing EngagementTrans.")
                filepart = infile_name[-13:-5]
                outfile_name = "EngagementTrans_"+filepart+".csv"
                logging.info("csv file being processed: "+outfile_name)
                output_file =  os.path.join(stage_csv_dir,outfile_name)
                logging.info("csv out file: "+output_file)
                outFile = open(output_file,"w")

                for items in reader:
                        dataType = json.dumps(items['dataType'])
                        header =  json.dumps(list(items['recordCollection'][0]['body']['header'].values()),ensure_ascii=False)
                        metaData = json.dumps(list(items['metaData'].values()), ensure_ascii=False)
                        x = 0
                        while x < len(items['recordCollection'][0]['body']['engagements']):
                                y = 0
                                while y < len(items['recordCollection'][0]['body']['engagements'][x]['transcripts']):
                                        conversationId = json.dumps(items['recordCollection'][0]['body']['engagements'][x]['conversationId'])
                                        linkData = json.dumps(items['recordCollection'][0]['body']['engagements'][x]['transcripts'][y]['linkData'])
                                        messageId = json.dumps(items['recordCollection'][0]['body']['engagements'][x]['transcripts'][y]['messageId'])
                                        dialogId = json.dumps(items['recordCollection'][0]['body']['engagements'][x]['transcripts'][y]['dialogId'])
                                        contentFormat = json.dumps(items['recordCollection'][0]['body']['engagements'][x]['transcripts'][y]['contentFormat'])
                                        controlType = json.dumps(items['recordCollection'][0]['body']['engagements'][x]['transcripts'][y]['controlType'])
                                        timestamp = json.dumps(items['recordCollection'][0]['body']['engagements'][x]['transcripts'][y]['timestamp'])
                                        fileData = json.dumps(items['recordCollection'][0]['body']['engagements'][x]['transcripts'][y]['fileData'])
                                        agentId = json.dumps(items['recordCollection'][0]['body']['engagements'][x]['transcripts'][y]['agentId'])
                                        type = json.dumps(items['recordCollection'][0]['body']['engagements'][x]['transcripts'][y]['type'])
                                        by = json.dumps(items['recordCollection'][0]['body']['engagements'][x]['transcripts'][y]['by'], ensure_ascii=False)
                                        text = json.dumps(items['recordCollection'][0]['body']['engagements'][x]['transcripts'][y]['text'], ensure_ascii=False)
                                        y += 1
                                        outFile.write(dataType+','+header.strip("[]")+', '+metaData.strip("[]")+','+linkData+','+ messageId+','+ dialogId+','+ text.replace(","," ") +','+contentFormat+','+ controlType+','+ timestamp+','+ fileData+','+ agentId+','+ type+','+ by+', '+conversationId+', '+filepart+'\n')
                                        #outFile.write(dataType+','+header.strip("[]")+', '+metaData.strip("[]"))
                                x += 1
                logging.info("Complete extracting EngagementTrans")

                #Process the engagement base data
                schema = avro.schema.Parse(open("/data/CTL/ingest/lvcht/schema/livePerson.avsc").read())
                reader = DataFileReader(open(input_file, "rb"), DatumReader())

                logging.info("Processing EngagementBase.")
                #create output file to write the csv data
                stage_csv_dir = '/data/CTL/ingest/lvcht/staging/CSV/EngagementBase_src'
                outfile_name = "EngagementBase_"+filepart+".csv"
                logging.info("csv file being processed: "+outfile_name)
                output_file =  os.path.join(stage_csv_dir,outfile_name)
                logging.info("csv out file: "+output_file)
                outFile = open(output_file,"w")

                for items in reader:
                        dataType = json.dumps(items['dataType'])
                        header =  json.dumps(list(items['recordCollection'][0]['body']['header'].values()),ensure_ascii=False)
                        metaData = json.dumps(list(items['metaData'].values()),ensure_ascii=False)

                        x = 0
                        while x < len(items['recordCollection'][0]['body']['engagements']):
                                interactionStartTime = json.dumps(items['recordCollection'][0]['body']['engagements'][x] ['interactionStartTime'])
                                conversationId = json.dumps(items['recordCollection'][0]['body']['engagements'][x] ['conversationId'])
                                consumerId = json.dumps(items['recordCollection'][0]['body']['engagements'][x] ['consumerId'])
                                skillName = json.dumps(items['recordCollection'][0]['body']['engagements'][x] ['skillName'])
                                startPage = json.dumps(items['recordCollection'][0]['body']['engagements'][x] ['startPage'], ensure_ascii=False)
                                queueEndTime = json.dumps(items['recordCollection'][0]['body']['engagements'][x] ['queueEndTime'])
                                sourceOrigin = json.dumps(items['recordCollection'][0]['body']['engagements'][x] ['sourceOrigin'])
                                agentId = json.dumps(items['recordCollection'][0]['body']['engagements'][x] ['agentId'])
                                startUrl = json.dumps(items['recordCollection'][0]['body']['engagements'][x] ['startUrl'])
                                queueStartTime = json.dumps(items['recordCollection'][0]['body']['engagements'][x] ['queueStartTime'])
                                conversationEndTime = json.dumps(items['recordCollection'][0]['body']['engagements'][x] ['conversationEndTime'])
                                secureForms = json.dumps(items['recordCollection'][0]['body']['engagements'][x] ['secureForms'])
                                skillId = json.dumps(items['recordCollection'][0]['body']['engagements'][x]     ['skillId'])
                                type = json.dumps(items['recordCollection'][0]['body']['engagements'][x]['type'])
                                startReasonId = json.dumps(items['recordCollection'][0]['body']['engagements'][x]['startReasonId'])
                                endReasonId = json.dumps(items['recordCollection'][0]['body']['engagements'][x]['endReasonId'])
                                conversationStartTime = json.dumps(items['recordCollection'][0]['body']['engagements'][x]['conversationStartTime'])
                                sourceDevice = json.dumps(items['recordCollection'][0]['body']['engagements'][x]['sourceDevice'])
                                isInteractive = json.dumps(items['recordCollection'][0]['body']['engagements'][x]['isInteractive'])
                                x += 1
                        outFile.write(dataType+','+header.strip("[]")+', '+metaData.strip("[]")+','+interactionStartTime+','+conversationId+','+consumerId+','+skillName+','+startPage+','+queueEndTime+','+sourceOrigin+','+agentId+','+startUrl+','+queueStartTime+','+conversationEndTime +','+secureForms+','+skillId+','+type+','+startReasonId+','+endReasonId+','+conversationStartTime+','+sourceDevice+','+isInteractive+', '+filepart+'\n')
                outFile.close()
                logging.info("Complete extracting EngagementBase")



        logging.info("Script Complete.")

def parse_args(argv):
        """
        Parse command line options.
        """
        if argv is None:  # No arguments supplied. Likely called from terminal.
                argv = sys.argv
        parser = ArgumentParser(prog=argv[0], description='Process the live chat tag file for the table')
        parser.add_argument(
                'file_name',
                help='The file_name to process.'
        )
        args = vars(parser.parse_args(args=argv[1:]))
        file_name= args['file_name']
        return (file_name)

def create_output_file(output_dir, file_name):
        """
        Create the output file and directory.
        """
        # Create the directory if it does not exist
        if not os.path.exists(output_dir):
                os.makedirs(output_dir)

        # Make sure the directory is really a directory
        if not os.path.isdir(output_dir):
                print('ERROR: {} is not a directory.'.format(output_dir))
                sys.exit(2)

        # We want to generate a timestamp in the file name so multiple runs don't overwrite each other.
        timestamp = datetime.utcnow().strftime('%Y.%m.%d.%H.%M.%S')
        file_name = file_name+'_{}.csv'.format(timestamp)
        output_file = os.path.join(output_dir, file_name)

# Actually run the script if calling from the command line
if __name__ == '__main__':
        sys.exit(main())
