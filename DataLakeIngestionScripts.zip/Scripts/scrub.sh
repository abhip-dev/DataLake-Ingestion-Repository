  cat column_list | while read line
  do
    old_pattern=${line}
    new_pattern=`echo ${old_pattern} | sed 's/\./_/g'`
	cat merged_file_20190421 | sed s/$old_pattern/$new_pattern/g > temp_file
	if [ $? -ne 0 ]; then
	   echo "unable to replace pattern : $old_pattern" >> scrub.log
        else
           mv temp_file merged_file_20190421
	fi
  done
