#############################################################################################################################################################
#  Script Shell : bash
#  Script       : download_pdf.sh
#
#  Description  : The script gets the Ensemble quote pdf files from oracle ENSARC database.
#
#  Author       : Srivatsa K Nagaraja
#
#############################################################################################################################################################

#!/bin/bash
script=`basename "$0"`
DATETIME=`date '+%y%m%d_%H%M%S'`

export ORACLE_HOME=/opt/cloudera/parcels/ORACLE_INSTANT_CLIENT/instantclient_11_2
export LD_LIBRARY_PATH=$ORACLE_HOME
export PATH=/opt/tools/python/bin:$PATH:$HOME/.local/bin:$HOME/bin

######################################### This section controls all local paths and local file names ########################################################

app_dir=/data/CTL/ingest/q2b_qtcpdf

python_code_dir=${app_dir}/python_code
local_pdf_dir=${app_dir}/pdf

script_log_dir=${app_dir}/log/script_log
log=${script_log_dir}/${script}_${DATETIME}.log

send_email () {
  sub="${script} FAILED During Execution"
  msg="Error occurred in ${script}, please check the log in ${log}"
     echo "$sub" >> ${log}
     echo "$msg" >> ${log}
     mail -s "$sub"  IT-DATALAKE-ENG@centurylink.com  <<< "$msg"
}

echo "Beginning the execution" >> ${log}
echo "Calling python code blob_to_pdf.py" >> ${log}
$(python ${python_code_dir}/blob_to_pdf.py)

rt=$?

if [ ${rt} -ne 0 ]; then
        echo "Script failed with the error code ${rt}" >> ${log}
        send_email
        cat ${log}
        exit 1
else
        echo " Script completed successfully" >> ${log}
        cat ${log}
        exit 0
fi
