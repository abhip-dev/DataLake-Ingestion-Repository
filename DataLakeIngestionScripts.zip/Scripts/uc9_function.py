#*********************************************************************************************
# Program Name           : UC9_FUNCTION
# Shell Objective        : This code has all the definition used by UC9.
# Modfied    User     
# Date                Description
# MM/DD/YYYY         
# ---------- -------- ------------------------------------------------
# 04/12/2019 lalit joshi   Initial version
#=====================================================================================
#*********************************************************************************************

def assign_n_cast(Meta_DF,file_DF):
	
	 df1="final_DF=file_DF.select("

	 for x in Meta_DF.collect() :
	  if x['STRTG_POS_NO'] is not None or x['FLD_LGTH_NO'] is not None :
	   if x['MTDT_DA_TYP'] == 'Number' and x['NO_DA_TYP_SCL_QTY'] == 0:
		df1=df1+"file_DF.value.substr("+str(int(x['STRTG_POS_NO']))+","+str(int(x['FLD_LGTH_NO']))+").alias('"+x['FLD_NM']+"').cast(\"bigint\"),"
	   elif x['MTDT_DA_TYP'] == 'Number' and x['NO_DA_TYP_PRECN_QTY']<=15 and x['NO_DA_TYP_SCL_QTY'] >= 1:
		df1=df1+"file_DF.value.substr("+str(int(x['STRTG_POS_NO']))+","+str(int(x['FLD_LGTH_NO']))+").alias('"+x['FLD_NM']+"').cast(\"double\"),"
	   elif x['MTDT_DA_TYP'] == 'Number' and x['NO_DA_TYP_PRECN_QTY']>15 and x['NO_DA_TYP_SCL_QTY'] >= 1:
		df1=df1+"file_DF.value.substr("+str(int(x['STRTG_POS_NO']))+","+str(int(x['FLD_LGTH_NO']))+").alias('"+x['FLD_NM']+"').cast(\"decimal\"),"
	   else :
		df1=df1+"file_DF.value.substr("+str(int(x['STRTG_POS_NO']))+","+str(int(x['FLD_LGTH_NO']))+").alias('"+x['FLD_NM']+"'),"

	 df1=df1[:-1]+")"
	 exec(df1)
	 return final_DF



def create_hive_table(Meta_DF,HIVE_SCHEMA,HIVE_TABLE,db_dir,sqlContext):
	create_query="sqlContext.sql(\"CREATE  TABLE  "+ HIVE_SCHEMA+"."+HIVE_TABLE + "("

	for x in Meta_DF.collect() :
	  if x['STRTG_POS_NO'] is not None or x['FLD_LGTH_NO'] is not None :
	   if x['MTDT_DA_TYP'] == 'Number' and x['NO_DA_TYP_SCL_QTY'] == 0:
		#create_query=create_query+x['FLD_NM']+ " bigint ,"
                 create_query=create_query+'`'+x['FLD_NM']+'`'+ " bigint ,"
	   elif x['MTDT_DA_TYP'] == 'Number' and x['NO_DA_TYP_PRECN_QTY']<=15 and x['NO_DA_TYP_SCL_QTY'] >= 1:
		create_query=create_query+'`'+x['FLD_NM']+'`'+ " double ,"
	   elif x['MTDT_DA_TYP'] == 'Number' and x['NO_DA_TYP_PRECN_QTY']>15 and x['NO_DA_TYP_SCL_QTY'] >= 1:
		create_query=create_query+'`'+x['FLD_NM']+'`'+ " decimal ,"
	   else :
		create_query=create_query+'`'+x['FLD_NM']+'`'+ " string ,"

	create_query=create_query+ "meta_src_file_nm string ,meta_load_dt  timestamp ) PARTITIONED BY (dt STRING) " + "  STORED AS PARQUET" +"\")"
	exec(create_query)


def blank_as_null(x):
	#from pyspark.sql.functions import *
	return when(col(x) != "", col(x)).otherwise(None)


def scrub_dataframe(Meta_DF,final_DF):
	from pyspark.sql.functions import *
	for y in Meta_DF.collect() :
	 if (y['STRTG_POS_NO'] is not None or y['FLD_LGTH_NO'] is not None) and y['MTDT_DA_TYP'] != 'Number' :
	  #h="final_DF=final_DF.withColumn('"+y['FLD_NM']+"', rtrim(final_DF."+y['FLD_NM']+"))"
	  h="final_DF=final_DF.withColumn('"+y['FLD_NM']+"', rtrim("+'col("'+y['FLD_NM']+'")'+"))"
	  exec(h)
	  #final_DF = final_DF.withColumn(y['FLD_NM'], blank_as_null(y['FLD_NM']))
	  a="final_DF = final_DF.withColumn('"+y['FLD_NM']+"',when (col("+'"'+y['FLD_NM']+'") != "", col("'+y['FLD_NM']+'")).otherwise(None))'
	  exec(a)
	return final_DF


