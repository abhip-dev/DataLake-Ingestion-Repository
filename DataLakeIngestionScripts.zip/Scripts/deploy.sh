#!/bin/bash

hdfs dfs -rm -r -f "/data/CTL/encrypt/code/ingest/lvcht_interaction/scripts"

hdfs dfs -mkdir -p "/data/CTL/encrypt/code/ingest/lvcht_interaction/scripts"

hdfs dfs -put * "/data/CTL/encrypt/code/ingest/lvcht_interaction/scripts"
