import sys
import pyspark
from pyspark import SparkContext
from pyspark.sql.functions import *
from pyspark.sql import HiveContext

sqlContext = HiveContext(pyspark.SparkContext())


import pyspark.sql.functions as f
sqlContext.setConf("hive.exec.dynamic.partition", "true")
sqlContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict")
sqlContext.setConf("mapred.output.compression.codec", "org.apache.hadoop.io.compress.SnappyCodec") 

location="/data/CTL/encrypt/db/ingest/raw/asl_mes/"
ingest_db="asl_mes"
databasename_list = sqlContext.read.text("/data/CTL/data/ingest/test3/databasename.txt").rdd.flatMap(lambda x: x).collect()
tablename_list = sqlContext.read.text("/data/CTL/data/ingest/test3/tablename1.txt").rdd.flatMap(lambda x: x).collect()

for tablename in tablename_list:
	count=0
	counter=0
	list_mismatchschema=[]
	for index in range(len(databasename_list)-1):                  
		df1 = sqlContext.sql("SELECT * FROM "+databasename_list[index]+"."+tablename) 
		df2 = sqlContext.sql("SELECT * FROM "+databasename_list[index+1]+"."+tablename)
		df1.count()
		df2.count()
		schemadf1=df1.dtypes
		schemadf2=df2.dtypes
