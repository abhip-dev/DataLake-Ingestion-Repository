import sys
import datetime
from collections import OrderedDict
from pyspark.sql import Row
from pyspark.sql.types import *
from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext
from pyspark.sql import HiveContext
from pyspark.sql.functions import *

print("Starting spark")
sconf = SparkConf().setAppName("CDN Ingest").setMaster("yarn-cluster")
sconf.set("spark.shuffle.service.enabled", "true")
sconf.set("spark.dynamicAllocation.enabled", "true")
sconf.set("spark.dynamicAllocation.minExecutors", "50")
sconf.set("spark.dynamicAllocation.maxExecutors", "200")
sconf.set("spark.dynamicAllocation.initialExecutors", "10")
sconf.set("spark.yarn.maxAppAttempts", "1")
sconf.set("spark.yarn.executor.memoryOverhead", "500")
sc = SparkContext.getOrCreate(conf=sconf)
sqlContext = HiveContext(sc)
sqlContext.setConf("hive.exec.dynamic.partition", "true")
sqlContext.setConf("hive.exec.dynamic.partition.mode","nonstrict")
sqlContext.setConf("hive.merge.mapredfiles", "true")
sqlContext.setConf("hive.merge.size.per.task", "512000000")
sqlContext.setConf("hive.merge.smallfiles.avgsize", "512000000")

# collect the next hour of partition to load
curr_hr = datetime.datetime.now().strftime ("%Y%m%d%H")
sqlContext.sql("MSCK REPAIR TABLE asl_cdn.five_min_aggregated_cdn_logs_cmprsd")
# change query to use the  cdn_meta_stream_date_ref to get max meta_stream_date
max_meta_stream_date = sqlContext.sql("SELECT coalesce(cast(max(meta_stream_date) AS INT),2019070700) AS max_meta_stream_date FROM asl_cdn.cdn_meta_stream_date_ref where event_type='Job End'").first()["max_meta_stream_date"]

next_hr = sqlContext.sql("select cast(min(load_date) as INT) as next_hr FROM asl_cdn.five_min_aggregated_cdn_logs_cmprsd where load_date < cast({0} as INT) and load_date > cast({1} as INT)".format(curr_hr,max_meta_stream_date)).first()["next_hr"]
print(next_hr)

# Check the partition hour to be loaded is less than current hour
if next_hr+2 >= int(curr_hr) :
    print (next_hr+2)
    exit()

#Get 4 days back date from current partition to skip four days older records
Four_days_older_date = sqlContext.sql("select from_unixtime(unix_timestamp(max(yyyymmddhh), 'yyyyMMddHH')-345600, 'yyyyMMddHH') as Four_days_older_date FROM asl_cdn.five_min_aggregated_cdn_logs_cmprsd where load_date >= cast({0} as INT) and load_date < cast({1} as INT)".format(next_hr, next_hr + 2)).first()["Four_days_older_date"]
print(Four_days_older_date)

# insert Job Start record into the meta_stream_date ref table
print("Inserting into meta_stream_ref")
curr_tmstmp = datetime.datetime.now().strftime ("%Y%m%d%H%M")
schema = StructType([StructField('meta_stream_date', StringType()),StructField('event_type',StringType()), StructField('meta_load_tmstmp',StringType())])
rows = [Row(meta_stream_date = next_hr+1,event_type = 'Job Start', meta_load_tmstmp = curr_tmstmp)]
cdn_meta_stream_date_ref = sqlContext.createDataFrame(rows, schema)
cdn_meta_stream_date_ref.coalesce(1).write.mode("append").format("parquet").insertInto("asl_cdn.cdn_meta_stream_date_ref")

print("Next partition to be loaded")
# collect the next 2hour's of partition to load
five_min_aggregated_cdn_logs_cmprsd = sqlContext.sql("select * from asl_cdn.five_min_aggregated_cdn_logs_cmprsd where load_date >= '{0}' and load_date < '{1}' and yyyymmddhh >= '{2}'".format(next_hr,next_hr+2,Four_days_older_date))
five_min_aggregated_cdn_logs = five_min_aggregated_cdn_logs_cmprsd.selectExpr("time_bucket","coserver_id","raw_asn","avg_mbps","stddev_mbps","sum_bytes","status_code","sum_request_time","distr_id","sum_tcwait","stddev_tcwait","sum_tcpinfo_rtt","stddev_tcpinfo_rtt","cc","state","counter","distr_id_geo","scheme","requesttb","tcwaittb","tdwaittb","yyyymmddhh","min","reason_code","ip_version","ssl_session_reused","gw","cache_status","upstream_vip","fast_tdwait_1m_6s","fast_upstream_1m_6s","ifdelayed","billing_direction","fast_tcwait","distanceb","distanceavg","upstream_cache_body_sizesum","sum_ttfb","fast_ttfb","load_date as meta_stream_date","yyyymmddhh as dt_hr")

five_min_aggregated_cdn_logs.coalesce(100).write.mode("append").format("parquet").insertInto("asl_cdn.five_min_aggregated_cdn_logs")

print("Dataload complete for final table")

# insert Job End record into the meta_stream_date ref table
print("Inserting into meta_stream_ref")
curr_tmstmp = datetime.datetime.now().strftime ("%Y%m%d%H%M")
schema = StructType([StructField('meta_stream_date', StringType()), StructField('event_type',StringType()), StructField('meta_load_tmstmp',StringType())])
rows = [Row(meta_stream_date = next_hr+1,event_type='Job End', meta_load_tmstmp = curr_tmstmp)]
cdn_meta_stream_date_ref = sqlContext.createDataFrame(rows, schema)
cdn_meta_stream_date_ref.coalesce(1).write.mode("append").format("parquet").insertInto("asl_cdn.cdn_meta_stream_date_ref")
print("Complete")
