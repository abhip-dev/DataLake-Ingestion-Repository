#!/usr/bin/env python
##################################################################
#
# Script : Merge_pdf.py
# Author : Gunasekharan Narayana
# Created : 25-Jun-2019
#
##################################################################
#
# This script is created to extract a blob column in Oracle and
# convert them to pdf to be stored in edge node (US285918)
#
############### Version History ##################################
#
# Initial Version - Created the script for US285918
#
##################################################################

import __main__
import os
import sys
import io
import datetime
import logging
import configparser
import cx_Oracle
import PyPDF2
import glob

def main():
    script_name = "blob_to_pdf.py"

#Path and files
    home_dir = '/data/CTL/ingest/q2b_qtcpdf'
    code_dir = home_dir+'/python_code/'
    tar_dir = home_dir+'/pdf/'
    mrg_tar = home_dir+'/merge_pdf/'
    log_dir = home_dir+'/log/ingest_pdf/'
    timestamp = datetime.datetime.utcnow().strftime('%Y.%m.%d.%H.%M.%S')
    log_name = script_name+'_{}.log'.format(timestamp)
    log_file = os.path.join(log_dir, log_name)
    logging.basicConfig(filename=log_file,level=logging.DEBUG)

##setting configuration file
    settings = configparser.ConfigParser()
    settings.read('/data/CTL/ingest/q2b_qtcpdf/python_code/settings.ini')
    settings.sections()

    try:
        paths = glob.glob(tar_dir+'*.pdf')
        paths.sort()
        filename = 'chng.fin.ctl.cons.outpdfemail03_'+datetime.datetime.now().strftime("%Y%m%d")+'.pdf'
        PDFmerge(mrg_tar+filename, paths)
        logging.info("Text file created")
        logging.info("End of processing")
        return_code = 0

    except Exception as e:
        logging.error(e)
        sys.exit(2)

    except Error as e:
        logging.error(e)
        sys.exit(2)


def PDFmerge(output_path, input_paths):
    pdfMerger = PyPDF2.PdfFileMerger()
    file_handles = []
    for path in input_paths:
        pdfMerger.append(path)
    with open(output_path,'wb') as f:
        pdfMerger.write(f)

# Actually run the script if calling from the command line
if __name__ == '__main__':
    exit(main())
