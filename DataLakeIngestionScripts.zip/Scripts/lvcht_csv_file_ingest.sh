#############################################################################################################################################################
#  Script Shell : bash
#  Script       : lvcht_csv_file_ingest.sh
#  Authors      : Srivatsa Nagaraja
#  Description  : ingest CSV files for all hive tables and call oozie workflow
#############################################################################################################################################################

#!/bin/bash

script=`basename "$0"| cut -d "." -f 1`
DATETIME=`date '+%y%m%d_%H%M%S'`

home_dir=/data/CTL/ingest/lvcht
csv_dir=${home_dir}/staging/CSV
hdfs_trg_dir=/data/CTL/encrypt/db/ingest/raw/lvcht/CSV
log_dir=${home_dir}/log
log_file=${log_dir}/${script}_${DATETIME}.log

#-----------------------------------------------------------------
# Function to log
#-----------------------------------------------------------------

function printMsg ()
{
  echo "<${DATETIME}>: $@" >> ${log_file}
  echo "<${DATETIME}>: $@"
  return
}


#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
function check_status()
{
    lastCommandStatus=$?

  if [ $lastCommandStatus -ne 0 ]; then
     printMsg $1
         printMsg "FAILED"
         echo "Script FAILED"
     exit 1
  else
          printMsg $1
          printMsg "Command Successful."
          sleep 1s
          return
  fi
}

printMsg "Beginning of the script"

#-----------------------------------------------------------------
#put all the folder/files  under ${csv_dir} to ${hdfs_trg_dir} in HDFS
#-----------------------------------------------------------------
hdfs dfs -mkdir -p ${hdfs_trg_dir}
check_status "hdfs dfs -mkdir -p ${hdfs_trg_dir}"

hdfs dfs -put -f ${csv_dir}/* ${hdfs_trg_dir}/
check_status "hdfs dfs -put -f ${csv_dir}/* ${hdfs_trg_dir}/"
printMsg "CSV file ingestion completed to HDFS"
