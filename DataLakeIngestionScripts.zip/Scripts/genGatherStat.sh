#!/bin/bash


add jar /opt/cloudera/parcels/CDH/lib/hive-hcatalog/share/hcatalog/hive-hcatalog-core.jar;

hive -f /home/cdlapp/abhi_test/analyze.hql
