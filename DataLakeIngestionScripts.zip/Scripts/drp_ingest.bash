##################################################################################################################################
#  Script Shell : bash
#  Script       : drp_ingest.sh
#  Description  : The script watches the /sftp/drpsftp/incoming/ directory for DRP files and ingests them every 30 mins
#  Author       : Arvind Rajagopal
#  Comments:
#  spasupa  6/22/2018  US246434: Prod Failure: DRP_INGEST ingestion script troubleshooting
#  spasupa  6/28/2018  US246434: Prod Failure: DRP_INGEST ingestion script troubleshooting
#                                Added logic to process large files first. Reduced batches to 50 files
#
#  Kumar Abhishek(AC38815)  02/12/2019  US268077: DRP Ingest Production: Clean up orphaned flag files
##################################################################################################################################

#!/bin/bash

ulimit -s 655360
script=`basename "$0"`

#Define alert email parameters & subject##########################
DATETIME=`date '+%y%m%d_%H%M%S'`
EMAIL_SUB="CDH_DEV_${script}_failed_@_${DATETIME}"
EMAIL_ID="IT-DATALAKE-DEV@centurylink.com"
#EMAIL_ID="satish.pasupathy@centurylink.com"


#This section controls all local paths and file names#############
pid_dir=/data/CTL/ingest/drp/script
log_dir=/data/CTL/ingest/drp/log
staging_dir=/data/CTL/ingest/drp/staging
landing_dir=/sftp/drpsftp/incoming
archive_dir=/data/CTL/ingest/drp/archive

drp_hdfs_dir=/data/CTL/encrypt/data/ingest/raw/drp/ts=${DATETIME}
drp_concat_file=drp_${DATETIME}.dat

log=${log_dir}/${script}_${DATETIME}.log


#-----------------------------------------------------------------
# Function to append messages in log files.
#-----------------------------------------------------------------
function printMsg ()
{
  echo "<`date '+%y%m%d_%H%M%S'`>: $@" >> ${log}
  return
}

#-----------------------------------------------------------------
# Function to check the status and print appropriate message
#-----------------------------------------------------------------
function check_status()
{
    lastCommandStatus=$?

  if [ $lastCommandStatus -ne 0 ]; then
     printMsg $1
         printMsg "FAILED"
         echo "Script FAILED"
     clearPidFile
         exit 1


  else
          printMsg $1
          printMsg "Command Successful."
          return
  fi

}

echo "Starting execution of ${script} @ ${DATETIME}" >> ${log}

echo ${log}


# -----------------------------------------------------------------
# Find log files older than 30 days to be purged
# -----------------------------------------------------------------
function purgeLogs()
{
printMsg "Log files older than 30 days"
cd ${log_dir}
logfileCount=$(find *.log -mtime +30 | wc -l)

if [ ${logfileCount} -ne 0 ]; then
                printMsg "Number of log files older than 30 days:" ${logfileCount}
                find *.log -mtime +30 -exec rm {} \;
                check_status "find *.log -mtime +30 -exec rm {} \;"
                printMsg "${logfileCount} Log files purged"
else
                printMsg "No log file older than 30 days."
fi
}

# -----------------------------------------------------------------
# Find Archive files older than 60 days to be purged
# -----------------------------------------------------------------
function purgeArchive()
{
printMsg "Archive files older than 60 days"
cd ${archive_dir}
ArchivefileCount=$(find * -mtime +60 | wc -l)

if [ ${ArchivefileCount} -ne 0 ]; then
                printMsg "Number of Archive files older than 60 days:" ${ArchivefileCount}
                find * -mtime +60 -exec rm {} \;
                check_status "find * -mtime +60 -exec rm {} \;"
                printMsg "${ArchivefileCount} files purged"
else
                printMsg "No Archive file older than 60 days."
fi
}

#-----------------------------------------------------------------
# Function to clear process id file.
#-----------------------------------------------------------------
function clearPidFile()
{
                rm -f ${pid_dir}/${script}.pid
}

#-----------------------------------------------------------------
# Function to count total no of files in landing directory.
#-----------------------------------------------------------------
function fileCount()
{
                TOT_FILE_CNT=$(find ${landing_dir}/* -printf "%f\n" | wc -l)
                printMsg "Total Files to be processed: "${TOT_FILE_CNT}
}


#This Section prevents duplicate execution of the script#########
PIDFILE=${pid_dir}/${script}.pid
if [ -f ${PIDFILE} ]
then
  PID=$(cat ${PIDFILE})
  ps -p $PID > /dev/null 2>&1
  if [ $? -eq 0 ]
  then
    echo "${script} already executing with process ID - ${PID} .process ID found using ps -p. Terminating" >> ${log}
    echo "${script} already executing with process ID - ${PID} .process ID found using ps -p. Terminating" | mail -s ${EMAIL_SUB} ${EMAIL_ID}
    clearPidFile
        exit 1

  else
    echo "${script} already executing with process ID - ${PID} .But process ID not found using ps -p. Terminating" >> ${log}
    echo "${script} already executing with process ID - ${PID} .But process ID not found using ps -p. Terminating" | mail -s ${EMAIL_SUB} ${EMAIL_ID}
    clearPidFile
        exit 1

  fi
else
  echo $$ > ${PIDFILE}
  echo "Process ID" >> ${log}
  echo $$ >> ${log}
  if [ $? -ne 0 ]
  then
    echo "${script} unable to create process ID lock file. Terminating" >> ${log}
    echo "${script} unable to create process ID lock file. Terminating" | mail -s ${EMAIL_SUB} ${EMAIL_ID}
    clearPidFile
        exit 1

  fi
fi
##################################################################

typeset -i MAX_FILE_CNT
typeset -i BATCH_ID=0
typeset -i TOT_FILE_CNT=0
typeset -i VALID_FILE_CNT=0

MAX_FILE_CNT=$1

if [ ${MAX_FILE_CNT} -eq 0 ]
        then
        printMsg "Override for Max files count not passed"
        printMsg "Default max file count to 50"
        MAX_FILE_CNT=50
fi

printMsg "Files processed in each batch: "${MAX_FILE_CNT}

printMsg "Clearing the staging directory"
rm -f ${staging_dir}/*


#This part of script executes continuously to move DRP files######
#Moves the Data and associated tag files to staging directory then removing all tag files, moves all the unassociated data or tag files to archive directory.
fileCount
while [ ${TOT_FILE_CNT} -ne 0 ]; do

        printMsg "Processing Batch: "${BATCH_ID}

        #listing all the files in landing directory
        ls ${landing_dir}/* | head -${MAX_FILE_CNT} | cut -d "/" -f5 | cut -d "." -f1 | while IFS= read -r fileName;

                        do
                                printMsg "Begin processing file name: ${fileName}"

                                #find a count of a file listed above##
                                VALID_FILE_CNT=$(find ${landing_dir}/${fileName}.* -printf "%f\n" | wc -l)

                                #find a count on the basis of file listed above, if count value is 2, means both data and associated tag files are present, thus move both data and associated tag file to staging directory##
                                if [ ${VALID_FILE_CNT} -eq 2 ]
                                then

                                                printMsg "Both data and tag files found, move the data and tag files to staging dir: "${fileName}
                                                #move the data and tag files to staging dir##
                                                mv ${landing_dir}/${fileName}.* ${staging_dir}/


                                #Next loop will have count 0, if the data and associated files found above is already moved to staging directory, thus do nothing##
                                elif [ ${VALID_FILE_CNT} -eq 0 ]
                                then

                                                #Do Nothing, Data file and associated tag file already moved to staging directory##
                                                printMsg "Data file or associated tag file moved to staging directory: "${fileName}


                                #If only data or tag file is found will have count 1, thus move that file to archive directory##
                                else

                                                printMsg "Data file or associated tag file moved to archive directory, move the data or tag files to archive dir: "${fileName}
                                                #move the data or tag files to archive dir##
                                                mv ${landing_dir}/${fileName}.* ${archive_dir}/


                                fi

                        done


                        #concat and ingest files in staging directory
                        STG_FILECOUNT=$(ls ${staging_dir}/*.DAT.gz | wc -l)
                        printMsg "Files in staging directory: " ${STG_FILECOUNT}

                        if [ ${STG_FILECOUNT} -ne 0 ]
                        then
                                        #remove the flag files
                                        rm -f ${staging_dir}/*_flag
                                        check_status "rm -f ${staging_dir}/*_flag"
                                        #process next BATCH
                                        drp_concat_file=drp_${DATETIME}_${BATCH_ID}.dat

                                        #perform the concatenation
                                        zcat ${staging_dir}/*.gz > ${staging_dir}/${drp_concat_file}
                                        check_status "zcat ${staging_dir}/*.gz > ${staging_dir}/${drp_concat_file}"

                                        #compress the concatenated file
                                        printMsg "Compressing the concatenated file: "${staging_dir}/${drp_concat_file}
                                        gzip ${staging_dir}/${drp_concat_file}
                                        check_status "gzip ${staging_dir}/${drp_concat_file}"
                                        FILESIZE=$(stat -c%s "${staging_dir}/${drp_concat_file}.gz")

                                        #if file is greater than 128MB then put it on hdfs
                                        if [ ${FILESIZE} -lt 524288000 ]
                                        then
                                                        ((MAX_FILE_CNT=${MAX_FILE_CNT}+500))
                                        fi

                                        printMsg "Size of $FILENAME = $FILESIZE bytes."

                                        #make hdfs directory
                                        hdfs dfs -mkdir -p ${drp_hdfs_dir}
                                        check_status "hdfs dfs -mkdir -p ${drp_hdfs_dir}"

                                        #perform the hdfs put of the concatenated file
                                        hdfs dfs -put ${staging_dir}/${drp_concat_file}.gz ${drp_hdfs_dir}
                                        check_status "hdfs dfs -put ${staging_dir}/${drp_concat_file}.gz ${drp_hdfs_dir}.gz"

                                        #increment Batch Id
                                        ((BATCH_ID=$BATCH_ID+1))

                                        printMsg "Clearing the staging directory"
                                        rm -f ${staging_dir}/*

                        fi

                        #check if there are more files to process
                        fileCount

                        if [ ${TOT_FILE_CNT} -eq 0 ]; then
                                        printMsg "All files processed. Breaking loop."
                                        break
                        fi

done

# -----------------------------------------------------------------
# Purging Old Archive files older than 60 days
# -----------------------------------------------------------------
purgeArchive

# -----------------------------------------------------------------
# Purging Old Log files older than 30 days
# -----------------------------------------------------------------
purgeLogs


printMsg "Script complete."
clearPidFile
exit 0
