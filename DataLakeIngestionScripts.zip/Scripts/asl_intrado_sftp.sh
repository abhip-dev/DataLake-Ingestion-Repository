#############################################################################################################################################################
#  Script Shell : bash
#  Script       : asl_intrado_sftp.sh
#
#  Description  : The script sftp files from Intrado Productio server and store them in edge node.
#  Author       : Liping Zhang
#
#############################################################################################################################################################

#!/bin/bash
source /data/CTL/ingest/asl_intrado/config/config.properties

script=`basename "$0"`
echo "${script}"

date_time=`date '+%Y%m%d-%H%M%S'`
date=`date '+%Y%m%d'`


############################################## This section sets additioal local paths ########################################################
script_log_dir=${app_dir}/log

sftp_cmd_file=${app_dir}/script/intrado_sftp_cmds_file

log=${script_log_dir}/${script}_${date_time}.log

echo "Starting script - ${script} @ ${date_time}" > ${log}

#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
check_status () {
    lastCommandStatus=$?
        echo "Exit status from last command '$1' - $lastCommandStatus" >> ${log}
  if [ $lastCommandStatus -ne 0 ]; then
     err_msg="Error occurred in ${script} - ${model} Error occured in step: $1. Please check the log for details."
     subject_msg="${script} FAILED During Execution"
     echo "$subject_msg" >> ${log}
     echo "$err_msg" >> ${log}
     echo "exit 1" >> ${log}
     mail -s "$subject_msg"  ${Email_List} <<< "$err_msg"
     sleep 10s
     exit 1
  fi
}

#-----------------------------------------------------------------
# Function to send the appropriate email message
#-----------------------------------------------------------------
send_email () {
    lastCommandStatus=$?
        echo "Exit status from last command '$1' - $lastCommandStatus" >> ${log}
  sub=$1
  msg=$2
     echo "$sub" >> ${log}
     echo "$msg" >> ${log}
     mail -s "$sub"  ${Email_List} <<< "$msg"
     sleep 10s
}


echo "Starting execution of ${script} @ ${date_time}" >> ${log}


########## generates sftp batch command
echo -e "lcd ${local_landing_zone}\ncd ${remote_file_dir}" > ${sftp_cmd_file}
echo -e "get *" >> ${sftp_cmd_file}


########## sftp to get the files from Intrado site
########## NOTE only Prod points to Intrado server. Dev always points to DEV poldcdhen003 for testing
########## You can copy files from Prod to DEV if needed for testing after production release.
##########
sftp -b ${sftp_cmd_file} ${remote_server} >>${log} 2>&1
check_status "sftp -b ${sftp_cmd_file} ${remote_server} >>${log} 2>&1"


######### check if inventory file exist
cd ${local_landing_zone}

inv_file_num=`ls ${inv_file_prefix}*.txt | wc -l`
echo "number of inventory files - ${inv_file_num}" >> ${log}
if [ ${inv_file_num} -eq 0 ]
then
  send_email "${script}" "Inventory file ${inv_file_prefix}*.txt does not exist, please contact Intrado when needed"
fi


##################### send files to Walter's server, will stop in few months when approved###########

########## generates sftp batch command to send files to Walter
walter_file_dir=/opt/jail/home/intrdcdl/data
walter_sftp_cmd_file=${app_dir}/script/walter_sftp_cmds_file
walter_server=vp131
echo -e "lcd ${local_landing_zone}\ncd ${walter_file_dir}" > ${walter_sftp_cmd_file}
echo -e "put *" >> ${walter_sftp_cmd_file}

########## sftp to put the files from local landing zone to Walter's server
sftp -b ${walter_sftp_cmd_file} ${walter_server} >>${log} 2>&1
check_status "sftp -b ${walter_sftp_cmd_file} ${walter_server} >>${log} 2>&1"

#####################################################################################################


echo "${script} ${file_dir_name} run successfully." >> ${log}
exit 0
