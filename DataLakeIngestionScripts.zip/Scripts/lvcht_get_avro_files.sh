#############################################################################################################################################################
#  Script Shell : bash
#  Script       : lvcht_get_avro_files.sh
#  Authors      : Srivatsa Nagaraja
#  Description  : Get all the avro files to be processed into edge node
#############################################################################################################################################################

#!/bin/bash

script=`basename "$0"| cut -d "." -f 1`
DATETIME=`date '+%y%m%d_%H%M%S'`

home_dir=/data/CTL/ingest/lvcht
table_name=$1
config_dir=${home_dir}/config
hdfs_cnfig_dir=/data/CTL/encrypt/db/ingest/raw/lvcht/config/${table_name}_list
log_dir=${home_dir}/log
local_avro_dir=${home_dir}/staging/avro/${table_name}
log_file=${log_dir}/${script}_${DATETIME}.log

#-----------------------------------------------------------------
# Function to log
#-----------------------------------------------------------------

function printMsg ()
{
  echo "<`date '+%m/%d%y_%H:%M:%S'`>: $@" >> ${log_file}
  echo "<`date '+%m/%d%y_%H:%M:%S'`>: $@"
  return
}


#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
function check_status()
{
    lastCommandStatus=$?

  if [ $lastCommandStatus -ne 0 ]; then
     printMsg $1
         printMsg "FAILED"
         echo "Script FAILED"
     exit 1
  else
          printMsg $1
          printMsg "Command Successful."
          sleep 1s
          return
  fi
}


#-----------------------------------------------------------------
## Get the consolidated file and get avro files to be processed
#-----------------------------------------------------------------

printMsg "Beginning of the script;"
printMsg "Remove the local config file and all local avro files"

rm $config_dir/${table_name}_list 2> /dev/null
rm $local_avro_dir/* 2> /dev/null

printMsg "Get config file from HDFS"

hdfs dfs -get  ${hdfs_cnfig_dir} $config_dir
check_status "hdfs dfs -get -f ${hdfs_cnfig_dir} $config_dir"
config_file_content=`cat $config_dir/${table_name}_list`
        for line in $config_file_content; do
                if hdfs dfs -test -e $line;
                then
                        hdfs dfs -get $line $local_avro_dir
                        check_status "hdfs dfs -get -f $line $local_avro_dir"
                        printMsg "Avro file ${line} downloaded"
                else
                        printMsg "Avro file ${line} not found in HDFS"
                        cat $log_file;
                        exit 1;
                fi
        done
avro_file_cnt=`ls $local_avro_dir | wc -l`
printMsg "Number of Avro files to be processed : ${avro_file_cnt}"
printMsg "Script completed"
cat $log_file;
exit 0;
