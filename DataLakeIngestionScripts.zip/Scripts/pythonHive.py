# -*- coding: utf-8 -*-
"""
Created on Fri Jun 14 17:51:17 2019

@author: AC38815
"""

from pyhive import hive

host_name = "poldcdhen001.dev.intranet"
port = 8889
user = "AC38815"
password = "Developer@1995"
database="bdalab_sa"

def hiveconnection(host_name, port, user,password, database):
    conn = hive.Connection(host=host_name, port=port, username=user, password=password,
                           database=database, auth='CUSTOM')
    cur = conn.cursor()
    cur.execute('select * from stage_cds_contact_medium_profile_ref')
    result = cur.fetchall()

    return result

# Call above function
output = hiveconnection(host_name, port, user,password, database)
print(output)
