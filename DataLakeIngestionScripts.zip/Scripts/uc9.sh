#*********************************************************************************************
# Program Name           : UC9 Shell
# Shell Objective        : This code is to maintain the file and call UC9 spark code to INGEST fixed width flat file to HDFS and then to HIVE/Impala.
# Revision History:  Please do not stray from the example provided.
#
# Modfied    User     
# Date                Description
# MM/DD/YYYY         
# ---------- -------- ------------------------------------------------
# 05/20/2019 lalit joshi   Initial version
#=====================================================================================
#*********************************************************************************************



if [ "$#" -ne 2 ]; then
    echo "Illegal number of parameters, please pass HIVE_DB and HIVE_TABLE"
fi

bas_dir="/home/cdlapp/UC9"
. $bas_dir/uc9_shell.parm

##########################################################
#Initializing variables
##########################################################
#---HIVE_DB and TABLE passed as an argumnet--
hive_db=$1
hive_table=$2

#---SFTP_LOCATION (from source) and FILE initials should be avilable in META tables----
file_dir_n_file=`beeline -u $URL -n $META_USER -p $META_PWD  --silent=true --showheader=false --outputformat=csv2 -e "select LOCAL_FILE_SYS_PATH_DIR_NM from DWBIREF.dtrb_file_sys_file_dir where FILE_DIR_NM='$hive_table'"`

if [ -z "$file_dir_n_file" ] 
then
	echo "Please check META table DWBIREF.dtrb_file_sys_file_dir"|mailx -s "UC9---No entry on DWBIREF.dtrb_file_sys_file_dir for $hive_table" $Email
	exit 1
fi

sftp_location=`echo $file_dir_n_file|rev |cut -f2- -d"/" |rev|sed -e 's/[[:space:]]*$//'`
hive_file=`echo $file_dir_n_file| rev |cut -f1 -d"/"|rev|sed -e 's/[[:space:]]*$//'`

#---Temp variables for programe use----
sftp_work_location=$sftp_location/working_dir/$hive_file
zip_file_name_prefix=$hive_file"*.gz"
file_name_prefix=$hive_file"*"


##########################################################
#Variable check -- Exit the programe, if variables are not assigned properly
##########################################################
variables="sftp_location  hive_file  sftp_work_location  zip_file_name_prefix  file_name_prefix  hdfs_processed  hdfs_work  hive_db  hive_table"

for i in $variables
do
        [  -z "${!i}" ] && v_check=$v_check" , "$i
done

if [ ! -z "$v_check" ] 
then
	echo "Variables are not assigned proeprly, please check META TABLES"|mailx -s "UC9---Variable assignmnet is not done properly for $v_check for $hive_table" $Email
	exit 1
fi

##########################################################
#SFTP from PROD to DEV ( This is temporary)
##########################################################
sftp_server=$hive_db"_server"
sftp_server=${!sftp_server}

if [ "$transfer_from_prod" == "Y" ]
then
 sftp $sftp_server <<END_FTP > $log_dir/$hive_file"_sftp".log 2>&1
    lcd $sftp_location
    cd $sftp_location
    mget $file_name_prefix
    rm $file_name_prefix
    bye
END_FTP

fi	

##########################################################
#move the file to temp location to avoid data issue in case
#any file comes during the processing
##########################################################

if [ "$mv_to_working" == "Y" ]
then
	if [ -d "$sftp_work_location" ]
	then
		mv $sftp_location/$file_name_prefix $sftp_work_location
		echo "Files has been moved to $sftp_work_location"	
	else
		mkdir $sftp_work_location
		mv $sftp_location/$file_name_prefix $sftp_work_location
		echo "Files has been moved to $sftp_work_location"	
	fi
fi		


##########################################################
#move the file from HDFS work location to HDFS processed location
##########################################################

if [ "$mv_to_processed" == "Y" ]
then
	echo "##########################################################"
	file_count=`ls $sftp_work_location/$file_name_prefix|wc -l`
	if [ $file_count -gt 0 ]
	then 
		echo "Putting the files to HDFS Processed location is started"
		hdfs dfs -put -f  $sftp_work_location/$file_name_prefix $hdfs_processed/$hive_db/
	else
		echo "There is no file to process hence exiting UC9 for $hive_table"
		mailx -s "UC9---There is no file to process hence exiting UC9 for $hive_table" $Email <$log_dir/$hive_file.log
         	exit 1
	fi

        ReturnCode=$?
	if [ "$ReturnCode" -ne 0 ]
  	then
              mailx -s "UC9---Moving the files from edge node work to hdfs processed location is failed for $hive_table" $Email < $log_dir/$hive_file.log
 	      exit 1
  	else
	      echo "Putting the files from edge node work to HDFS Processed location is Completed"
	fi
fi



##########################################################
#Unzip the file ( If any )
##########################################################

if [ "$unzip_files" == "Y" ]
then
	echo "##########################################################"
	gz_file_count=`ls $sftp_work_location/$zip_file_name_prefix|wc -l`
	if [ $gz_file_count -ge 1 ]
	then
		echo "Unzipping the files started"
		gunzip $sftp_work_location/$zip_file_name_prefix
	else
		echo " No file to Unzip"
	fi

        ReturnCode=$?
	if [ "$ReturnCode" -ne 0 ]
  	then
              mailx -s "UC9---Unzip of the files for $hive_db has been failed" $Email <$log_dir/$hive_file.log
 	      exit 1
  	else
	      echo "Unzipping the files completed"
	fi

fi

extn=$hive_db"_extn"
extn=${!extn}

hdfs_work_files=`if [ -z $extn ];then ls $sftp_work_location --ignore='*.*' | grep $hive_file;else ls  $sftp_work_location |grep $hive_file|grep $extn; fi`
if [ -z "$hdfs_work_files" ] 
then
	echo "Variables are not assigned proeprly"|mailx -s "UC9---Variable assignmnet is not done properly for hdfs_work_files for $hive_table" $Email
	exit 1
fi


##########################################################
#move the file from SFTP location to HDFS work location
##########################################################


if [ "$sftp_to_work" == "Y" ]
then
	echo "##########################################################"
	file_count=`echo $hdfs_work_files|wc -w`
	if [ $file_count -gt 0 ]
	then 
		echo "Putting the files to HDFS work location is started"
		for file in `echo $hdfs_work_files`
		do
			hdfs dfs -put -f $sftp_work_location/$file $hdfs_work/$hive_db/
		done
	else
		mailx -s "UC9---There is no file to process hence exiting UC9 for $hive_table" $Email <$log_dir/$hive_file.log
         	exit 1

	fi

        ReturnCode=$?
	if [ "$ReturnCode" -ne 0 ]
  	then
              mailx -s "UC9---Moving the files for $hive_db to hdfs work location is failed" $Email <$log_dir/$hive_file.log
 	      exit 1
  	else
		echo "Putting the files to HDFS work location is Completed"
	fi

fi

##########################################################
#Spark code call for Ingestion
##########################################################

if [ "$spark_code_call" == "Y" ]
then
	echo "##########################################################"
	echo "Starting SPARK CODE"
	spark-submit --master yarn --jars "/usr/share/java/ojdbc6.jar" --driver-java-options="-Droot.logger=ERROR,console" $bas_dir/uc9.py $hive_db $hive_table $hive_file "$extn">$log_dir/$hive_file"_spark".log

        ReturnCode=$?
	if [ "$ReturnCode" -ne 0 ]
  	then
              mailx -s "UC9---Spark-code failed for $hive_table" $Email<$log_dir/$hive_file"_spark".log

 	      exit 1
  	else
	      count=`grep "subtract" $log_dir/$hive_file"_spark".log| cut -f2 -d '>'`
	      echo "SPARK CODE completed sucessfully"
	fi
fi



##########################################################
#Keep only one copy of the file in HDFS Processed location
##########################################################

if [ "$delete_loaded_files" == "Y" ]
then
	echo "##########################################################"
	echo "Removing the file from SFTP and HDFS work location is started"
	
	hdfs dfs -rm -f $hdfs_work/$hive_db/$file_name_prefix
	ReturnCode=$?

	rm -r $sftp_work_location
	ReturnCode1=$?

	if [[ "$ReturnCode" -ne 0 ]] || [[ "$ReturnCode1" -ne 0 ]]
  	then
              mailx -s "UC9--- $hive_table -- Moving the files to sftp OR hdfs processed location is failed, please check the logs" $Email <$log_dir/$hive_file.log
 	      exit 1
  	else
	      echo "Removing the file from SFTP and HDFS work location is Completed"
	fi
fi

echo "##########################################################"

mailx -s "UC9---$count record sucessfully loaded to $hive_db.$hive_table" $Email < $log_dir/$hive_file.log
