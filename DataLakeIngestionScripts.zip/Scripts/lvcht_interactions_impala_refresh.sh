#!/bin/bash

############################################################################
#Purpose: To refresh Impala matadata for LVCHT_INTERACTIONS tables
#Author : Srivatsa Nagaraja
#
#lowercase table name (i.e. co, bo, po)
############################################################################

kinit -k /home/cdlapp/cdlapp.keytab cdlapp@CTL.INTRANET

script=`basename "$0"| cut -d "." -f 1`
DATETIME=`date '+%y%m%d_%H%M%S'`
home_dir=/data/CTL/ingest/lvcht_interaction


script_log_dir=${home_dir}/logs
log_file=${script_log_dir}/${script}_${DATETIME}.log

RANDOM_NUMBER=$(shuf -i 11-20 -n 1)
echo $RANDOM_NUMBER >> ${log_file}


impala_server=polpcdhdn0$RANDOM_NUMBER.corp.intranet
impala_sql_dir=${home_dir}/scripts

#-----------------------------------------------------------------
function sendEmail ()
{
  EMAIL_SUB="CDH_PROD_${script}_failed_@_${DATETIME}"
  EMAIL_ID="IT-DATALAKE-DEV@centurylink.com"
  echo "Failed Processing: Please check log file for further details." | mail -s ${EMAIL_SUB} -a ${log_file} ${EMAIL_ID}
  sleep 1s
  return
}

#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
check_status () {
    lastCommandStatus=$?
        echo "Exit status from last command '$1' - $lastCommandStatus" >> ${log_file}
  if [ $lastCommandStatus -ne 0 ]; then
     err_msg="Error occurred in ${script}, in step: $1. please check the log in ${log_file}"
     subject_msg="${script} FAILED During Execution"
     echo "$subject_msg" >> ${log_file}
     echo "$err_msg" >> ${log_file}
     mail -s "$subject_msg"  ${Email_List} <<< "$err_msg"
     sleep 10s

     cat ${log_file}
     exit 1
  fi
}

#-----------------------------------------------------------------
# Start the processing
#-----------------------------------------------------------------

echo "Starting impala refresh" >> ${log_file}

echo "Running daily processing refresh" >> ${log_file}
impala_stg_log=`impala-shell -k --ssl -i ${impala_server} -B -f ${impala_sql_dir}/lvcht_interactions_refresh_metadata.sql 2>&1`
check_status "impala-shell -k --ssl -i ${impala_server} -B -f ${impala_sql_dir}/lvcht_interactions_refresh_metadata.sql 2>&1"
echo "${impala_stg_log}" >> ${log_file}

echo "Completed impala refresh" >> ${log_file}
