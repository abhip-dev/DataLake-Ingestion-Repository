#############################################################################################################################################################
#  Script Shell : bash
#  Script       : five_min_aggregated_cdn_logs_checkstatus.sh
#  Authors              : spasupa/ab08841
#  Data                 : Check the status of the CDN data load after each hourly load. The script will handle failed runs by checking and updating the cdn_meta_stream_date_ref
#############################################################################################################################################################

#!/bin/bash
script=`basename "$0"| cut -d "." -f 1`
DATETIME=`date '+%y%m%d_%H%M%S'`
home_dir=/data/CTL/ingest/asl_cdn
export PYTHON_EGG_CACHE=./eggs

# Get kerberos ticket
/usr/bin/kinit -V -kt cdlapp.keytab cdlapp@CTL.INTRANET

#-----------------------------------------------------------------
#This section controls all local paths, local file names, and hdfs dir
#-----------------------------------------------------------------
script_log_dir=/data/CTL/ingest/asl_cdn/log
log_file=${script_log_dir}/${script}_${DATETIME}.log

echo "Access the log file here: "${log_file}
#-----------------------------------------------------------------
# Function to log
#-----------------------------------------------------------------
function printMsg ()
{
  echo "<${DATETIME}>: $@"
  echo "<${DATETIME}>: $@" >> ${log_file}
  return
}

#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
function sendEmail ()
{
        EMAIL_SUB="CDH_DEV_${script}_failed_@_${DATETIME}"
    EMAIL_ID="IT-DATALAKE-DEV@centurylink.com"
    echo "CDN Processing: WARN: Job failed with no matching End job record, but data was not loaded for ${MetaStreamDtRef}. Next run will catchup." | mail -s ${EMAIL_SUB} -a ${log_file} ${EMAIL_ID}
    sleep 1s
        return
}

#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
function check_status()
{
    lastCommandStatus=$?

  if [ $lastCommandStatus -ne 0 ]; then
     printMsg $1
         printMsg "FAILED"
         echo "Script FAILED"
     sendEmail
     exit 1
  else
          printMsg $1
          printMsg "Command Successful."
          sleep 1s
          return
  fi

}
#-----------------------------------------------------------------
# Check if there is a start and end date for the Max meta stream date
#-----------------------------------------------------------------
impala-shell -k --ssl -i polpcdhdn002.corp.intranet -q 'invalidate metadata asl_cdn.cdn_meta_stream_date_ref'
printMsg "Refresh meatadata for asl_cdn.cdn_meta_stream_date_ref completed"
check_status

end_Job_Status=$(impala-shell -k --ssl -i polpcdhdn002.corp.intranet -q "WITH start_table AS (SELECT max(a.meta_stream_date) start_proc_time FROM  asl_cdn.cdn_meta_stream_date_ref a WHERE a.event_type = 'Job Start'), end_table AS (SELECT max(b.meta_stream_date) end_proc_time FROM asl_cdn.cdn_meta_stream_date_ref b WHERE b.event_type = 'Job End') SELECT end_table.end_proc_time FROM start_table LEFT JOIN end_table ON start_table.start_proc_time = end_table.end_proc_time;")
endJobStatus=$(echo $end_Job_Status | cut -d '|' -f4 | sed -e 's/^ *//' -e 's/ *$//')
echo $endJobStatus
printMsg "Completed load for max_meta_stream_date:"${endJobStatus}

if [ ${endJobStatus} != 'NULL' ];
then
# -----------------------------------------------------------------
# If the start and end have a matching entry, then exit 0
# -----------------------------------------------------------------
        printMsg "No failed jobs found. Exit 0"
        exit 0
elif [ ${endJobStatus} == 'NULL' ];
then
# -----------------------------------------------------------------
# If the end record is missing, get max meta stream table from the final table
# -----------------------------------------------------------------
printMsg "Incomplete load for max_meta_stream_date:"${endJobFlag}
printMsg "Querying asl_cdn.five_min_aggregated_cdn_logs for the maxMetaStreamDt"
Meta_StreamDtTable=$(impala-shell -k --ssl -i polpcdhdn002.corp.intranet -q "Select max(meta_stream_date) from asl_cdn.five_min_aggregated_cdn_logs")
MetaStreamDtTable=$(echo $Meta_StreamDtTable | cut -d '|' -f4 | sed -e 's/^ *//' -e 's/ *$//')

Meta_StreamDtRef=$(impala-shell -k --ssl -i polpcdhdn002.corp.intranet -q "Select max(meta_stream_date) from asl_cdn.cdn_meta_stream_date_ref")
MetaStreamDtRef=$(echo $Meta_StreamDtRef | cut -d '|' -f4 | sed -e 's/^ *//' -e 's/ *$//')

# -----------------------------------------------------------------
# If max meta stream date is = to max value orphaned start job, then make matching entry
# -----------------------------------------------------------------

        if [ ${MetaStreamDtTable} -eq ${MetaStreamDtRef} ];
        then
        printMsg "Insert the matching End Job Entry"
        timestamp=$(date +"%Y%m%d%H%M")
        # Insert query for the matching entry
impala-shell -k --ssl -i polpcdhdn002.corp.intranet -q "insert into table asl_cdn.cdn_meta_stream_date_ref values (${MetaStreamDtTable},'Job End',${timestamp});"

        else
# -----------------------------------------------------------------
# If max meta stream date is <> to max value orphaned start job, then ignore and exit
# PS: we will assume that the previous entries were all matched, and the max entry is always
# corresponding to the latest run.
# -----------------------------------------------------------------
        printMsg "No data was loaded for failed run of maxMetaStreamDt: "${MetaStreamDtRef}
        printMsg "Next dataload process will catchup on failed run."
        sendEmail
        exit 0
        fi

fi

exit 0
