#!/bin/bash

set -e

CONNECTION="jdbc:oracle:thin:@//salefadb.qintra.com:1528/salefa"
USERID=DWCDLSEL
PW=`hdfs dfs -cat /data/CTL/encrypt/pwd/cdlapp/salefa.passwd`

HIVE_SCHEMA=asl_sdp
OWNER=SFA_OWNER
SRC_TABLE=QOA_SERVICE_ELEMENT_ATTR


typeset -l TABLE_L=$SRC_TABLE
typeset -u TABLE_U=$SRC_TABLE
TABLE_TMP=$TABLE_L"_tmp"
TABLE_NEW=$TABLE_L

HIVE_SQL="/data/CTL/ingest/asl_sdp/"$TABLE_NEW

#IMPALA_HOST=poldcdhdn001.dev.intranet
IMPALA_HOST=polpcdhdn015.corp.intranet
DB_DOT_TABLE_NAME="${HIVE_SCHEMA}.${TABLE_NEW}"

echo ""
echo "Source Owner: ${OWNER}"
echo "Source Table: ${SRC_TABLE}"
echo "Target Table: ${TABLE_NEW}"
echo "Hive SQL: ${HIVE_SQL}"
echo ""

#check if exists
rm -f /data/CTL/ingest/asl_sdp/$TABL_NEW".hql"
rm -f /data/CTL/ingest/asl_sdp/$TABLE_NEW".hqll"

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom

sqoop import -D mapred.child.java.opts="\-Djava.security.egd=file:/dev/../dev/urandom" --direct --connect $CONNECTION \
--username $USERID --password $PW --table $OWNER.$SRC_TABLE \
--fetch-size=10000 --delete-target-dir --m 32 \
--target-dir /data/CTL/encrypt/db/ingest/raw/$HIVE_SCHEMA/work/"landing_"$TABLE_TMP

printf "use $HIVE_SCHEMA ;\n\ndrop table if exists $TABLE_TMP purge;\ndrop table if exists $TABLE_NEW purge;\n\n">$HIVE_SQL".hqll"

#Create TEMP Table
sqltext=`echo "Select 'CREATE EXTERNAL TABLE ' || '$TABLE_TMP ' || '('|| chr(10) ||listagg (COLUMN_NAME ||' STRING ', ' ,' ||chr(10) ) WITHIN GROUP (ORDER BY column_ID)|| ')' || ''|| chr(10)|| 'ROW FORMAT DELIMITED FIELDS TERMINATED BY ' ||''''||',' ||''''||chr(10)||'LOCATION '|| '''' || '/data/CTL/encrypt/db/ingest/raw/$HIVE_SCHEMA/work/"landing_"$TABLE_TMP' ||'''' FROM all_tab_columns where OWNER='$OWNER' and table_name='$SRC_TABLE' GROUP BY table_name"`
beeline -u $CONNECTION -n $USERID -p $PW  --silent=true --showheader=false --outputformat=csv -e "$sqltext" >>$HIVE_SQL".hqll"

#Create parquet table
sqlt=`echo "Select chr(10)||chr(10)|| 'CREATE EXTERNAL TABLE     ' || '$TABLE_NEW' || '('|| chr(10) ||listagg (COLUMN_NAME || CASE when Data_type = 'NUMBER' then ' DOUBLE ' when Data_type = 'DATE' then ' TIMESTAMP ' when Data_type = 'TIMESTAMP'  then ' TIMESTAMP ' ELSE ' STRING ' END , ' ,' ||chr(10) ) WITHIN GROUP (ORDER BY column_ID)||','|| CHR(10)|| 'META_LOAD_DT TIMESTAMP, META_BEGIN_DT TIMESTAMP, META_END_DT TIMESTAMP,META_CHECKSUM STRING, META_CURRENT_IND STRING'||')' ||CHR(10)||'STORED AS PARQUET' ||chr(10)||'LOCATION  '|| '''' || '/data/CTL/encrypt/db/ingest/raw/$HIVE_SCHEMA/' || '$TABLE_NEW' ||''''  FROM all_tab_columns where OWNER='$OWNER' and table_name='$SRC_TABLE' GROUP BY table_name"`
beeline -u $CONNECTION -n $USERID -p $PW  --silent=true --showheader=false --outputformat=csv -e "$sqlt">>$HIVE_SQL".hqll"

printf "\n\nset hive.merge.mapredfiles=true;\nset hive.merge.mapfiles=true;">>$HIVE_SQL".hqll"
printf "\nset hive.merge.size.per.task=512000000;\nset hive.merge.smallfiles.avgsize=511000000;">>$HIVE_SQL".hqll"
printf "\nset hive.exec.compress.output=true;\nset mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;">>$HIVE_SQL".hqll"
printf "\nset mapred.output.compression.type=BLOCK;">>$HIVE_SQL".hqll"

printf "\nset mapreduce.map.memory.mb=4096;\nset mapreduce.reduce.memory.mb=8192;\n\n">>$HIVE_SQL".hqll"
#printf  "\n\nset hive.exec.dynamic.partition=true;\nset hive.exec.dynamic.partition.mode=nonstrict;\n\n">>$HIVE_SQL".hqll"

#Insert from tmp into final table
sql_i=`echo "Select 'INSERT OVERWRITE TABLE $TABLE_NEW ' || chr(10) ||'SELECT    ' ||listagg (COLUMN_NAME , ' ,' ||chr(10) ) WITHIN GROUP (ORDER BY column_ID)|| ',current_timestamp()  as meta_load_dt,current_timestamp()  as meta_begin_dt,' || ''''||'9999-12-31 00:00:00'||''''||' as meta_end_dt,' ||'''' ||'--NA--'||''''||' AS meta_checksum,' ||'''' ||'Y'||''''||' AS meta_current_ind'||chr(10)||'FROM $TABLE_TMP' FROM all_tab_columns where OWNER='$OWNER' and table_name='$SRC_TABLE' GROUP BY table_name"`
beeline -u $CONNECTION -n $USERID -p $PW  --silent=true --showheader=false --outputformat=csv -e "$sql_i">>$HIVE_SQL".hqll"

# format and write to final hql file
sed -e 's/^'\''//g' $HIVE_SQL".hqll"|sed -e 's/'\'''\''$/'\'';/g'|sed '$ s/'\''$/;/g' > $HIVE_SQL".hql"
#rm -f $HIVE_SQL".hqll"

printf "\nanalyze table $TABLE_NEW compute statistics for columns;\n\n">>$HIVE_SQL".hql"
#printf "\ndrop table if exists $TABLE_TMP purge;\n\n">>$HIVE_SQL".hql"

#beeline -u "jdbc:hive2://hivedev.dev.intranet:10000/default;principal=hive/hivedev.dev.intranet@CTL.INTRANET;ssl=true" -f $HIVE_SQL".hql"
beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f $HIVE_SQL".hql"

#hdfs dfs -du -s -h /data/CTL/encrypt/db/ingest/raw/$HIVE_SCHEMA/work/"landing_"$TABLE_TMP >> $TABLE_U"_size.txt"
#hdfs dfs -du -s -h /data/CTL/encrypt/db/ingest/raw/$HIVE_SCHEMA/$TABLE_L >> $HIVE_SQL"_size.txt"

#remove TMP table's data files
hdfs dfs -rm -r /data/CTL/encrypt/db/ingest/raw/$HIVE_SCHEMA/work/"landing_"$TABLE_TMP/*

#invalidate metadata/refresh table
impala-shell -k --ssl -i $IMPALA_HOST -B --output_delimiter=, -q "REFRESH $DB_DOT_TABLE_NAME"
RC=$?
if [[ $RC -ne 0 ]]; then
    echo "IMPALA ERROR RC: $RC"
    exit 3
fi

exit 0
