import logging
import requests
import json
from datetime import datetime
import base64
import os
import sys
import time

#sys.path.insert(1, '/data/CTL/ingest/lvcht_interaction/requests-oauthlib-1.2.0')
from requests_oauthlib import OAuth1

code_dir='/data/CTL/ingest/lvcht_interaction/scripts'
config_dir='/data/CTL/ingest/lvcht_interaction/config'
script_name = "get_json.py"

#Logging
log_dir = '/data/CTL/ingest/lvcht_interaction/logs/'
timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
log_name = script_name+'_'+format(timestamp)+'.log'
log_file = os.path.join(log_dir, log_name)
logging.basicConfig(filename=log_file,level=logging.DEBUG)


accessUrl = 'https://va.enghist.liveperson.net/interaction_history/api/account/43906703/interactions/search'
consumer_key = 'e5853fb5ea074f058956a15998784c98'
consumer_secret = '55106681abe66a72'
access_token = '41f53d2187f6434286b01950a8d502b1'
access_token_secret = '72339c95a3c55803'

g_record_count = 0
start_time=str(sys.argv[1])
end_time=str(sys.argv[2])

def get_record_count():
    return g_record_count


def set_record_count(count):
    global g_record_count
    g_record_count = count

def get_oauth1_authorization():
    auth = OAuth1(consumer_key,
                  consumer_secret,
                  access_token,
                  access_token_secret,
                  signature_type='auth_header'
                  )
    return auth

def get_all_json_objects_response_from_live_engage(api_url,authorization,start_time,end_time):
    start_time_epoch = start_time
    end_time_epoch = end_time
    header = {"Content-type": "Application/json",
              "Accept": "application/json"}
    body = {
        "start": {
            "from": str(start_time_epoch),
            "to": str(end_time_epoch)
        }
    }
    body=json.dumps(body)
    response = requests.post(url=api_url, auth=authorization, data=body, headers=header)
    if response.status_code == 200:
        logging.info("GET request successful")
    else:
            sys.exit("Failed: Code %s" % response.status_code)
    response_dict=response.json()
    fetched_record_count = len(response_dict['interactionHistoryRecords'])
    set_record_count(get_record_count() + fetched_record_count)
    logging.info("Records fetched " + str(fetched_record_count) + ", Total Records " + str(get_record_count()))
    json_objects_list = [response_dict['interactionHistoryRecords']]
    logging.info("Extracted JSON objects from response")
    nextURLExists = False
    for key in response_dict["_metadata"].keys():
        if key == "next":
            nextURLExists = True
            break
    if nextURLExists:
        with open('/data/CTL/ingest/lvcht_interaction/incoming/interactions_'+str(sys.argv[1])+'_'+str(sys.argv[2])+'_'+str(get_record_count())+'.json','w') as f:
            json.dump(json_objects_list,f)
            f.close()
        return get_all_json_objects_response_from_live_engage(response_dict["_metadata"]["next"]["href"],authorization,start_time,end_time)
    else:
        logging.info('No further data to fetch from API')
        with open('/data/CTL/ingest/lvcht_interaction/incoming/interactions_'+str(sys.argv[1])+'_'+str(sys.argv[2])+'_'+str(get_record_count())+'.json','w') as f:
            json.dump(json_objects_list,f)
            f.close()
        return 1

logging.info("Beginning of the script")
logging.info("Get authorization")
authorization=get_oauth1_authorization()
logging.info("Auth successfull, get json data")
json_data_return=get_all_json_objects_response_from_live_engage(accessUrl,authorization,start_time,end_time)
