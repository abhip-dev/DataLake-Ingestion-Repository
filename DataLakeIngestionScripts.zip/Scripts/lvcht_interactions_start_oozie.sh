#############################################################################################################################################################
#  Script Shell : bash
#  Script       : lvcht_interactions_start_oozie.sh
#  Author       : Nagaraja, Srivatsa
#  Date         : 07/24/2019
#
#  Description  :  To run oozie work flow
#
#
#############################################################################################################################################################
#!/bin/bash

app_dir=/data/CTL/ingest/lvcht_interaction
workflow_name=$1
script=`basename "$0"| cut -d "." -f 1`
DATETIME=`date '+%y%m%d_%H%M%S'`
script_log_dir=${app_dir}/logs
log_file=${script_log_dir}/${script}_${DATETIME}_${workflow_name}.log
oozie_config=https://polpcdhen001.corp.intranet:11443/oozie

#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
check_status () {
    lastCommandStatus=$?
        echo "Exit status from last command '$1' - $lastCommandStatus" >> ${log_file}
  if [ $lastCommandStatus -ne 0 ]; then
     cat ${log_file}
     exit 1
  fi
}

#-----------------------------------------------------------------
# Function to log
#-----------------------------------------------------------------
function printMsg ()
{
  echo "<${DATETIME}>: $@" >> ${log_file}
  echo "<${DATETIME}>: $@"
  return
}

#-----------------------------------------------------------------
# Start oozie workflow
#-----------------------------------------------------------------

oozie_wf_id=$(oozie job -oozie ${oozie_config} -config ${app_dir}/oozie/${workflow_name}/job.properties -run | cut -d ':' -f2)

printMsg "Oozie Job kicked off. Job id: ${oozie_wf_id}"

oozie_wf_status=$(oozie job -oozie ${oozie_config} -info ${oozie_wf_id} | head -5 | tail -1 | cut -d ':' -f2)

printMsg "${oozie_wf_status}"

if [ $oozie_wf_status == 'RUNNING' ] || [ $oozie_wf_status == 'KILLED' ] || [ $oozie_wf_status == 'FAILED' ] || [ $oozie_wf_status ==   'SUCCEEDED' ] || [ $oozie_wf_status == 'SUSPENDED' ] || [ $oozie_wf_status == 'PREP' ]; then

    while [ $oozie_wf_status == 'RUNNING' ]
   do
       printMsg "Workflow status:" $oozie_wf_status
       sleep 60
          oozie_wf_status=$(oozie job -oozie ${oozie_config} -info ${oozie_wf_id} | head -5 | tail -1 | cut -d ':' -f2)
   done

   if [ ${oozie_wf_status} == 'KILLED' ]; then
       printMsg "Oozie Workflow id ${oozie_wf_id} Failed. Check Log for details."
       exit 1
   elif [ ${oozie_wf_status} == 'SUCCEEDED' ]; then
       printMsg "Oozie workflow ${oozie_wf_id} Succeeded."
       exit 0
   fi
else
        printMsg "status unknown"
        exit 1;
fi
