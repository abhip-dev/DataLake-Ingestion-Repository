##################################################################################################################################
#  Script Shell : bash
#  Script       : asl_intrado_load_table.sh
#  Description  : The script creates Hive Table and Load the Data for all 6 Intrado west files(For More Information See CR7608)
#  Author       : AC38815 - Kumar Abhishek
##################################################################################################################################

#!/bin/bash
kinit -kt /home/cdlapp/cdlapp.keytab cdlapp@CTL.INTRANET

script=`basename "$0"| cut -d "." -f1`
DATETIME=`date '+%Y%m%d_%H%M%S'`
curr_year=`date '+%Y'`

#-----------------------------------------------------------------
# This section controls all local paths and file names
#-----------------------------------------------------------------
home_dir=/data/CTL/ingest
log_dir=${home_dir}/asl_intrado/log
staging_dir=${home_dir}/asl_intrado/staging
log=${log_dir}/${script}_${DATETIME}.log
echo "Access the log file here: "${log}

#-----------------------------------------------------------------
# HDFS Processed Directory(to keep all files as backup)
#-----------------------------------------------------------------
hdfs_processed_dir=/data/CTL/encrypt/data/ingest/processed/asl_intrado/${curr_year}
hdfs dfs -test -d ${hdfs_processed_dir}
if [ $? != 0 ]; then
    hdfs dfs -mkdir -p ${hdfs_processed_dir}
fi

#-----------------------------------------------------------------
# Setting Variables to support sendEmail functionality
#-----------------------------------------------------------------
EMAIL_SUB="${script}_failed_@_${DATETIME}"
#EMAIL_ID="abhishek.kumar2@centurylink.com"
EMAIL_ID="IT-DATALAKE-DEV@centurylink.com"

#-----------------------------------------------------------------
# Function to append messages in log files.
#-----------------------------------------------------------------
function printMsg ()
{
        echo "<`date '+%Y%m%d_%H%M%S'`>: $@" >> ${log}
        return
}

#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
function sendEmail()
{
        echo "Failed Processing: Please check log file for further details." | mail -s ${EMAIL_SUB} -a ${log} ${EMAIL_ID}
        sleep 10s
        return
}

#-----------------------------------------------------------------
# Function to check the status and send the appropriate email message
#-----------------------------------------------------------------
function check_status()
{
        lastCommandStatus=$?
        printMsg "Exit status from last command '$1' - $lastCommandStatus"
        if [ $lastCommandStatus -ne 0 ]; then
                printMsg "Error occurred in ${script} in step: $1"
                printMsg "SCRIPT Execution FAILED"
                sendEmail
                exit 1
        fi
}


echo "Starting execution of ${script} @ ${DATETIME}" >> ${log}
echo ${log}
printMsg "================================================================="

#-----------------------------------------------------------------------------------------------------#
#-----------------------------------------------------------------
# Trigger Hive Query to Load DECC Data
#-----------------------------------------------------------------
ls ${staging_dir}/D*
if [ $? -eq 0 ]
then
        printMsg "started Loading Data For DECC Files."
        printMsg "================================================================="
         beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f "${home_dir}/asl_intrado/hive/asl_intrado_load_decc.hql"
        check_status "beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f "${home_dir}/asl_intrado/hive/asl_intrado_load_decc.hql""
        printMsg "Moving DECC files from ${staging_dir} directory to ${hdfs_processed_dir}. "
        hdfs dfs -put -f ${staging_dir}/D* ${hdfs_processed_dir}/
        check_status "hdfs dfs -put ${staging_dir}/D* ${hdfs_processed_dir}/"
        rm ${staging_dir}/D*
fi

#-----------------------------------------------------------------
# Trigger Hive Query to Load LNP Data
#-----------------------------------------------------------------
ls ${staging_dir}/L*
if [ $? -eq 0 ]
then
        printMsg "started Loading Data For LNP Files."
        printMsg "================================================================="
        beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f "${home_dir}/asl_intrado/hive/asl_intrado_load_lnp.hql"
        check_status "beeline -u "jdbc:hive2://hivedejdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f "${home_dir}/asl_intrado/hive/asl_intrado_load_lnp.hql""
        printMsg "Moving LNP files from ${staging_dir} directory to ${hdfs_processed_dir}. "
        hdfs dfs -put -f ${staging_dir}/L* ${hdfs_processed_dir}/
        check_status "hdfs dfs -put ${staging_dir}/L* ${hdfs_processed_dir}/"
        rm ${staging_dir}/L*
fi

#-----------------------------------------------------------------
# Trigger Hive Query to Load REF Data
#-----------------------------------------------------------------
ls ${staging_dir}/R*
if [ $? -eq 0 ]
then
        printMsg "started Loading Data For REF Files."
        printMsg "================================================================="
        beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f "${home_dir}/asl_intrado/hive/asl_intrado_load_ref.hql"
        check_status "beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f "${home_dir}/asl_intrado/hive/asl_intrado_load_ref.hql""
        printMsg "Moving REF files from ${staging_dir} directory to ${hdfs_processed_dir}. "
        hdfs dfs -put -f ${staging_dir}/R* ${hdfs_processed_dir}/
        check_status "hdfs dfs -put ${staging_dir}/L* ${hdfs_processed_dir}/"
        rm ${staging_dir}/R*
fi

#-----------------------------------------------------------------
# Trigger Hive Query to Load OE Data
#-----------------------------------------------------------------
ls ${staging_dir}/O*
if [ $? -eq 0 ]
then
        printMsg "started Loading Data For OE Files."
        printMsg "================================================================="
        beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f "${home_dir}/asl_intrado/hive/asl_intrado_load_oe.hql"
        check_status "beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f "${home_dir}/asl_intrado/hive/asl_intrado_load_oe.hql""
        printMsg "Moving OE files from ${staging_dir} directory to ${hdfs_processed_dir}. "
        hdfs dfs -put -f ${staging_dir}/O* ${hdfs_processed_dir}/
        check_status "hdfs dfs -put ${staging_dir}/O* ${hdfs_processed_dir}/"
        rm ${staging_dir}/O*
fi

#-----------------------------------------------------------------
# Trigger Hive Query to Load v911 ERROR Data
#-----------------------------------------------------------------
ls ${staging_dir}/VOIP_SEMI_DELIMITED_ERROR*
if [ $? -eq 0 ]
then
        printMsg "started Loading Data For VOIP_SEMI_DELIMITED_ERROR Files."
        printMsg "================================================================="
        beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f "${home_dir}/asl_intrado/hive/asl_intrado_load_v911_error.hql"
        check_status "beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f "${home_dir}/asl_intrado/hive/asl_intrado_load_v911_error.hql""
        printMsg "Moving VOIP ERROR files from ${staging_dir} directory to ${hdfs_processed_dir}. "
        hdfs dfs -put -f ${staging_dir}/VOIP_SEMI_DELIMITED_ERROR* ${hdfs_processed_dir}/
        check_status "hdfs dfs -put ${staging_dir}/VOIP_SEMI_DELIMITED_ERROR* ${hdfs_processed_dir}/"
        rm ${staging_dir}/VOIP_SEMI_DELIMITED_ERROR*
fi

#-----------------------------------------------------------------
# Trigger Hive Query to Load V911 INVENTORY Data
#-----------------------------------------------------------------
ls ${staging_dir}/VOIP_SEMI_DELIMITED_TN*
if [ $? -eq 0 ]
then
        printMsg "started Loading Data For VOIP_SEMI_DELIMITED_TN Files."
        printMsg "================================================================="
        beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f "${home_dir}/asl_intrado/hive/asl_intrado_load_v911_inventory.hql"
        check_status "beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f "${home_dir}/asl_intrado/hive/asl_intrado_load_v911_inventory.hql""
        printMsg "Moving VOIP TN files from ${staging_dir} directory to ${hdfs_processed_dir}. "
        hdfs dfs -put -f ${staging_dir}/VOIP_SEMI_DELIMITED_TN* ${hdfs_processed_dir}/
        check_status "hdfs dfs -put ${staging_dir}/VOIP_SEMI_DELIMITED_TN* ${hdfs_processed_dir}/"
        rm ${staging_dir}/VOIP_SEMI_DELIMITED_TN*
fi

#-----------------------------------------------------------------------------------------------------#
printMsg "================================================================="
printMsg "All the Tables has been Loaded for Date: " ${DATETIME}
printMsg "Script Processing Completed for Date: " ${DATETIME}

exit 0;
