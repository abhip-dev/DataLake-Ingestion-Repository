#*********************************************************************************************
# Program Name           : UC9_parm
# Shell Objective        : It holds all the variable. User can change them accordingly.
# Modfied    User     
# Date                Description
# MM/DD/YYYY         
# ---------- -------- ------------------------------------------------
# 04/12/2019 lalit joshi   Initial version
#=====================================================================================
#*********************************************************************************************



input_path = "/data/CTL/encrypt/data/ingest/work/"
db_dir="/data/CTL/encrypt/db/ingest/raw/"

quality_check_days='1'
asl_cabs_extn=""
asl_rjf_extn=".dat"


URL='jdbc:oracle:thin:@//podclodm-scan:1521/DWBS01DU1'
META_USER='MKISUSER'
META_PWD='bcdev15'