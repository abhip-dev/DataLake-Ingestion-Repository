#############################################################################################################################################################
#  Script Shell : bash
#  Script       : lvcht_start_oozie.sh
#  Authors      : Srivatsa Nagaraja
#  Description  : start the oozie workflow for the parameter passed
#############################################################################################################################################################

#!/bin/bash

script=`basename "$0"| cut -d "." -f 1`
DATETIME=`date '+%y%m%d_%H%M%S'`

home_dir=/data/CTL/ingest/lvcht
oozie_config=https://poldcdhen001.dev.intranet:11443/oozie
log_dir=${home_dir}/log
log_file=${log_dir}/${script}_${DATETIME}.log
table_name=$1
#-----------------------------------------------------------------
# Function to log
#-----------------------------------------------------------------


function printMsg ()
{
  echo "<${DATETIME}>: $@" >> ${log_file}
  echo "<${DATETIME}>: $@"
  return
}


#--------------------------------------------------------
#call oozie workflow
#--------------------------------------------------------

oozie_wf_id=$(oozie job -oozie ${oozie_config} -config ${home_dir}/job.properties -run -D hive_table_name=${table_name}| cut -d ':' -f2)

printMsg "Oozie Job kicked off. Job id: ${oozie_wf_id}"

oozie_wf_status=$(oozie job -oozie ${oozie_config}  -info ${oozie_wf_id} | head -5 | tail -1 | cut -d ':' -f2)

printMsg "${oozie_wf_status}"

     while [ $oozie_wf_status == 'RUNNING' ]
     do
             printMsg "Workflow status:" $oozie_wf_status
             sleep 60
             oozie_wf_status=$(oozie job -oozie ${oozie_config}  -info ${oozie_wf_id} | head -5 | tail -1 | cut -d ':' -f2)
     done

     if [ ${oozie_wf_status} == 'KILLED' ]; then
             printMsg "Oozie Workflow id ${oozie_wf_id} Failed. Check Log for details."
             exit 1
     elif [ ${oozie_wf_status} == 'SUCCEEDED' ]; then
             printMsg "Oozie workflow ${oozie_wf_id} Succeeded."
             exit 0
     fi
