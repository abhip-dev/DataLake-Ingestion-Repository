package com.ctl

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql._
import org.apache.spark.sql.types._



object  VoipAIResponseSummary{

def main(args: Array[String]): Unit = {

 val sparkSession = SparkSession.builder.master("yarn").appName(" TCS ").config("spark.sql.warehouse.dir", "hdfs:///data/CTL/encrypt/db/ingest/raw/asl_comtech/src_CTL_VoIP03_ALI_Response_Summary").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate()

import sparkSession.implicits._

val input = args(0)

val custom_schema = StructType(Array(StructField("PSAP_LOCATION", StringType, true),StructField("Total_ALI_Requests", StringType, true),StructField("Total_Responses_w_out_ALI_Data", StringType, true),StructField("Total_Responses_with_ALI_Data", StringType, true),StructField("Delivered_w_MSAG_Address", StringType, true),StructField("Delivered_w_Geolocation_and_Address", StringType, true),StructField("Delivered_w_Geolocation_Only", StringType, true),StructField("percent_Delivered_with_MSAG", StringType, true),StructField("Delivered_w_Position", StringType, true),StructField("Average_Response_Time", StringType, true)))

val readxl = sparkSession.read.format("com.crealytics.spark.excel").option("dataAddress", "'Page 1'!A11").option("useHeader", "false").option("treatEmptyValuesAsNulls", "true").schema(custom_schema).load(input)


val meta_load_time_Stamp = readxl.withColumn("meta_load_timeStamp",from_unixtime(unix_timestamp(), "yyyyMMdd"))
val rptt = meta_load_time_Stamp.withColumn("rpt_dt", from_unixtime(unix_timestamp($"meta_load_timeStamp", "yyyyMMdd"), "yyyyMM"))
rptt.write.partitionBy("rpt_dt").format("parquet").mode("append").saveAsTable("asl_comtech.CTL_VoIP03_ALI_Response_Summary")

sparkSession.stop()

}
}