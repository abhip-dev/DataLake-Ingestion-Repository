hdfs dfs -du -s -h /data/CTL/encrypt/db/ingest/raw/ems_calix_ctel_midwest_southern/public_mef_serviceovcendptperennicfgtable|awk '{print $1}'
hdfs dfs -du -s -h /data/CTL/encrypt/db/ingest/raw/ems_calix_ctel_midwest_southern/public_mef_serviceovcendptpervunicfgtable|awk '{print $1}'
