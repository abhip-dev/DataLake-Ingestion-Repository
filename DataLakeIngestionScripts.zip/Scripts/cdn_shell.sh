#############################################################################################################################################################
#  Script Shell : bash
#  Script       : cdnWarapper.sh
#  Authors              : spasupa
#  Data                 : Execute the cdn spark 2 submit
#############################################################################################################################################################

#!/bin/bash
script=`basename "$0"| cut -d "." -f 1`
DATETIME=`date '+%y%m%d_%H%M%S'`
home_dir=/data/CTL/ingest/asl_cdn

#-----------------------------------------------------------------
#This section controls all local paths, local file names, and hdfs dir
#-----------------------------------------------------------------
script_log_dir=/data/CTL/ingest/asl_cdn/log
config_dir=/data/CTL/ingest/asl_cdn/config
log_file=${script_log_dir}/${script}_${DATETIME}.log

echo "Access the log file here: "${log_file}
#-----------------------------------------------------------------
# Function to log
#-----------------------------------------------------------------
function printMsg ()
{
  echo "<${DATETIME}>: $@" >> ${log_file}
  return
}

#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
function sendEmail ()
{
        EMAIL_SUB="CDH_PROD_${script}_failed_@_${DATETIME}"
    EMAIL_ID="IT-DATALAKE-DEV@centurylink.com"
    echo "Failed Processing: Please check log file for further details." | mail -s ${EMAIL_SUB} -a ${log_file} ${EMAIL_ID}
    sleep 1s
        return
}

#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
function check_status()
{
    lastCommandStatus=$?

  if [ $lastCommandStatus -ne 0 ]; then
     printMsg $1
         printMsg "FAILED"
         echo "Script FAILED"
     sendEmail
     exit 1
  else
          printMsg $1
          printMsg "Command Successful."
          sleep 1s
          return
  fi

}
#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
success_file="${config_dir}/success.flag"
cat ${success_file}

if [ -f ${config_dir}/success.flag ]
then
    printMsg "Success File Found"
        rm ${config_dir}/success.flag
        printMsg "submitting CDN Spark job"
        spark2-submit --master yarn --deploy-mode cluster --executor-memory 2G --driver-memory 6G /data/CTL/ingest/asl_cdn/script/five_min_aggregated_cdn_logs_load.py
        /data/CTL/ingest/asl_cdn/script/five_min_aggregated_cdn_logs_checkstatus.sh
        autoimpala -q 'invalidate metadata asl_cdn.five_min_aggregated_cdn_logs'
        printMsg "Completed CDN Spark job"

        touch ${config_dir}/success.flag
else
    printMsg "Success File not Found"
fi

exit 0