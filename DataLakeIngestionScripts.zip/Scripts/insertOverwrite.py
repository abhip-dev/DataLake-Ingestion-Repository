from __future__ import division
import sys
import pyspark
from pyspark import SparkConf, SparkContext
from pyspark.sql.functions import *
from pyspark.sql import HiveContext
import datetime
import commands
import math

HIVE_SCHEMA=sys.argv[1]
HIVE_TABLE=sys.argv[2]
PARTITION_COLS=sys.argv[3].strip('[]')

conf = (SparkConf().setMaster("yarn"))

conf.set("hivemetastore.uris", "thrift://poldcdhmn003.dev.intranet:9083")
conf.set("spark.shuffle.service.enabled", "true")
conf.set("yarn.nodemanager.pmem-check-enabled", "false")
conf.set("yarn.nodemanager.vmem-check-enabled", "false")
conf.set("spark.dynamicAllocation.enabled", "true")
conf.set("spark.dynamicAllocation.minExecutors", "0")
conf.set("spark.dynamicAllocation.maxExecutors", "50")
conf.set("spark.dynamicAllocation.initialExecutors", "5")
conf.set("spark.yarn.executor.memoryOverhead", "10G")
conf.set("spark.sql.warehouse.dir", "/user/hive/warehouse")
conf.set("hive.metastore.execute.setugi", "true")
conf.set("hive.exec.dynamic.partition", "true")
conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
conf.set("hive.enforce.bucketing", "true")
conf.set("hive.merge.mapfiles", "true")
conf.set("hive.merge.mapredfiles", "true")
conf.set("hive.merge.sparkfiles", "true")
conf.set("spark.sql.inMemoryColumnarStorage.compressed" ,"true")
conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
conf.set("spark.sql.hive.verifyPartitionPath", "false")

sc = SparkContext(conf = conf)
sc._jsc.hadoopConfiguration().set("dfs.block.size", "512m")

sqlContext = HiveContext(sc);

temp_table = "_temp_" + str(datetime.datetime.today().strftime('%Y_%m_%d'))
overwrite_query="INSERT OVERWRITE TABLE " + HIVE_SCHEMA + "." + HIVE_TABLE 

#create temp_table
print("Creating temp table : "+ str(datetime.datetime.now()))
sqlContext.sql("CREATE TABLE IF NOT EXISTS " + HIVE_SCHEMA + "." + HIVE_TABLE + temp_table + " AS SELECT * FROM " + HIVE_SCHEMA + "." + HIVE_TABLE )
print("Finished creating temp table : "+ str(datetime.datetime.now()))

if PARTITION_COLS!="" and PARTITION_COLS!="null":
	print "Overwriting for partitioned table"
	overwrite_query = overwrite_query + " PARTITION(" + PARTITION_COLS + ")"
else :
	print "Overwriting for flat table"

overwrite_query = overwrite_query + " SELECT * from " + HIVE_SCHEMA + "." + HIVE_TABLE + temp_table

print overwrite_query

#executing overwrite query
print("overwrite data start : "+ str(datetime.datetime.now()))
sqlContext.sql("set hive.enforce.bucketing=true;")
sqlContext.sql(overwrite_query)
print ("overwrite data finish : "+ str(datetime.datetime.now()))

#drop temp table
sqlContext.sql("DROP table IF EXISTS " + HIVE_SCHEMA + "." + HIVE_TABLE + temp_table)

sc.stop()
exit()
