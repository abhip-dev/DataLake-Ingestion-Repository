#!/usr/bin/env python

import sys
import io
import os
import re
import datetime


def find_between( s, first, last ):
    try:
        start = s.index( first ) + len( first )
        end = s.index( last, start )
        return s[start:end]
    except ValueError:
        return ""

def find_between_r( s, first, last ):
    try:
        start = s.rindex( first ) + len( first )
        end = s.rindex( last, start )
        return s[start:end]
    except ValueError:
        return ""

def usage(argv):
    print ('usage: %s actual_pdf_file_name pdf_parsed_text_file outfile_for_data ' % argv[0])


def get_date(file_name,date_regx):
  for val in file_name.split('_'):
   matched_val=date_regx.match(val)
   if(matched_val!= None):
    #print matched_val.group(1)
    return matched_val.group(1)



# main
def main(argv):

  if len(argv) < 3 :
      usage(argv)

  pdf_text_file=argv[1]
  output_file=argv[2]
  tmp_inter_file=argv[1]+"temp"
  pre, ext = os.path.splitext(os.path.basename(pdf_text_file))
  actual_pdf_file=pre+".pdf"


  page_arr=[];
  wf = open(tmp_inter_file,"w");
  second_line_found="NO"
  found_page="NO"
  strat_writing="NO"
  next_page="FALSE"

  pattern=re.compile("^Page \d+ *$")

  with open(pdf_text_file,'r') as f:

    for line_with_blanks in f:
       line = line_with_blanks.rstrip().replace("
Page","Page")

       match_string=pattern.match(line)
       if(match_string!= None and next_page=='FALSE'):
           page_arr.append(line);
           continue;
       if(match_string!= None and next_page=='TRUE'):
           if any("Page 1 of " in s for s in page_arr):
               wf.write("\n".join(page_arr))
               wf.write("\n")
           if any("Page 2 of " in s for s in page_arr):
               wf.write("\n".join(page_arr))
               wf.write("\n")
           if any("Page 3 of " in s for s in page_arr):
               wf.write("\n".join(page_arr))
               wf.write("\n")
           if any("Page 4 of " in s for s in page_arr):
               wf.write("\n".join(page_arr))
               wf.write("\n")
           page_arr=[]
           page_arr.append(line);
           continue;
       next_page='TRUE'
       page_arr.append(line);

  f.close();
  wf.close();

  line_string="pdf_file_gen_year,pdf_file_gen_month,pdf_file_gen_date,pdf_file_name,quote_id,billing_account_number,order_date,order_type,order_number,first_name,last_name,address_line1,address_line2,city,state,zip,monthly_recurring_charges,prorated_charges,fees_and_surcharges,taxes,first_month_bill,second_month_bill"
  pdf_file_name=""
  i=0;
  found_address="NO"
  running_line_string=line_string
  read_cnt=5
  name_addr_arr=[]
  page_arr=[];
  ord_acc_ref_arr=[];
  next_page="FALSE"

  date_pattern=re.compile("(\d+-\d+-\d+-\d+-\d+-\d+)")
  str_date_fielded=str(get_date(actual_pdf_file,date_pattern))
  if(str_date_fielded != 'None'):
    date_str_arr=str_date_fielded.split('-')
    tmp_date_fmt=datetime.date(int(date_str_arr[0]),int(date_str_arr[1]),int(date_str_arr[2]))

  tmp_year=tmp_date_fmt.strftime("%Y")
  tmp_month=tmp_date_fmt.strftime("%m")
  tmp_date_str=str_date_fielded


  wf = open(output_file,"a");
  exists=os.path.isfile(output_file)
  if not exists:
     wf.write(line_string+"\n")
     wf.write(",,,,,,,,,,,,,"+"\n")
  pattern=re.compile("^Page \d+ *$")
  empty_line_pattern=re.compile("^ *$");

  with open(tmp_inter_file,'r') as f:
    for line_with_blanks in f:
       line = line_with_blanks.rstrip().replace("
Page","Page")

       match_string=pattern.match(line)
       page_arr.append(line);

  mrc_index=0
  index = [idx for idx, s in enumerate(page_arr) if "Page 1 of " in s][0]
  index2= [idx for idx, s in enumerate(page_arr) if "Order Date:" in s][0]
  index3= [idx for idx, s in enumerate(page_arr) if "Order Number:" in s][0]
  index4= [idx for idx, s in enumerate(page_arr) if "Account Number:" in s][0]
  index5= [idx for idx, s in enumerate(page_arr) if "Reference:" in s][0]
  second_time='FALSE'

  ### find address
  for item in page_arr[index:]:
      found_empty_line=empty_line_pattern.match(item)
      if (found_empty_line!=None and second_time=='TRUE'):
           second_time='FALSE'
           if len(name_addr_arr) >= 3:

               # name info
               name_arr=name_addr_arr[1].split()

               running_line_string=running_line_string.replace("first_name",name_arr[0])
               if len(name_arr) >2:
                   running_line_string=running_line_string.replace("last_name",name_arr[2])
               elif len(name_arr)==1:
                   running_line_string=running_line_string.replace("last_name","")
               else:
                   running_line_string=running_line_string.replace("last_name",name_arr[1])

               #state and zip info
               state_zip_arr=name_addr_arr[-1].split()
               if len(state_zip_arr) == 3:
                  running_line_string=running_line_string.replace("city",state_zip_arr[0].rstrip(','))
                  running_line_string=running_line_string.replace("state",state_zip_arr[1])
                  running_line_string=running_line_string.replace("zip",state_zip_arr[2])
               elif len(state_zip_arr) == 5:
                  running_line_string=running_line_string.replace("city",state_zip_arr[0]+" "+state_zip_arr[1].rstrip(','))
                  running_line_string=running_line_string.replace("state",state_zip_arr[2])
                  running_line_string=running_line_string.replace("zip",state_zip_arr[3])
               elif len(state_zip_arr) == 6:
                  running_line_string=running_line_string.replace("city",state_zip_arr[0]+" "+state_zip_arr[1]+" "+state_zip_arr[2].rstrip(','))
                  running_line_string=running_line_string.replace("state",state_zip_arr[3])
                  running_line_string=running_line_string.replace("zip",state_zip_arr[4])
               elif len(state_zip_arr) < 3:
                  running_line_string=running_line_string.replace("city",state_zip_arr[0].rstrip(','))
                  running_line_string=running_line_string.replace("state",'')
                  running_line_string=running_line_string.replace("zip",'')
               else:
                  running_line_string=running_line_string.replace("city",state_zip_arr[0].rstrip(','))
                  running_line_string=running_line_string.replace("state",state_zip_arr[len(state_zip_arr)-3])
                  running_line_string=running_line_string.replace("zip",state_zip_arr[len(state_zip_arr)-2])

               #address info
               running_line_string=running_line_string.replace("address_line1",name_addr_arr[2])
               running_line_string=running_line_string.replace("address_line2"," ".join(name_addr_arr[3:len(name_addr_arr)-3] ))
               break;
      elif  (found_empty_line!=None and second_time=='FALSE'):
              name_addr_arr.append(item)
              second_time='TRUE'
      elif (second_time=='TRUE'):
              if(item == "Welcome!"):
                running_line_string=running_line_string.replace("first_name",'')
                running_line_string=running_line_string.replace("last_name",'')
                running_line_string=running_line_string.replace("address_line1",'')
                running_line_string=running_line_string.replace("address_line2",'')
                running_line_string=running_line_string.replace("city",'')
                running_line_string=running_line_string.replace("state",'')
                running_line_string=running_line_string.replace("zip",'')
                break;
              name_addr_arr.append(item)

  ### find page number
  running_line_string=running_line_string.replace("pdf_file_name",actual_pdf_file)
  orddate_key,orddate_value=page_arr[index2].split(':')
  ordnum_lst=page_arr[index3].split(':')
  if(len(ordnum_lst)==2):
    running_line_string=running_line_string.replace("order_number",'')
    running_line_string=running_line_string.replace("order_type",'')
  else:
    ordnum_key,ord_type,ordnum_value=page_arr[index3].split(':')
    running_line_string=running_line_string.replace("order_number",ordnum_value.lstrip())
    running_line_string=running_line_string.replace("order_type",ord_type.lstrip())
  accnum_key,accnum_value=page_arr[index4].split(':',1)
  quoteid_key,quoteid_value=page_arr[index5].split(':',1)
  running_line_string=running_line_string.replace("order_date",orddate_value.lstrip())
  running_line_string=running_line_string.replace("billing_account_number",accnum_value.lstrip())
  running_line_string=running_line_string.replace("quote_id",quoteid_value.lstrip())

  if any("Monthly Recurring Charges for Services Ordered" in s for s in page_arr):
      mrc_index= [idx for idx, s in enumerate(page_arr) if "Monthly Recurring Charges for Services Ordered" in s][0]

  if(mrc_index):
     mrc_amount_arr = [float(s) for s in re.findall(r'-?\d+\.?\d*',page_arr[mrc_index])]
     mrc_amount='%.2f' % mrc_amount_arr[0]
     running_line_string=running_line_string.replace("monthly_recurring_charges","$"+str(mrc_amount))
  else:
     running_line_string=running_line_string.replace("monthly_recurring_charges",'')


  running_line_string=running_line_string.replace("pdf_file_gen_year",tmp_year)
  running_line_string=running_line_string.replace("pdf_file_gen_month",tmp_month)
  running_line_string=running_line_string.replace("pdf_file_gen_date",tmp_date_str)

  first_bill_index=0
  next_bill_index=0

  if any("Total Monthly Charges (" in s for s in page_arr):
     first_bill_index= [idx for idx, s in enumerate(page_arr) if "Total Monthly Charges (" in s][0]
  if any("Total Next Bill " in s for s in page_arr):
     next_bill_index= [idx for idx, s in enumerate(page_arr) if "Total Next Bill " in s][0]

  if(first_bill_index):
     first_amount_arr = [float(s) for s in re.findall(r'-?\d+\.?\d*',page_arr[first_bill_index])]
     first_bill='%.2f' % first_amount_arr[0]
     running_line_string=running_line_string.replace("first_month_bill","$"+str(first_bill))
  else:
     running_line_string=running_line_string.replace("first_month_bill",'')

  if(next_bill_index):
     next_amount_arr = [float(s) for s in re.findall(r'-?\d+\.?\d*',page_arr[next_bill_index])]
     next_bill='%.2f' % next_amount_arr[0]
     running_line_string=running_line_string.replace("second_month_bill","$"+str(next_bill))
  else:
     running_line_string=running_line_string.replace("second_month_bill",'')

  prorated_charges_index=0
  fees_sur_index=0
  taxes_index=0

  regex = re.compile('^\$\d+.\d+Prorated Charges')
  if any(regex.match(s) for s in page_arr):
     prorated_charges_index= [idx for idx, s in enumerate(page_arr) if regex.match(s)][0]
  if any("Fees and Surcharges" in s for s in page_arr):
     fees_sur_index= [idx for idx, s in enumerate(page_arr) if "Fees and Surcharges" in s][0]
  if any("Taxes" in s for s in page_arr):
     taxes_index= [idx for idx, s in enumerate(page_arr) if "Taxes" in s][0]

  if(prorated_charges_index):
     prc_amount_arr = [float(s) for s in re.findall(r'-?\d+\.?\d*',page_arr[prorated_charges_index])]
     prc_amount='%.2f' % prc_amount_arr[0]
     running_line_string=running_line_string.replace("prorated_charges","$"+str(prc_amount))
  else:
     running_line_string=running_line_string.replace("prorated_charges",'')

  if(fees_sur_index):
     fees_sur_amount_arr = [float(s) for s in re.findall(r'-?\d+\.?\d*',page_arr[fees_sur_index])]
     fees_sur_amount='%.2f' % fees_sur_amount_arr[0]
     running_line_string=running_line_string.replace("fees_and_surcharges","$"+str(fees_sur_amount))
  else:
     running_line_string=running_line_string.replace("fees_and_surcharges",'')

  if(taxes_index):
     taxes_amount_arr = [float(s) for s in re.findall(r'-?\d+\.?\d*',page_arr[taxes_index])]
     tax_amount='%.2f' % taxes_amount_arr[0]
     running_line_string=running_line_string.replace("taxes","$"+str(tax_amount))
  else:
     running_line_string=running_line_string.replace("taxes",'')

  wf.write(running_line_string+"\n")

  running_line_string=running_line_string.replace("pdf_file_name",'')
  running_line_string=running_line_string.replace("order_date",'')
  running_line_string=running_line_string.replace("order_number",'')
  running_line_string=running_line_string.replace("order_type",'')
  running_line_string=running_line_string.replace("billing_account_number",'')
  running_line_string=running_line_string.replace("quote_id",'')
  running_line_string=running_line_string.replace("first_name",'')
  running_line_string=running_line_string.replace("last_name",'')
  running_line_string=running_line_string.replace("address_line1",'')
  running_line_string=running_line_string.replace("address_line2",'')
  running_line_string=running_line_string.replace("city",'')
  running_line_string=running_line_string.replace("state",'')
  running_line_string=running_line_string.replace("zip",'')
  running_line_string=running_line_string.replace("first_month_bill",'')
  running_line_string=running_line_string.replace("second_month_bill",'')
  running_line_string=running_line_string.replace("monthly_recurring_charges",'')
  running_line_string=running_line_string.replace("prorated_charges",'')
  running_line_string=running_line_string.replace("taxes",'')
  running_line_string=running_line_string.replace("fees_and_surcharges",'')


  #wf.write(running_line_string+"\n")
  page_arr=[]
  name_addr_arr=[]

  f.close();
  wf.close();


if __name__ == '__main__':
   sys.exit(main(sys.argv))

