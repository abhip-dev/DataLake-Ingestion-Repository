#!/bin/bash
###############################################################################
# Author : Srivatsa K Nagaraja
# Date  :  08/09/2019
#
#################################################################################

script=`basename "$0"| cut -d "." -f 1`
v_date=`date '+%m_%d_%Y_%H_%M_%S'`
v_log_file=_${v_date}.log
DATETIME=`date '+%y%m%d_%H%M%S'`
app_dir='/data/CTL/ingest/lvcht_interaction/scripts'
log_dir='/data/CTL/ingest/lvcht_interaction/logs'
log_file=${log_dir}/onetime_${DATETIME}.log

#-----------------------------------------------------------------
# Function to log
#-----------------------------------------------------------------
function printMsg ()
{
  echo "<${DATETIME}>: $@" >> ${log_file}
  echo "<${DATETIME}>: $@"
  return
}

#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
function sendEmail ()
{
    EMAIL_SUB="CDH_DEV_${script}_failed_@_${DATETIME}"
    EMAIL_ID="ab09507@centurylink.com"
    # EMAIL_ID="IT-DATALAKE-DEV@centurylink.com"
    echo "Failed Processing: Please check log file for further details." | mail -s ${EMAIL_SUB} -a ${log_file} ${EMAIL_ID}
    sleep 1s
    return
}

#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
function check_status()
{
    lastCommandStatus=$?

  if [ $lastCommandStatus -ne 0 ]; then
     printMsg $1
         printMsg "FAILED"
         echo "Script FAILED"
     sendEmail
     exit 1
  else
          printMsg $1
          printMsg "Command Successful."
          sleep 1s
          return
  fi

}

count=0
txt_file='/data/CTL/ingest/lvcht_interaction/config/last_ext_date.txt'
while [ $count -lt 3 ]
do
        start_time=`cat $txt_file`
        new_start_time=${start_time:0:10}
        tmp_date=$(TZ="UTC" date -d"$(date -d @$new_start_time) +3 hours" +'%Y-%m-%d %H:%M:%S')
        end_time1=`date -d "$tmp_date UTC" +%s`
        end_time=$end_time1'000'
        printMsg "Start time: $start_time"
        printMsg "End time: $end_time"
        printMsg "Seq Number: $count"

        hdfs dfs -rm -f /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_json_work/*.json
        check_status "hdfs dfs -rm -f /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_json_work/*.json"
        printMsg "HDFS rm completed"

        export PATH=/opt/tools/python/bin:$PATH:$HOME/.local/bin:$HOME/bin

        python $app_dir/lvcht_interactions_get_json.py $start_time $end_time
        check_status "python $app_dir/lvcht_interactions_get_json.py $start_time $end_time"
        printMsg "python script completed"

        hdfs dfs -put /data/CTL/ingest/lvcht_interaction/incoming/*.json /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_json_work
        check_status "hdfs dfs -put /data/CTL/ingest/lvcht_interaction/incoming/*.json /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_json_work"
        printMsg "HDFS put completed"

                beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f /data/CTL/ingest/lvcht_interaction/scripts/hive_onetime/info.hql >$log_dir/tmp_info.log 2>&1
                check_status "beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f /data/CTL/ingest/lvcht_interaction/scripts/hive_onetime/info.hql >$log_dir/tmp_info.log 2>&1"
                printMsg "Info completed"

                beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f /data/CTL/ingest/lvcht_interaction/scripts/hive_onetime/transcript.hql >$log_dir/tmp_trans.log 2>&1
                check_status "beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f /data/CTL/ingest/lvcht_interaction/scripts/hive_onetime/transcript.hql >$log_dir/tmp_trans.log 2>&1"
                printMsg "transcript completed"


                beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f /data/CTL/ingest/lvcht_interaction/scripts/hive_onetime/visitorinfo.hql >$log_dir/tmp_visitor.log 2>&1
                check_status "beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f /data/CTL/ingest/lvcht_interaction/scripts/hive_onetime/visitorinfo.hql >$log_dir/tmp_visitor.log 2>&1"
                printMsg "visitorinfo completed"


                beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f /data/CTL/ingest/lvcht_interaction/scripts/hive_onetime/campaign.hql >$log_dir/tmp_campaign.log 2>&1
                check_status "beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f /data/CTL/ingest/lvcht_interaction/scripts/hive_onetime/campaign.hql >$log_dir/tmp_campaign.log 2>&1"
                printMsg "campaign completed"


                beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f /data/CTL/ingest/lvcht_interaction/scripts/hive_onetime/survey_prechat.hql >$log_dir/tmp_prechat.log 2>&1
                check_status "beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f /data/CTL/ingest/lvcht_interaction/scripts/hive_onetime/survey_prechat.hql >$log_dir/tmp_prechat.log 2>&1"
                printMsg "Prechat completed"


                beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f /data/CTL/ingest/lvcht_interaction/scripts/hive_onetime/survey_postchat.hql >$log_dir/tmp_postchat.log 2>&1
                check_status "beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f /data/CTL/ingest/lvcht_interaction/scripts/hive_onetime/survey_postchat.hql >$log_dir/tmp_postchat.log 2>&1"
                printMsg "Post chat completed"


                beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f /data/CTL/ingest/lvcht_interaction/scripts/hive_onetime/survey_operator.hql >$log_dir/tmp_operator.log 2>&1
                check_status "beeline -u "jdbc:hive2://polpcdhmn002.corp.intranet:10000/default;principal=hive/polpcdhmn002.corp.intranet@CTL.INTRANET;ssl=true" -f /data/CTL/ingest/lvcht_interaction/scripts/hive_onetime/survey_operator.hql >$log_dir/tmp_operator.log 2>&1"
                printMsg "Operator completed"


        rm /data/CTL/ingest/lvcht_interaction/incoming/*.json
        check_status "rm /data/CTL/ingest/lvcht_interaction/incoming/*.json"
        printMsg "Files removed"


        echo $end_time > /data/CTL/ingest/lvcht_interaction/config/last_ext_date.txt
        count=$((count+1))
        sleep 10s;

done

impala_stg_log=`impala-shell -k --ssl -i polpcdhdn021.corp.intranet -B -f /data/CTL/ingest/lvcht_interaction/scripts/hive_onetime/refresh_tables.sql 2>&1`
check_status "impala-shell -k --ssl -i polpcdhdn021.corp.intranet -B -f /data/CTL/ingest/lvcht_interaction/scripts/hive_onetime/refresh_tables.sql 2>&1"

exit 0;
