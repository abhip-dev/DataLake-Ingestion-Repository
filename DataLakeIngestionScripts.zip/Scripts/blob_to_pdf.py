#!/usr/bin/env python
##################################################################
#
# Script : blob_to_pdf.py
# Author : Srivatsa K Nagaraja
# Created : 08-Feb-2019
#
##################################################################
#
# This script is created to extract a blob column in Oracle and
# convert them to pdf to be stored in edge node (US285918)
#
############### Version History ##################################
#
# Initial Version - Created the script for US285918
#
##################################################################

import __main__
import os
import sys
import io
import datetime
import logging
import configparser
import cx_Oracle

def main():
    script_name = "blob_to_pdf.py"

#Path and files
    home_dir = '/data/CTL/ingest/q2b_qtcpdf'
    code_dir = home_dir+'/python_code/'
    tar_dir = home_dir+'/pdf/'
    log_dir = home_dir+'/log/ingest_pdf/'
    timestamp = datetime.datetime.utcnow().strftime('%Y.%m.%d.%H.%M.%S')
    log_name = script_name+'_{}.log'.format(timestamp)
    log_file = os.path.join(log_dir, log_name)
    logging.basicConfig(filename=log_file,level=logging.DEBUG)

##setting configuration file
    settings = configparser.ConfigParser()
    settings.read('/data/CTL/ingest/q2b_qtcpdf/python_code/settings.ini')
    settings.sections()

## reading data from blob_to_pdf_date.last file

    f=open(code_dir+"/blob_to_pdf_date.last", "r")
    start_time =f.read()

    logging.info("Fetching source data from:  "+start_time)

    query_max = "SELECT to_char(MAX(SYS_CREATION_DATE),'MM/DD/YYYY HH:MI:SS AM') from QTCPDF.QUOTE_PDF_DOC"
    try:
        con_v= settings.get('OracleSettings','OraUser') + "/" + settings.get('OracleSettings','OraPassWord') + "@" + settings.get('OracleSettings','OraConnect')
        con = cx_Oracle.connect(con_v)
        Scursor_1 = con.cursor()
        Scursor_1.execute(query_max)
        end_time = Scursor_1.fetchone()[0]
        logging.info("Capturing Maximun SYS_CREATION_DATE value which has been processed: " + end_time)
        query = "SELECT  quote_id || '_' || replace(to_char( SYS_CREATION_DATE,'yyyy-mm-dd hh24-mi-ss'),' ','-') || '.pdf' filename , QUOTE_BLOB  from QTCPDF.QUOTE_PDF_DOC where SYS_CREATION_DATE >TO_TIMESTAMP('" + start_time + "','MM/DD/YYYY HH:MI:SS AM') and SYS_CREATION_DATE <= TO_TIMESTAMP('" + end_time + "','MM/DD/YYYY HH:MI:SS AM') and length(QUOTE_BLOB) is not null"
        Scursor = con.cursor()
        Scursor.execute(query)
        logging.info(query)
        logging.info("Starting creating the PDF files")

##looping into cursor to fetch all records

        for row in Scursor:
            filename=tar_dir+row[0]
            pdf = row[1]
            write_pdf_file(pdf, filename)
            logging.info("PDF file created: "+filename)

        logging.info("Processing completed for creating PDF files")
        logging.info("Creating Text file to store max processed date")
        write_text_file(end_time,code_dir+"/blob_to_pdf_date.last")
        logging.info("Text file created")
        logging.info("End of processing")
        return_code = 0

    except Exception as e:
        logging.error(e)
        sys.exit(2)

    except Error as e:
        logging.error(e)
        sys.exit(2)


    finally:
         Scursor.close()
         Scursor_1.close()
         con.close()

def write_pdf_file(data, filename):

    with open(filename, 'wb') as f:
        f.write(data.read())
        f.close()

def write_text_file(data,filename):
    f = open(filename, "w")
    f.write(data)
    f.close()

# Actually run the script if calling from the command line
if __name__ == '__main__':
    exit(main())
