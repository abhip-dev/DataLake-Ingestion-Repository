  extn=_demo
  
  hdfs dfs -ls /data/CTL/encrypt/db/bdalab/Infinera/pm15min/data/h_* | cut -d "/" -f10 | grep -v "Found" | uniq > infinera_miss_tbl_lst
  cat infinera_miss_tbl_lst | while read line
  do
  count=0
    echo "line: $line"
    hdfs dfs -mkdir /data/CTL/encrypt/db/bdalab/Infinera/pm15min/data/$line$extn
    hdfs dfs -ls /data/CTL/encrypt/db/bdalab/Infinera/pm15min/data/$line/ | cut -d "/" -f11 | grep -v "Found" > infinera_device_lst
	cat infinera_device_lst | while read line1
	do
	 echo "line1: $line1"
	  hdfs dfs -ls /data/CTL/encrypt/db/bdalab/Infinera/pm15min/data/$line/$line1 | cut -d "/" -f12 |  grep -v "Found" >  infinera_dt_part_lst
	  cat infinera_dt_part_lst | while read line2
	  do
	    echo "line2: $line2"
	    hdfs dfs -ls /data/CTL/encrypt/db/bdalab/Infinera/pm15min/data/$line/$line1/$line2 | grep -v -i "success" | tr -s " " | cut -d " " -f8 | grep -v "^$" > copy_file_lst
	    cat copy_file_lst | while read line3
		do
		  count=$(($count + 1))
		  echo "line3: $line3"
		  echo "count: $count"
		  hdfs dfs -cp $line3 /data/CTL/encrypt/db/bdalab/Infinera/pm15min/data/$line$extn/part-$line1-$line2-$count
	    done
	 done
   done
 done  
