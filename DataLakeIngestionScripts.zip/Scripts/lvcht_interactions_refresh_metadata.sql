REFRESH lvcht.interaction_info;

REFRESH lvcht.interaction_campaign;

REFRESH lvcht.interaction_linescores;

REFRESH lvcht.interaction_survey_operator;

REFRESH lvcht.interaction_survey_postchat;

REFRESH lvcht.interaction_survey_prechat;

REFRESH lvcht.interaction_sdes_customerinfo;

REFRESH lvcht.interaction_sdes_cartstatus;

REFRESH lvcht.interaction_sdes_lead;

REFRESH lvcht.interaction_sdes_marketingcampaigninfo;

REFRESH lvcht.interaction_sdes_personalinfo;

REFRESH lvcht.interaction_sdes_purchase;

REFRESH lvcht.interaction_sdes_searchcontent;

REFRESH lvcht.interaction_sdes_serviceactivity;

REFRESH lvcht.interaction_sdes_visitorerror;

REFRESH lvcht.interaction_sdes_viewedProduct;

REFRESH lvcht.interaction_visitorinfo;
