#############################################################################################################################################################
#  Script Shell : bash
#  Script       : lvcht_file_ingest.sh
#  Authors      : Kumar Abhishek
#  Description  : Ingest all the Incoming data files into hdfs(Data Lake)
#  14/03/2019, AC38815: Validate gz files in Tag files, Convert JSON text files into AVRO binary, put the Avro binary file to hdfs
#############################################################################################################################################################

#!/bin/bash
export PATH=/opt/cloudera/parcels/Anaconda/bin:$PATH
kinit -kt /home/cdlapp/cdlapp.keytab cdlapp@CTL.INTRANET

script=`basename "$0"| cut -d "." -f1`
DATETIME=`date '+%y%m%d_%H%M%S'`
#home_dir=/data/CTL/ingest
home_dir=/data/CTL/ingest
TABLE_NAME=$1

if [ -z ${TABLE_NAME} ]
then
        echo "Table name is NULL"
        echo "Invalid. Pass table name as input variable"
        echo "Example: lvcht_file_ingest.sh TABLE_NAME"
        exit 1
fi
#-----------------------------------------------------------------
# The incoming directory
#-----------------------------------------------------------------
#incoming_data_dir=/sftp/lvchtcdl/incoming
incoming_data_dir=/sftp/lvchtcdl/incoming

#-----------------------------------------------------------------
# endPointUrl
#-----------------------------------------------------------------
endPointUrl=https://cxg7i.corp.intranet/rest/liveEngage

#-----------------------------------------------------------------
# Schema for avro files
#-----------------------------------------------------------------
avro_schema=${home_dir}/lvcht/schema/livePerson.avsc

#-----------------------------------------------------------------
#This section controls all local paths, local file names, and hdfs dir
#-----------------------------------------------------------------
script_dir=${home_dir}/lvcht/script
archive_dir=${home_dir}/lvcht/archive
staging_dir=${home_dir}/lvcht/staging
script_log_dir=${home_dir}/lvcht/log
config_dir=${home_dir}/lvcht/config
temp_dir=${home_dir}/lvcht/temp
bad_dir=${home_dir}/lvcht/badfiles

hdfsDirName=${TABLE_NAME}
hdfs_dir=/data/CTL/encrypt/db/ingest/raw/lvcht

log_file=${script_log_dir}/${script}_${DATETIME}_${TABLE_NAME}.log
echo "Access the log file here: "${log_file}

typeset -i EPOCH_START_TIME

#-----------------------------------------------------------------
#Sourcing the properties for the Oozie jobs
#-----------------------------------------------------------------
#source ${config_dir}/job.properties

#-----------------------------------------------------------------
# Function to log
#-----------------------------------------------------------------
function printMsg ()
{
        echo "<${DATETIME}>: $@" >> ${log_file}
        echo "<${DATETIME}>: $@"
        return
}

#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
function sendEmail ()
{
        EMAIL_SUB="CDH_DEV_${script}_failed_@_${DATETIME}"
        #EMAIL_ID="abhishek.kumar2@centurylink.com"
        EMAIL_ID="IT-DATALAKE-DEV@centurylink.com"
        echo "Failed Processing: Please check log file for further details." | mail -s ${EMAIL_SUB} -a ${log_file} ${EMAIL_ID}
        sleep 1s
        return
}

#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
function check_status()
{
        lastCommandStatus=$?
        if [ $lastCommandStatus -ne 0 ]; then
                printMsg $1
                printMsg "FAILED"
                echo "Script FAILED"
                sendEmail
                exit 1
        else
                printMsg $1
                printMsg "Command Successful."
                sleep 1s
                return
        fi
}

# -----------------------------------------------------------------
# Find log files to be purged
# Input: number if days to retain logs
# -----------------------------------------------------------------
function purgeLogs()
{
printMsg "Log files older than 30 days"
cd ${script_log_dir}
logfileCount=$(find ${script_log_dir}/${script}_${DATETIME}_${TABLE_NAME}*.log -mtime +30 | wc -l)

if [ ${logfileCount} -ne 0 ]; then
        printMsg "Number of log files older than 30 days:" ${logfileCount}
        find *.log -mtime +30 -exec rm {} \;
        check_status "find *.log -mtime +30 -exec rm {} \;"
        printMsg "${logfileCount} Logs purged"
else
        printMsg "No log files older than 30 days."
        printMsg "End Script."
fi
}

printMsg "Start script execution:" ${script}

#-----------------------------------------------------------------
# Purge staging directory
#-----------------------------------------------------------------
printMsg "Clearing Staging and Temporary directories."
rm -f ${staging_dir}/${TABLE_NAME}*
rm -f ${config_dir}/${TABLE_NAME}_list
rm -f ${temp_dir}/${TABLE_NAME}_file_list_hist.lst
rm -f ${bad_dir}/${TABLE_NAME}.bad

#-----------------------------------------------------------------
# Process all the .gz files
#-----------------------------------------------------------------
printMsg "Collect number of .gz files associate to the table."
fileCount=$(find ${incoming_data_dir}/${TABLE_NAME}*.gz | wc -l)
printMsg "No. of files to be processed:"${fileCount}


#-----------------------------------------------------------------
# Validate the incoming tag files and corresponding gz files
#-----------------------------------------------------------------
if [ ${fileCount} -gt 0 ];
then
#-----------------------------------------------------------------
#Get the history file list from hdfs. If the gz file already exists in the history file, do no ingest again.
#-----------------------------------------------------------------
        if hdfs dfs -test -e /data/CTL/encrypt/db/ingest/raw/lvcht/config/${TABLE_NAME}_file_list_hist.lst;
        then
                printMsg "Get the gz Hist File List from HDFS"
                hdfs dfs -get /data/CTL/encrypt/db/ingest/raw/lvcht/config/${TABLE_NAME}_file_list_hist.lst ${temp_dir}
        else
                printMsg "WARN: ${TABLE_NAME}_file_list_hist.lst not found on HDFS. Creating new one."
                touch ${temp_dir}/${TABLE_NAME}_file_list_hist.lst
        fi

        #-----------------------------------------------------------------
        #list all the Tag file by sorting on the basis of epoch start time and process
        #-----------------------------------------------------------------
        ls -l ${incoming_data_dir}/${TABLE_NAME}*.gz | cut -d "/" -f5 |sort -t "." -k2 | while read gz_file
        do
                #testing the gzip file
                gzip -t ${incoming_data_dir}/$gz_file
                if [ $? -ne 0 ]; then
                  printMsg " $gz_file File seems to be corrupt"
                  echo $gz_file >> ${bad_dir}/${TABLE_NAME}.bad
                fi
                printMsg "Processing: "${gz_file}

        #-----------------------------------------------------------------
        #check if the file has been previously processed
        #-----------------------------------------------------------------
                echo "grep ${gz_file} ${temp_dir}/${TABLE_NAME}_file_list_hist.lst"
                file_already_proc=$(grep ${gz_file} ${temp_dir}/${TABLE_NAME}_file_list_hist.lst | wc -l)
                if [ ${file_already_proc} -ne 0 ];
                then
                #-----------------------------------------------------------------
                #File exists previously and need not be reprocessed
                #-----------------------------------------------------------------
                        echo ${file_already_proc}
                        printMsg "File already ingested: "${gz_file}
                        mv ${incoming_data_dir}/${gz_file} ${archive_dir}

                #-----------------------------------------------------------------
                #If file not ingested previously, add to the history file list
                #-----------------------------------------------------------------
                else
                        echo ${gz_file} >> ${temp_dir}/${TABLE_NAME}_file_list_hist.lst

                #-----------------------------------------------------------------
                #Getting start epoch time from gz files in incoming directory to
                #convert it into Human Readable format and use while writing files into hdfs
                #-----------------------------------------------------------------
                        EPOCH_START_TIME=`find ${incoming_data_dir}/${gz_file} | cut -d '/' -f5 | cut -d '.' -f2 | cut -c1-10`
                        printMsg "epoch time: "${EPOCH_START_TIME}
                #-----------------------------------------------------------------
                #Converting epoch start time to Human Readable time
                #-----------------------------------------------------------------
                        file_date=`date -d @${EPOCH_START_TIME} +"%Y%m%d"`
                        printMsg "file suffix: "${file_date}
                #-----------------------------------------------------------------
                #Concatenating all the gz files on daily basis
                #-----------------------------------------------------------------
                        zcat ${incoming_data_dir}/${gz_file} >> ${staging_dir}/${TABLE_NAME}_${file_date}.temp
                        check_status "zcat ${gz_sort_file} >> ${staging_dir}/${TABLE_NAME}_${file_date}.temp"
                #-----------------------------------------------------------------
                #Moving gz file from incoming directory after processing.
                #-----------------------------------------------------------------
                        mv ${incoming_data_dir}/${gz_file} ${archive_dir}
                        check_status "mv ${gz_sort_file} ${archive_dir}"
                fi
        done
#-----------------------------------------------------------------
#Move the list file hist to HDFS
#-----------------------------------------------------------------
hdfs dfs -mkdir -p ${hdfs_dir}/config/
check_status "hdfs dfs -mkdir -p /data/CTL/encrypt/db/ingest/raw/lvcht/config/"

hdfs dfs -put -f ${temp_dir}/${TABLE_NAME}_file_list_hist.lst /data/CTL/encrypt/db/ingest/raw/lvcht/config/
check_status "hdfs dfs -put -f ${temp_dir}/${TABLE_NAME}_file_list_hist.lst /data/CTL/encrypt/db/ingest/raw/lvcht/config/"

#-----------------------------------------------------------------
#list all the zcat_file from staging directory in sorting order
#-----------------------------------------------------------------
        concat_file_count=$(ls -ltr ${staging_dir}/${TABLE_NAME}_*.temp|wc -l)
        if [ ${concat_file_count} -ne 0 ];
        then
                ls -ltr ${staging_dir}/${TABLE_NAME}_*.temp | cut -d '/' -f7 | sort -t '.' -k2 | while read zcat_file
                do
                #-----------------------------------------------------------------
                #getting date value from zcat_file to append in the Avro Binary File
                #-----------------------------------------------------------------
                        avro_file_dt=`ls -l ${staging_dir}/${zcat_file} | cut -d '/' -f7 | cut -d '_' -f2 | cut -d '.' -f1`
                        avro_file_yrMnth=`find ${staging_dir}/${zcat_file} | cut -d '/' -f7 | cut -d '_' -f2 | cut -d '.' -f1 | cut -c1-6`
                        check_status "avro_file_dt=`find ${staging_dir}/${zcat_file} | cut -d "/" -f10 | cut -d "_" -f2 | cut -d "." -f1`"
                #-----------------------------------------------------------------
                #If AVRO file already exists, GET the file and concat to new data
                #-----------------------------------------------------------------
                if hdfs dfs -test -e ${hdfs_dir}/AVRO/${TABLE_NAME}/yr_mnth=${avro_file_yrMnth}/${TABLE_NAME}_${avro_file_dt}.avro;
                then
                        printMsg "Merge the existing AVRO file with new data"
                        hdfs dfs -get ${hdfs_dir}/AVRO/${TABLE_NAME}/yr_mnth=${avro_file_yrMnth}/${TABLE_NAME}_${avro_file_dt}.avro ${staging_dir}
                        avro-tools tojson ${staging_dir}/${TABLE_NAME}_${avro_file_dt}.avro >> ${TABLE_NAME}_${avro_file_dt}.temp
                        printMsg "Convert Concatenated files ${zcat_file} to AVRO Binary"
                        avro-tools fromjson ${staging_dir}/${zcat_file} --schema-file ${avro_schema} > ${staging_dir}/${TABLE_NAME}_${avro_file_dt}.avro
                        check_status "avro-tools fromjson ${staging_dir}/${zcat_file} --schema-file ${avro_schema} > ${staging_dir}/${TABLE_NAME}_${avro_file_dt}.avro"


                #-----------------------------------------------------------------
                #Using Avro json text file and schema file, converting to Avro Binary File
                #-----------------------------------------------------------------
                else
                        printMsg "Convert Concatenated files ${zcat_file} to AVRO Binary"
                        avro-tools fromjson ${staging_dir}/${zcat_file} --schema-file ${avro_schema} > ${staging_dir}/${TABLE_NAME}_${avro_file_dt}.avro
                        check_status "avro-tools fromjson ${staging_dir}/${zcat_file} --schema-file ${avro_schema} > ${staging_dir}/${TABLE_NAME}_${avro_file_dt}.avro"
                fi

                #-----------------------------------------------------------------
                # - #make hdfs directory
                #-----------------------------------------------------------------
                        hdfs dfs -mkdir -p ${hdfs_dir}/AVRO/${TABLE_NAME}

                        hdfs dfs -mkdir -p ${hdfs_dir}/AVRO/${TABLE_NAME}/yr_mnth=${avro_file_yrMnth}
                        check_status "hdfs dfs -mkdir -p ${hdfs_dir}/AVRO/${TABLE_NAME}/${avro_file_yrMnth}"

                        hdfs dfs -put -f ${staging_dir}/${TABLE_NAME}_${avro_file_dt}.avro ${hdfs_dir}/AVRO/${TABLE_NAME}/yr_mnth=${avro_file_yrMnth}/${TABLE_NAME}_${avro_file_dt}.avro
                        check_status "hdfs dfs -put -f ${hdfs_dir}/${TABLE_NAME}_${avro_file_dt}.avro"


        #-----------------------------------------------------------------
        # creating config file in local which will get appended till loop ends
        #-----------------------------------------------------------------
                        printMsg "Moving ${hdfs_dir}/AVRO/${TABLE_NAME}/yr_mnth=${avro_file_yrMnth}/${TABLE_NAME}_${avro_file_dt}.avro to ${config_dir}/${TABLE_NAME}_list"
                        echo "${hdfs_dir}/AVRO/${TABLE_NAME}/yr_mnth=${avro_file_yrMnth}/${TABLE_NAME}_${avro_file_dt}.avro" >> ${config_dir}/${TABLE_NAME}_list

        #-----------------------------------------------------------------
        #Move zcat_file file to archive directory after procesing.
        #-----------------------------------------------------------------
                        rm ${staging_dir}/${zcat_file}
                        rm ${staging_dir}/${TABLE_NAME}_${avro_file_dt}.avro
                        check_status "mv ${staging_dir}/${zcat_file} ${archive_dir}/"
                done
        fi
else
                printMsg "No files found."
                touch ${config_dir}/${TABLE_NAME}_list
fi

#--------------------------------------------------------------------------------
# Creating Config directory if not exist in HDFS and moving AVRO list file to it
#--------------------------------------------------------------------------------
if hdfs dfs -test -d ${hdfs_dir}/config;
then
        printMsg "Moving AVRO list file to config HDFS config directory"
        hdfs dfs -put -f ${config_dir}/${TABLE_NAME}_list ${hdfs_dir}/config
else
        printMsg "Moving AVRO list file to config HDFS config directory"
fi

printMsg "Completed ingesting all available files for: "${TABLE_NAME}
###Error handling section #####

if [ -f ${bad_dir}/${TABLE_NAME}.bad ]; then
       echo "File contains bad .gz files, kindly check script /data/CTL/ingest/lvcht/script/lvcht_file_ingest.sh" | mailx -s "Bad .gz files" -a ${bad_dir}/${TABLE_NAME}.bad satyabrata.jena@centurylink.com
else
   echo "File contains no bad .gz files" | mailx -s "No bad .gz files" satyabrata.jena@centurylink.com
fi

exit 0
