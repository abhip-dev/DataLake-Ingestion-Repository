#!/bin/bash
###############################################################################
# Author : Srivatsa K Nagaraja
# Date  :  08/09/2019
#
#################################################################################

script=`basename "$0"| cut -d "." -f 1`
v_date=`date '+%m_%d_%Y_%H_%M_%S'`
v_log_file=_${v_date}.log
DATETIME=`date '+%y%m%d_%H%M%S'`
app_dir='/data/CTL/ingest/lvcht_interaction/scripts'
log_dir='/data/CTL/ingest/lvcht_interaction/logs'
log_file=${log_dir}/${script}_${DATETIME}.log
txt_file='/data/CTL/ingest/lvcht_interaction/config/last_ext_date.txt'
config_dir='/data/CTL/ingest/lvcht_interaction/config/'


#-----------------------------------------------------------------
# Function to log
#-----------------------------------------------------------------
function printMsg ()
{
  echo "<${DATETIME}>: $@" >> ${log_file}
  echo "<${DATETIME}>: $@"
  return
}

#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
function sendEmail ()
{
    EMAIL_SUB="CDH_PROD_${script}_failed_@_${DATETIME}"
    EMAIL_ID="ab09507@centurylink.com"
    echo "Failed Processing: Please check log file for further details." | mail -s ${EMAIL_SUB} -a ${log_file} ${EMAIL_ID}
    sleep 1s
    return
}

#-----------------------------------------------------------------
# Function to check the return status and send the appropriate email message
#-----------------------------------------------------------------
function check_status()
{
    lastCommandStatus=$?

  if [ $lastCommandStatus -ne 0 ]; then
     printMsg $1
         printMsg "FAILED"
         echo "Script FAILED"
     sendEmail
     exit 1
  else
          printMsg $1
          printMsg "Command Successful."
          sleep 1s
          return
  fi

}

# -----------------------------------------------------------------
# Find log files to be purged
# Input: number if days to retain logs
# -----------------------------------------------------------------
function purgeLogs()
{
printMsg "Log files older than 10 days"
cd ${log_dir}
logfileCount=$(find ${script}*.log -mtime +10 | wc -l)

if [ ${logfileCount} -ne 0 ]; then
        printMsg "Number of log files older than 10 days:" ${logfileCount}
        find *.log -mtime +10 -exec rm {} \;
        check_status "find *.log -mtime +10 -exec rm {} \;"
        printMsg "${logfileCount} Logs purged"
        else
        printMsg "No log files older than 10 days."
        printMsg "End Script."
fi
}


start_time=`cat $txt_file`
new_start_time=${start_time:0:10}
tmp_date=$(TZ="UTC" date -d"$(date -d @$new_start_time) +6 hours" +'%Y-%m-%d %H:%M:%S')
end_time1=`date -d "$tmp_date UTC" +%s`
end_time=$end_time1'000'
printMsg "Start time: $start_time"
printMsg "End time: $end_time"
curr_epoc_time=$(TZ="UTC" date +%s)
max_date=$(TZ="UTC" date -d"$(date -d @$curr_epoc_time) -6 hours" +'%Y-%m-%d %H:%M:%S')
max_epoc_time1=`date -d "$max_date UTC" +%s`
max_epoc_time=$max_epoc_time1'000'

curr_day=`date +"%d"`
par_mon=`date +"%Y%m" --date="1 months ago"`
printMsg "${curr_day} and ${par_mon}"

if [ ${curr_day} -eq 05 ]; then
  if [ ! -e ${config_dir}merge_small_files_${par_mon}.tag ] ; then

        printMsg "Running file merge process"

        spark2-submit $app_dir/merge_small_files_lvcht_updated.py lvcht interaction_info /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_info ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}
        check_status "spark2-submit merge_small_files_lvcht_updated.py lvcht interaction_info /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_info ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}"
        printMsg "interaction_info table merge completed for ${par_mon} month"

        spark2-submit $app_dir/merge_small_files_lvcht_updated.py lvcht interaction_campaign /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_campaign ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}
        check_status "spark2-submit merge_small_files_lvcht_updated.py lvcht interaction_campaign /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_campaign ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}"
        printMsg "interaction_campaign table merge completed for ${par_mon} month"

    spark2-submit $app_dir/merge_small_files_lvcht_updated.py lvcht interaction_visitorinfo /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_visitorInfo ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}
        check_status "spark2-submit merge_small_files_lvcht_updated.py lvcht interaction_visitorinfo /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_visitorinfo ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}"
        printMsg "interaction_visitorinfo table merge completed for ${par_mon} month"

    spark2-submit $app_dir/merge_small_files_lvcht_updated.py lvcht interaction_survey_operator /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_survey_operator ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}
        check_status "spark2-submit merge_small_files_lvcht_updated.py lvcht interaction_survey_operator /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_survey_operator ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}"
        printMsg "interaction_survey_operator table merge completed for ${par_mon} month"

    spark2-submit $app_dir/merge_small_files_lvcht_updated.py lvcht interaction_survey_postchat /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_survey_postchat ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}
        check_status "spark2-submit merge_small_files_lvcht_updated.py lvcht interaction_survey_postchat /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_survey_postchat ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}"
        printMsg "interaction_survey_postchat table merge completed for ${par_mon} month"

    spark2-submit $app_dir/merge_small_files_lvcht_updated.py lvcht interaction_survey_prechat /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_survey_prechat ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}
        check_status "spark2-submit merge_small_files_lvcht_updated.py lvcht interaction_survey_prechat /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_survey_prechat ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}"
        printMsg "interaction_survey_prechat table merge completed for ${par_mon} month"

    spark2-submit $app_dir/merge_small_files_lvcht_updated.py lvcht interaction_sdes_customerinfo /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_customerInfo ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}
        check_status "spark2-submit merge_small_files_lvcht_updated.py lvcht interaction_sdes_customerinfo /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_customerinfo ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}"
        printMsg "interaction_sdes_customerinfo table merge completed for ${par_mon} month"

    spark2-submit $app_dir/merge_small_files_lvcht_updated.py lvcht interaction_sdes_cartstatus /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_cartStatus ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}
        check_status "spark2-submit merge_small_files_lvcht_updated.py lvcht interaction_sdes_cartstatus /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_cartstatus ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}"
        printMsg "interaction_sdes_cartstatus table merge completed for ${par_mon} month"

    spark2-submit $app_dir/merge_small_files_lvcht_updated.py lvcht interaction_sdes_lead /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_lead ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}
        check_status "spark2-submit merge_small_files_lvcht_updated.py lvcht interaction_sdes_lead /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_lead ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}"
        printMsg "interaction_sdes_lead table merge completed for ${par_mon} month"

    spark2-submit $app_dir/merge_small_files_lvcht_updated.py lvcht interaction_sdes_marketingcampaigninfo /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_marketingCampaignInfo ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}
        check_status "spark2-submit merge_small_files_lvcht_updated.py lvcht interaction_sdes_marketingcampaigninfo /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_marketingcampaigninfo ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}"
        printMsg "interaction_sdes_marketingcampaigninfo table merge completed for ${par_mon} month"

    spark2-submit $app_dir/merge_small_files_lvcht_updated.py lvcht interaction_sdes_personalinfo /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_personalInfo ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}
        check_status "spark2-submit merge_small_files_lvcht_updated.py lvcht interaction_sdes_personalinfo /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_personalinfo ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}"
        printMsg "interaction_sdes_personalinfo table merge completed for ${par_mon} month"

    spark2-submit $app_dir/merge_small_files_lvcht_updated.py lvcht interaction_sdes_purchase /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_purchase ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}
        check_status "spark2-submit merge_small_files_lvcht_updated.py lvcht interaction_sdes_purchase /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_purchase ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}"
        printMsg "interaction_sdes_purchase table merge completed for ${par_mon} month"

    spark2-submit $app_dir/merge_small_files_lvcht_updated.py lvcht interaction_sdes_searchcontent /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_searchContent ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}
        check_status "spark2-submit merge_small_files_lvcht_updated.py lvcht interaction_sdes_searchcontent /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_searchcontent ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}"
        printMsg "interaction_sdes_searchcontent table merge completed for ${par_mon} month"

    spark2-submit $app_dir/merge_small_files_lvcht_updated.py lvcht interaction_sdes_serviceactivity /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_serviceActivity ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}
        check_status "spark2-submit merge_small_files_lvcht_updated.py lvcht interaction_sdes_serviceactivity /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_serviceactivity ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}"
        printMsg "interaction_sdes_serviceactivity table merge completed for ${par_mon} month"

    spark2-submit $app_dir/merge_small_files_lvcht_updated.py lvcht interaction_sdes_visitorerror /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_visitorError ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}
        check_status "spark2-submit merge_small_files_lvcht_updated.py lvcht interaction_sdes_visitorerror /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_sdes_visitorerror ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}"
        printMsg "interaction_sdes_visitorerror table merge completed for ${par_mon} month"

    spark2-submit $app_dir/merge_small_files_lvcht_updated.py lvcht interaction_transcript /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_transcript ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}
        check_status "spark2-submit merge_small_files_lvcht_updated.py lvcht interaction_transcript /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_transcript ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}"
        printMsg "interaction_transcript table merge completed for ${par_mon} month"

    spark2-submit $app_dir/merge_small_files_lvcht_updated.py lvcht interaction_linescores /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_linescores ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}
        check_status "spark2-submit merge_small_files_lvcht_updated.py lvcht interaction_linescores /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_linescores ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}"
        printMsg "interaction_linescores table merge completed for ${par_mon} month"

        spark2-submit $app_dir/merge_small_files_lvcht_updated.py lvcht interaction_linescores /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_linescores ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}
        check_status "spark2-submit merge_small_files_lvcht_updated.py lvcht interaction_linescores /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_linescores ['year_month=${par_mon}'] null null 350000000 --master yarn --deploy-mode cluster 2> ${log_file} >${log_file}"

        printMsg "interaction_linescores table merge completed for ${par_mon} month"

        printMsg "Completed small files merge"

        touch '${config_dir}merge_small_files_${par_mon}.tag'
    printMsg "Tag file created"

  fi
fi


if [ ${end_time} -le ${max_epoc_time} ]; then

        hdfs dfs -rm -f -skipTrash /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_json_work/*.json
        check_status "hdfs dfs -rm -f /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_json_work/*.json"
        printMsg "HDFS rm completed"

        hdfs dfs -rm -f -skipTrash /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_json_work_sdes/*.json
        check_status "hdfs dfs -rm -f /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_json_work_sdes/*.json"
        printMsg "HDFS rm completed"

        rm -f /data/CTL/ingest/lvcht_interaction/incoming/*.json
        check_status "rm -f /data/CTL/ingest/lvcht_interaction/incoming/*.json"
        printMsg "Files removed"

        export PATH=/opt/tools/python/bin:$PATH:$HOME/.local/bin:$HOME/bin

        python $app_dir/lvcht_interactions_get_json.py $start_time $end_time
        check_status "python $app_dir/lvcht_interactions_get_json.py $start_time $end_time"
        printMsg "python script completed"

        hdfs dfs -put /data/CTL/ingest/lvcht_interaction/incoming/*.json /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_json_work
        check_status "hdfs dfs -put /data/CTL/ingest/lvcht_interaction/incoming/*.json /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_json_work"
        printMsg "HDFS put completed"

        hdfs dfs -put /data/CTL/ingest/lvcht_interaction/incoming/*.json /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_json_work_sdes
        check_status "hdfs dfs -put /data/CTL/ingest/lvcht_interaction/incoming/*.json /data/CTL/encrypt/db/ingest/raw/lvcht/interaction_json_work_sdes"
        printMsg "HDFS SDES put completed"


        rm -f /data/CTL/ingest/lvcht_interaction/incoming/*.json
        check_status "rm -f /data/CTL/ingest/lvcht_interaction/incoming/*.json"
        printMsg "Files removed"


        echo $end_time > $txt_file

        purgeLogs
        printMsg "Script completed successfully"
        exit 0;
else
        printMsg "Source data is not refreshed, please restart after 1 hour"
        exit 1;
fi
