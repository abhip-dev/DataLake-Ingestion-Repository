#!/usr/bin/env python

#########################################################################################################################################################
### pyspark script to merge multiple small files or split large files to approximately the size of avg hdfs block                                     ###
### size.                                                                                                                                             ###
### Author --> NAVNEET KAUR                                                                                                                           ###
### Input parameters --> This script takes five input params                                                                                          ###
### 1. HIVE_SCHEMA: This is the name of concerned database                                                                                            ###
### 2. HIVE_TABLE: This is the name of concerned table                                                                                                ###
### 3. DB_DIR: The location of concerned table on hdfs                                                                                                ###
### 4. PARTITION_COLS: Name of partition columns if concerned table has any( This parameter will be passed as NULL if no partitioning is there)       ###
### 5. BUCKET_COLS :Name of bucketing columns if concerned table has any( This parameter will be passed as NULL if no bucketing is there)             ###
### 6. NUM_BUCKETS : Number of buckets                                                                                                                ###
###                                                                                                                                                   ###
### Example 1(Table with no partition no bucketing): spark2-submit merge-small-files.py ilm document /data/CTL/encrypt/db/ingest/raw/ilm/document     ###
###           null null null                                                                                                                          ###
### Example 2(Table with just partition columns) : spark2-submit merge-small-files.py ilm document /data/CTL/encrypt/db/ingest/raw/ilm/document       ###
###           [part_col1,part_col2.... part_coln] null null                                                                                           ###
### Example 3(Table with partition and bucketing) :  spark2-submit merge-small-files.py ilm document /data/CTL/encrypt/db/ingest/raw/ilm/document     ###
###           [part_col1,part_col2,......partcoln] [bucket_col1,bucket_col2....bucket_coln] 256                                                       ###
#########################################################################################################################################################

from __future__ import division
from pyspark.sql import SparkSession
import sys
import pyspark
from pyspark.conf import SparkConf
from pyspark import SparkContext
from pyspark.sql.functions import *
from pyspark.sql import HiveContext
import datetime
import commands
import math
import subprocess

HIVE_SCHEMA=sys.argv[1]
HIVE_TABLE=sys.argv[2]
DB_DIR=sys.argv[3]
PARTITION_COLS=sys.argv[4].strip('[]')
BUCKET_COLS=sys.argv[5].strip('[]')
NUM_BUCKETS=sys.argv[6]
FILE_SIZE=sys.argv[7]
PART_CONTINUE=0
sconf = pyspark.SparkConf()

###############################################################################################################
### -*- setting required configs for hive, spark sql and yarn in sparkContext and initializing SparkSession -*-
###############################################################################################################

sconf.set("hive.metastore.uris", "thrift://poldcdhmn003.dev.intranet:9083")
sconf.set("spark.shuffle.service.enabled", "true")
sconf.set("yarn.nodemanager.pmem-check-enabled", "false")
sconf.set("yarn.nodemanager.vmem-check-enabled", "false")
sconf.set("spark.dynamicAllocation.enabled", "true")
sconf.set("spark.dynamicAllocation.minExecutors", "1")
sconf.set("spark.dynamicAllocation.maxExecutors", "500")
sconf.set("spark.dynamicAllocation.initialExecutors", "10")
sconf.set("spark.yarn.executor.memoryOverhead", "10G")
sconf.set("spark.sql.warehouse.dir", "/user/hive/warehouse")
sconf.set("hive.metastore.execute.setugi", "true")
sconf.set("hive.exec.dynamic.partition", "true")
sconf.set("hive.exec.dynamic.partition.mode", "nonstrict")
sconf.set("hive.merge.sparkfiles", "true")
sconf.set("spark.sql.parquet.compression.codec", "snappy")
sconf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
sconf.set("spark.sql.inMemoryColumnarStorage.compressed", "true")
sconf.set("spark.hadoop.parquet.enable.summary-metadata", "false")
sconf.set("spark.hadoop.mapreduce.fileoutputcommitter.marksuccessfuljobs", "false")
sconf.set("spark.network.timeout","60s")
sconf.set("spark.sql.files.maxPartitionBytes","140000000")


spark = SparkSession.builder.appName('mergeSmallFiles').config(conf=sconf).getOrCreate()

temp_table = "_temp_" + str(datetime.datetime.today().strftime('%Y_%m_%d'))

######################################################
### -*- Merge partitioned/partition-bucketed files -*-
######################################################

def merge_partitioned_table( isBucketed ):
        all_partitions = spark.sql("SHOW PARTITIONS "+ HIVE_SCHEMA+"."+HIVE_TABLE)
        part_count=0;
	part_processed_count= PART_CONTINUE;

        for partition in all_partitions.collect():
		part_count= part_count + 1
		print ("****Processing partition :" + str(part_count))

		if int(PART_CONTINUE) > 0 and part_count < int(PART_CONTINUE) :
			continue	

                current_dir = DB_DIR + "/" + str(partition).replace("Row(partition=u'","").replace("')","")
                proc = subprocess.Popen(['hadoop', 'fs', '-test', '-e', current_dir])
                proc.communicate()

                if proc.returncode != 0:
                        print '%s does not exist' % current_dir
                else :
                        print '%s exist' % current_dir
                        current_part = str(partition).replace("Row(partition=u'","").replace("=","='").replace(r"/","' AND ").replace("')","'")
                        part_df = spark.sql("SELECT * from "+ HIVE_SCHEMA + "." + HIVE_TABLE +" WHERE "+ current_part)
                        part_row_count = part_df.count()
			
			if part_row_count > 0 :
				if isBucketed == False :
 	                               part_hdir_size = commands.getoutput("hdfs dfs -du -s " + current_dir + " |awk \'{print $1}\'")
                                       part_num_files = math.ceil(int(part_hdir_size)/int(FILE_SIZE));
                                       part_df.write.format("parquet").mode("overwrite").saveAsTable(HIVE_SCHEMA + "." + HIVE_TABLE+ temp_table)
                                else :
                                       part_df.repartition(int(NUM_BUCKETS),BUCKET_COLS).write.format("parquet").mode("overwrite").saveAsTable(HIVE_SCHEMA + "." + HIVE_TABLE+ temp_table)

        	                part_df_temp = spark.table(HIVE_SCHEMA + "." + HIVE_TABLE + temp_table)
                	        part_temp_row_count = part_df_temp.count()

                        	if part_row_count != part_temp_row_count :
                                	print("****Row count for partition did not match. Org row count =" + str(part_row_count) + ", Temp row count =" + str(part_temp_row_count) + ". So skipping file merge.")
					exit()
                        	else :
                                	print("****Row count for partition match. Original row count =" + str(part_row_count) + ", Temp row count =" + str(part_temp_row_count))
					#delete the original partition location
					subprocess.call(["hadoop", "fs", "-rm", "-R", current_dir+"/*"])
						
					#copy from temp to org location
					subprocess.call(["hdfs", "dfs", "-mv", DB_DIR + temp_table + "/*", current_dir])
					
					part_processed_count = part_processed_count+1;
        	                        print ("Total partitions processed : " + str(part_processed_count))

	                	        spark.sql("DROP TABLE IF EXISTS "+HIVE_SCHEMA + "." + HIVE_TABLE + temp_table);
			else :
				print ("No data in partition")

##########################################
### -*- Merge flat/flat-bucketed files -*-
##########################################

def merge_flat_table(isBucketed):
	hive_df = spark.table(HIVE_SCHEMA+"."+HIVE_TABLE)
	org_row_count = hive_df.count()

	if org_row_count > 0 :
	        hive_df.write.format("parquet").mode("overwrite").saveAsTable(HIVE_SCHEMA + "." + HIVE_TABLE + temp_table)
        	hive_df_temp = spark.table(HIVE_SCHEMA + "." + HIVE_TABLE + temp_table)
        	temp_row_count = hive_df_temp.count()

        	if org_row_count != temp_row_count :
        	        print("****Row count did not match. Original row count =" + str(org_row_count) + ", Temp row count =" + str(temp_row_count))
        	else :
			print("****Row count match. Original row count =" + str(org_row_count) + ", Temp row count =" + str(temp_row_count))
			if isBucketed == False :
	                	hdir_size = commands.getoutput("hdfs dfs -du -s " + DB_DIR + temp_table + " |awk \'{print $1}\'")
	                	num_files = math.ceil(int(hdir_size)/int(FILE_SIZE));
				hive_df_temp.repartition(int(num_files)).write.format("parquet").mode("overwrite").saveAsTable(HIVE_SCHEMA + "." + HIVE_TABLE )
			else :
	                	hive_df_temp.repartition(int(NUM_BUCKETS),BUCKET_COLS).write.format("parquet").mode("overwrite").saveAsTable(HIVE_SCHEMA + "." + HIVE_TABLE )
        		#########################################################################
			### -*- refresh catalog cache for loading fresh partition and values -*-
			########################################################################

			spark.catalog.refreshTable(HIVE_SCHEMA + "." + HIVE_TABLE )

			hive_df_final = spark.table(HIVE_SCHEMA + "." + HIVE_TABLE )
			final_row_count = hive_df_final.count()

			########################################################################################################
	                ### -*- Compare row count of original and final table drop and stop processing if it does not match -*-
	                ########################################################################################################

	                if org_row_count != final_row_count :
        	                print("****Row count for final and org table did not match. Org row count =" + str(org_row_count) + ", Final table row count =" + str(final_row_count))
        	        else :
        	                print("****Row count for final and org table match. Org row count =" + str(org_row_count) + ", Final table row count =" + str(final_row_count)) 
		
		spark.sql("DROP TABLE IF EXISTS "+HIVE_SCHEMA + "." + HIVE_TABLE + temp_table);
		
	else :
		print ("No data in table")

def merge_flat_table1(isBucketed):
        hive_df = spark.table(HIVE_SCHEMA+"."+HIVE_TABLE)
        org_row_count = hive_df.count()

        if org_row_count > 0 :
                if isBucketed == False :
 	               hdir_size = commands.getoutput("hdfs dfs -du -s " + DB_DIR  + " |awk \'{print $1}\'")
                       num_files = math.ceil(int(hdir_size)/int(FILE_SIZE));
                       hive_df.write.format("parquet").mode("overwrite").saveAsTable(HIVE_SCHEMA + "." + HIVE_TABLE + temp_table)
                else :
                       hive_df.repartition(int(NUM_BUCKETS),BUCKET_COLS).write.format("parquet").mode("overwrite").saveAsTable(HIVE_SCHEMA + "." + HIVE_TABLE+ temp_table )

                hive_df_temp = spark.table(HIVE_SCHEMA + "." + HIVE_TABLE + temp_table)
                temp_row_count = hive_df_temp.count()

                if org_row_count != temp_row_count :
                        print("****Row count did not match. Original row count =" + str(org_row_count) + ", Temp row count =" + str(temp_row_count))
                else :
                        print("****Row count match. Original row count =" + str(org_row_count) + ", Temp row count =" + str(temp_row_count))
                        
			#delete the original partition location
                        subprocess.call(["hadoop", "fs", "-rm", "-R", DB_DIR+"/*"])

                        #copy from temp to org location
                        subprocess.call(["hdfs", "dfs", "-mv", DB_DIR + temp_table + "/*", DB_DIR])			
			
			#########################################################################
                        ### -*- refresh catalog cache for loading fresh partition and values -*-
                        ########################################################################

                        spark.catalog.refreshTable(HIVE_SCHEMA + "." + HIVE_TABLE )

                        hive_df_final = spark.table(HIVE_SCHEMA + "." + HIVE_TABLE )
                        final_row_count = hive_df_final.count()

                        ########################################################################################################
                        ### -*- Compare row count of original and final table drop and stop processing if it does not match -*-
                        ########################################################################################################

                        if org_row_count != final_row_count :
                                print("****Row count for final and org table did not match. Org row count =" + str(org_row_count) + ", Final table row count =" + str(final_row_count))
                        else :
                                print("****Row count for final and org table match. Org row count =" + str(org_row_count) + ", Final table row count =" + str(final_row_count))

                spark.sql("DROP TABLE IF EXISTS "+HIVE_SCHEMA + "." + HIVE_TABLE + temp_table);

        else :
                print ("No data in table")


#########################################################
### -*- Check arg values and callfunction accordingly -*-
#########################################################

if PARTITION_COLS!="" and PARTITION_COLS!="null" and BUCKET_COLS!="" and BUCKET_COLS!="null" :
	print "****Overwriting partition-bucketed table with partition cols:" + PARTITION_COLS +" ,bucketing cols:" + BUCKET_COLS + " ,num_buckets:" + NUM_BUCKETS
	merge_partitioned_table(True)
elif PARTITION_COLS!="" and PARTITION_COLS!="null" and (BUCKET_COLS=="" or BUCKET_COLS=="null") :
	print "****Overwriting partitioned table with partition cols:" + PARTITION_COLS
	merge_partitioned_table(False)    
elif BUCKET_COLS!="" and BUCKET_COLS!="null" and (PARTITION_COLS=="" or PARTITION_COLS=="null") :
	print "****Overwriting bucketed table with bucketing cols:" + BUCKET_COLS + " ,num_buckets:" + NUM_BUCKETS
	merge_flat_table(True)
else :
	print "****Overwriting flat table"
    	merge_flat_table(False)


print "Overwrite Successful"
spark.stop()
exit()
