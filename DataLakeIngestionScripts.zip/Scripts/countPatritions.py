from __future__ import division
from pyspark.sql import SparkSession
import sys
import pyspark
from pyspark.conf import SparkConf
from pyspark import SparkContext
from pyspark.sql.functions import *
from pyspark.sql import HiveContext
import datetime
import commands
import math
import subprocess

HIVE_SCHEMA=sys.argv[1]
HIVE_TABLE=sys.argv[2]

sconf = pyspark.SparkConf()

sconf.set("hive.metastore.uris", "thrift://poldcdhmn003.dev.intranet:9083")
sconf.set("spark.shuffle.service.enabled", "true")
sconf.set("yarn.nodemanager.pmem-check-enabled", "false")
sconf.set("yarn.nodemanager.vmem-check-enabled", "false")
sconf.set("spark.dynamicAllocation.enabled", "true")
sconf.set("spark.dynamicAllocation.minExecutors", "1")
sconf.set("spark.dynamicAllocation.maxExecutors", "500")
sconf.set("spark.dynamicAllocation.initialExecutors", "10")
sconf.set("spark.yarn.executor.memoryOverhead", "10G")
sconf.set("spark.sql.warehouse.dir", "/user/hive/warehouse")
sconf.set("hive.metastore.execute.setugi", "true")
sconf.set("hive.exec.dynamic.partition", "true")
sconf.set("hive.exec.dynamic.partition.mode", "nonstrict")
sconf.set("hive.merge.mapfiles", "true")
sconf.set("hive.merge.mapredfiles", "true")
sconf.set("hive.merge.sparkfiles", "true")
sconf.set("spark.sql.parquet.compression.codec", "snappy")
sconf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
sconf.set("spark.sql.inMemoryColumnarStorage.compressed", "true")
sconf.set("spark.hadoop.parquet.enable.summary-metadata", "false")
sconf.set("spark.hadoop.mapreduce.fileoutputcommitter.marksuccessfuljobs", "false")
sconf.set("spark.network.timeout","60s")

spark = SparkSession.builder.appName('mergeSmallFiles').config(conf=sconf).getOrCreate()

all_partitions = spark.sql("SHOW PARTITIONS "+ HIVE_SCHEMA+"."+HIVE_TABLE)
part_count=0;

for partition in all_partitions.collect():
	part_count = part_count+1 ;

print ("***************************** Total partitions :" + str(part_count))

spark.stop()
exit()

