#*********************************************************************************************
# Program Name           : UC9
# Shell Objective        : This spark code is to INGEST fixed width flat file to HDFS and then to HIVE/Impala.
# Revision History:  Please do not stray from the example provided.
#
# Modfied    User     
# Date                Description
# MM/DD/YYYY         
# ---------- -------- ------------------------------------------------
# 04/12/2019 lalit joshi   Initial version
#=====================================================================================
#*********************************************************************************************
from __future__ import division

import sys
import pyspark
from pyspark import SparkContext
from pyspark.sql.functions import *
from pyspark.sql import HiveContext
import datetime
import commands
import math


##########################################################
#Importing the programe defined parameter and function file
##########################################################

from uc9_parm import *
from uc9_function import *


sqlContext = HiveContext(pyspark.SparkContext())

HIVE_SCHEMA=sys.argv[1]
HIVE_TABLE=sys.argv[2]
FILE_NAME=sys.argv[3]
file_extn=sys.argv[4]


print "FILE_NAME-->"+str(FILE_NAME)
print "File extn-->"+str(file_extn)
print "UC9 Started for -->"+str(HIVE_SCHEMA)+"."+str(HIVE_TABLE)+ " at "+str((datetime.datetime.now()))

##########################################################
#Reading all the raw files to a dataframe
##########################################################

file_DF = sqlContext.read.text(input_path + HIVE_SCHEMA + "/" + FILE_NAME +"*"+ file_extn)

hdir_size = commands.getoutput("hdfs dfs -du -s " + input_path + HIVE_SCHEMA + "/" + FILE_NAME +"*"+ file_extn + "|awk \'{total += $1 }; END { print total}\'")
num_files = math.ceil(int(hdir_size)/2000000000);

print "Size of all the files to be ingested-->"+str(hdir_size)
print "num_files-->"+str(num_files)


x=file_DF.count()
print "File count-->"+str(x)


##########################################################
#Reading Meta table to get the field and other info
##########################################################

query = "(select PRNT_PATH_DIR_NM,FLD_NM,MTDT_DA_TYP,NO_DA_TYP_PRECN_QTY,NO_DA_TYP_SCL_QTY,STRTG_POS_NO,FLD_LGTH_NO from DWBIREF.DTRB_FILE_SYS_FILE_FLD  where PRNT_PATH_DIR_NM like '%"+HIVE_TABLE+"%' order by STRTG_POS_NO) META_TABLE"
Meta_DF = sqlContext.read .format("jdbc").option("url", URL).option("dbtable", query).option("user", META_USER).option("password", META_PWD).option("driver", "oracle.jdbc.OracleDriver").load()

Meta_DF.show()
print "Meta_DF columns-->"+str(Meta_DF.count())


##############################################################
#Type casting based on the predefined rules ( see uc9_function)
##############################################################

final_DF=assign_n_cast(Meta_DF,file_DF)


##################################################################
#scrub the data based on the predefined rules ( see uc9_function)
##################################################################

final_DF=scrub_dataframe(Meta_DF,final_DF)

if HIVE_SCHEMA == 'asl_rjf':
	final_DF= final_DF.where("line_type='D'")

cnt=final_DF.count()
print "Final_df after all scrubbing-->"+str(cnt)

######################################################################
#Add File_name to the dataframe
######################################################################
regex_str = "([^\/]+[^\/]+)$"

final_DF=final_DF.withColumn("meta_src_file_nm", input_file_name())
final_DF1=final_DF.withColumn("meta_src_file_nm",regexp_extract("meta_src_file_nm",regex_str,1))


######################################################################
#Data Quality check OR create HIVE table based on HIVE table existnace
######################################################################

Table_exist= HIVE_TABLE in sqlContext.tableNames(HIVE_SCHEMA)
#Table_exist='False'
print "Table Exist-->"+str(Table_exist)

if Table_exist == True :
	 TEMP_TABLE=HIVE_TABLE+"_TEMP_DF"
	 final_DF.registerTempTable(TEMP_TABLE)
	 Hive_query="Hive_DF=sqlContext.sql(\"SELECT t.* from  "+ TEMP_TABLE +" t1, "+HIVE_SCHEMA+"."+HIVE_TABLE+" t where t1.meta_src_file_nm=t.meta_src_file_nm and meta_load_dt>= date_sub(current_date,"+quality_check_days+")\")"
	 #Hive_query="Hive_DF=sqlContext.sql(\"SELECT t.* from final_df_temp_table t1, "+HIVE_SCHEMA+"."+HIVE_TABLE+" t where t1.meta_src_file_nm=t.meta_src_file_nm and meta_load_dt>= date_sub(current_date,"+quality_check_days+")\")"
	 exec(Hive_query)
	 print "length of HIVE_DF-->"+str(len(Hive_DF.columns))
         h_c=Hive_DF.count()
	 print "Hive_df count-->"+str(h_c)
	 if h_c!=0:
	 	Hive_DF=Hive_DF.drop('dt').drop('meta_load_dt').select("*")
	        final_DF=final_DF.subtract(Hive_DF)
	 else:
		print "Nothing to compare with HIVE table "+HIVE_SCHEMA+"."+HIVE_TABLE

else :
	 create_hive_table(Meta_DF,HIVE_SCHEMA,HIVE_TABLE,db_dir,sqlContext)
	 #print "Ignoring HIVE comapre"

x=final_DF.count()
print "Final_df after subtract count-->"+str(x)


######################################################################
#Add partition column and meta_load_dt to the dataframe
######################################################################

final_DF=final_DF.withColumn("meta_load_dt", lit(current_timestamp()).cast("timestamp"))
final_DF=final_DF.withColumn("dt",from_unixtime(unix_timestamp(current_date(),'dd/MM/yy HH:mm'),'yyyyMMdd'))

######################################################################
#Append the record to the PARTITION table in HIVE and drop the temp HDFS location
######################################################################

sqlContext.setConf("hive.exec.dynamic.partition", "true")
sqlContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict")
sqlContext.setConf("mapred.output.compression.codec", "org.apache.hadoop.io.compress.SnappyCodec")

print "Write to table started-->"+str((datetime.datetime.now()))
final_DF.repartition(int(num_files)).write.format("parquet").mode("append").partitionBy("dt").saveAsTable(HIVE_SCHEMA+"."+HIVE_TABLE)
print "Writing to HIVE table completed -->"+str((datetime.datetime.now()))

######################################################################
#Compute STAT for the HIVE table
######################################################################

compute_str="sqlContext.sql(\"analyze table "+HIVE_SCHEMA+"."+HIVE_TABLE+" compute statistics for columns\")"
exec(compute_str)

print "UC9 Completed for -->"+str(HIVE_SCHEMA)+"."+str(HIVE_TABLE)+" at "+str((datetime.datetime.now()))

