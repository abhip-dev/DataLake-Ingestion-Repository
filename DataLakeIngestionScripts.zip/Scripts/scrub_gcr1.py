#!/opt/tools/python/bin/python
import json
import sys
import logging
from argparse import ArgumentParser
#from datetime import datetime
import time;
import datetime
import os


def main():
        #Get script name
        script_name = "scrub_clarifygcr.py"

        #Logging
#        log_dir = '/data/CTL/ingest/lvcht/clarifygcr/log/'
        log_dir = '/home/cdlapp/satya'
#        timestamp = datetime.utcnow().strftime('%Y.%m.%d.%H.%M.%S')
        timestamp = time.time()
#        log_name = script_name+'_{}.log'.format(timestamp)
        log_name = script_name+'_'+str(timestamp)+'.log'
        log_file = os.path.join(log_dir, log_name)
        print(log_file)
        logging.basicConfig(filename=log_file,level=logging.DEBUG)
#        print(log_file)

        #Path and files
#        stage_json_dir = '/data/CTL/encrypt/db/ingest/raw/flvlt/clarifygcr'
#        stage_csv_dir = '/data/CTL/encrypt/db/ingest/raw/flvlt/clarifygcr_csv'
        stage_json_dir = '/home/cdlapp/satya/json_files'
        stage_csv_dir = '/home/cdlapp/satya/csv_files'

        #Clear the CSV Dir
        #os.system('rm -rf %s/*' % '/data/CTL/ingest/lvcht/staging/CSV/AgentActivity_src')
        print("Running the script -1")
        for sub_dir_name in os.listdir(stage_json_dir):
             for infile_name in os.listdir(os.path.join(stage_json_dir,sub_dir_name)):
                print("Running the script - 2")
        # Parse Arguments
                input_file = os.path.join(stage_json_dir,sub_dir_name,infile_name)
                logging.info("JSON file being processed: "+input_file)

                #create output file to write the csv data
                #filepart = infile_name[-13:-5]
                outfile_name = "FlumeData"+str(timestamp)+".csv"
                output_file =  os.path.join(stage_csv_dir,outfile_name)
                logging.info("csv out file: "+output_file)
                outFile = open(output_file, "w")
                with open(input_file,"r") as json_file:
                    for line in json_file:
                        items = json.loads(line)
                        print("Running the script -3")
                        print(items)
                        AD_LMS_STATUS  =  items.get('AD.LMS_STATUS')
                        AD_S_ADDRESS  =  items.get('AD.S_ADDRESS')
                        AD_S_CITY  =  items.get('AD.S_CITY')
                        AD_S_STATE  =  items.get('AD.S_STATE')
                        AD_X_BLDG_LAT  =  items.get('AD.X_BLDG_LAT')
                        AD_X_BLDG_LAT_F  =  items.get('AD.X_BLDG_LAT_F')
                        AD_X_BLDG_LONG  =  items.get('AD.X_BLDG_LONG')
                        AD_X_BLDG_LONG_F  =  items.get('AD.X_BLDG_LONG_F')
                        AD_X_CLLI_CD  =  items.get('AD.X_CLLI_CD')
                        AD_ZIPCODE  =  items.get('AD.ZIPCODE')
                        AO_CREATED_BY  =  items.get('AO.CREATED_BY')
                        AO_CREATED_DT  =  items.get('AO.CREATED_DT')
                        AO_DEACTIVATED_BY  =  items.get('AO.DEACTIVATED_BY')
                        AO_DEACTIVATED_DT  =  items.get('AO.DEACTIVATED_DT')
                        AO_LEGACY_NETWORK  =  items.get('AO.LEGACY_NETWORK')
                        AO_MODIFIED_BY  =  items.get('AO.MODIFIED_BY')
                        AO_NAME  =  items.get('AO.NAME')
                        AO_OUTAGE_DURATION_I  =  items.get('AO.OUTAGE_DURATION_I')
                        AO_PROTECTED_OUTAGE_DUR_I  =  items.get('AO.PROTECTED_OUTAGE_DUR_I')
                        AO_STATUS  =  items.get('AO.STATUS')
                        AO_TYPE  =  items.get('AO.TYPE')
                        AO_TYPE_OF_IMPACT  =  items.get('AO.TYPE_OF_IMPACT')
                        C_ID_NUMBER  =  items.get('C.ID_NUMBER')
                        CM_CLASSIFICATION  =  items.get('CM.CLASSIFICATION')
                        CM_CREATED_BY  =  items.get('CM.CREATED_BY')
                        CM_CREATED_DT  =  items.get('CM.CREATED_DT')
                        CM_CUSTOMER_OUTAGE_B  =  items.get('CM.CUSTOMER_OUTAGE_B')
                        CM_IS_FIELD_SUPPORT_REQURIED_B  =  items.get('CM.IS_FIELD_SUPPORT_REQURIED_B')
                        CM_MAX_DUR_MINS_HR_I  =  items.get('CM.MAX_DUR_MINS_HR_I')
                        CM_MODIFIED_BY  =  items.get('CM.MODIFIED_BY')
                        CM_MODIFIED_DT  =  items.get('CM.MODIFIED_DT')
                        CM_MULTI_NIGHT_ALLOWED_B  =  items.get('CM.MULTI_NIGHT_ALLOWED_B')
                        CM_NAME  =  items.get('CM.NAME')
                        CM_NOTES  =  items.get('CM.NOTES')
                        #PRINT(CM_NOTES)
                        CM_STATUS  =  items.get('CM.STATUS')
                        CM_SUMMARY  =  items.get('CM.SUMMARY')
                        CM_THIRD_PARTY  =  items.get('CM.THIRD_PARTY')
                        CM_TYPE_LEVEL_1  =  items.get('CM.TYPE_LEVEL_1')
                        CM_TYPE_LEVEL_2  =  items.get('CM.TYPE_LEVEL_2')
                        CM_TYPE_LEVEL_3  =  items.get('CM.TYPE_LEVEL_3')
                        CM_TYPE_LEVEL_4  =  items.get('CM.TYPE_LEVEL_4')
                        CM_TYPE_LEVEL_5  =  items.get('CM.TYPE_LEVEL_5')
                        CM_VERSION_I  =  items.get('CM.VERSION_I')
                        C_OBJID_I  =  items.get('C.OBJID_I')
                        COUNTRY_NAME  =  items.get('COUNTRY.NAME')
                        C_OWNER  =  items.get('C.OWNER')
                        C_QUEUE  =  items.get('C.QUEUE')
                        C_TITLE  =  items.get('C.TITLE')
                        C_WIPBIN  =  items.get('C.WIPBIN')
                        C_X_CASE_TYPE_LEVEL1  =  items.get('C.X_CASE_TYPE_LEVEL1')
                        C_X_CASE_TYPE_LEVEL2  =  items.get('C.X_CASE_TYPE_LEVEL2')
                        C_X_CASE_TYPE_LEVEL3  =  items.get('C.X_CASE_TYPE_LEVEL3')
                        C_X_CASE_TYPE_LEVEL4  =  items.get('C.X_CASE_TYPE_LEVEL4')
                        C_X_CASE_TYPE_LEVEL5  =  items.get('C.X_CASE_TYPE_LEVEL5')
                        GCR_CHANGEMODEL_I  =  items.get('GCR.CHANGEMODEL_I')
                        GCR_CLASSIFICATION  =  items.get('GCR.CLASSIFICATION')
                        GCR_COMBINE_RESCHD_INIT_EML_B  =  items.get('GCR.COMBINE_RESCHD_INIT_EML_B')
                        GCR_CREATED_BY  =  items.get('GCR.CREATED_BY')
                        GCR_CREATED_DT  =  items.get('GCR.CREATED_DT')
                        GCR_DESCRIPTION  =  items.get('GCR.DESCRIPTION')
                        GCR_DESIGNATION  =  items.get('GCR.DESIGNATION')
                        GCR_EID   =  items.get('GCR.EID ')
                        GCR_END_DT  =  items.get('GCR.END_DT')
                        GCR_IMPL_GROUP  =  items.get('GCR.IMPL_GROUP')
                        GCR_INIT_NOTIF_SENT_B   =  items.get('GCR.INIT_NOTIF_SENT_B ')
                        GCR_IS_BPMS_INTEGRATION_B  =  items.get('GCR.IS_BPMS_INTEGRATION_B')
                        GCR_IS_FIELD_SUP_REQ_B  =  items.get('GCR.IS_FIELD_SUP_REQ_B')
                        GCR_MODIFIED_BY  =  items.get('GCR.MODIFIED_BY')
                        GCR_MODIFIED_DT  =  items.get('GCR.MODIFIED_DT')
                        GCR_MULTI_NIGHT_B  =  items.get('GCR.MULTI_NIGHT_B')
                        GCR_NOCDEMAND_B  =  items.get('GCR.NOCDEMAND_B')
                        GCR_NOTIFICATION_DESIGNATION  =  items.get('GCR.NOTIFICATION_DESIGNATION')
                        GCR_NOTIFICATIONS_REVIEWED_B  =  items.get('GCR.NOTIFICATIONS_REVIEWED_B')
                        GCR_NOTIFICATIONS_REVIEWED_BY  =  items.get('GCR.NOTIFICATIONS_REVIEWED_BY')
                        GCR_NOTIFICATIONS_REVIEWED_DT  =  items.get('GCR.NOTIFICATIONS_REVIEWED_DT')
                        GCR_NOTIFICATION_TEXT  =  items.get('GCR.NOTIFICATION_TEXT')
                        GCR_PROGRAM_CODE  =  items.get('GCR.PROGRAM_CODE')
                        GCR_REGION  =  items.get('GCR.REGION')
                        GCR_RELATED_ORDER_ID  =  items.get('GCR.RELATED_ORDER_ID')
                        GCR_REQUESTOR_DEPARTMENT_ID  =  items.get('GCR.REQUESTOR_DEPARTMENT_ID')
                        GCR_REQUESTOR_GROUP  =  items.get('GCR.REQUESTOR_GROUP')
                        GCR_REQUESTOR_LOGIN  =  items.get('GCR.REQUESTOR_LOGIN')
                        GCR_REQUESTOR_PHONE  =  items.get('GCR.REQUESTOR_PHONE')
                        GCR_SPECIAL_PROCESSING_TYPES  =  items.get('GCR.SPECIAL_PROCESSING_TYPES')
                        GCR_START_DT  =  items.get('GCR.START_DT')
                        GCR_STATUS  =  items.get('GCR.STATUS')
                        GCR_VENDOR_MAINTENANCE_ID  =  items.get('GCR.VENDOR_MAINTENANCE_ID')
                        GCR_VENDOR_NAME  =  items.get('GCR.VENDOR_NAME')
                        GCR_VENDOR_REQ_RECEIVED_DT  =  items.get('GCR.VENDOR_REQ_RECEIVED_DT')
                        IM_AEND_CLLI  =  items.get('IM.AEND_CLLI')
                        IM_ALTERNATE_SID  =  items.get('IM.ALTERNATE_SID')
                        IM_BAN  =  items.get('IM.BAN')
                        IM_BANDWIDTH  =  items.get('IM.BANDWIDTH')
                        IM_BUSORG_ID  =  items.get('IM.BUSORG_ID')
                        IM_BUSORG_NAME  =  items.get('IM.BUSORG_NAME')
                        IM_CLASSIFICATION  =  items.get('IM.CLASSIFICATION')
                        IM_CREATED_BY  =  items.get('IM.CREATED_BY')
                        IM_CREATED_DT  =  items.get('IM.CREATED_DT')
                        IM_HOLD_NOTIFICATION_B  =  items.get('IM.HOLD_NOTIFICATION_B')
                        IM_IMPACT_TYPE  =  items.get('IM.IMPACT_TYPE')
                        IM_INITIAL_EMAIL_SENT_B  =  items.get('IM.INITIAL_EMAIL_SENT_B')
                        IM_IS_PROTECTED_B  =  items.get('IM.IS_PROTECTED_B')
                        IM_MODIFIED_BY  =  items.get('IM.MODIFIED_BY')
                        IM_MODIFIED_DT  =  items.get('IM.MODIFIED_DT')
                        IM_NOTIF_APPROVAL_DT  =  items.get('IM.NOTIF_APPROVAL_DT')
                        IM_NOTIF_APPROVED_B  =  items.get('IM.NOTIF_APPROVED_B')
                        IM_NOTIF_APPROVED_BY  =  items.get('IM.NOTIF_APPROVED_BY')
                        IM_NOTIFICATION_APPROVED  =  items.get('IM.NOTIFICATION_APPROVED')
                        IM_NOTIFICATION_NAME  =  items.get('IM.NOTIFICATION_NAME')
                        IM_ORDER_NUMBER  =  items.get('IM.ORDER_NUMBER')
                        IM_PRODUCT  =  items.get('IM.PRODUCT')
                        IM_PRODUCT_FAMILY  =  items.get('IM.PRODUCT_FAMILY')
                        IM_SID  =  items.get('IM.SID')
                        IM_STATUS  =  items.get('IM.STATUS')
                        IM_TSP_CODE  =  items.get('IM.TSP_CODE')
                        IM_ZEND_CLLI  =  items.get('IM.ZEND_CLLI')
                        OW_ALTERNATE_NIGHT_B  =  items.get('OW.ALTERNATE_NIGHT_B')
                        OW_CLOSURE_CD_LVL1  =  items.get('OW.CLOSURE_CD_LVL1')
                        OW_CLOSURE_CD_LVL2  =  items.get('OW.CLOSURE_CD_LVL2')
                        OW_CLOSURE_CD_LVL3  =  items.get('OW.CLOSURE_CD_LVL3')
                        OW_CLOSURE_CD_LVL4  =  items.get('OW.CLOSURE_CD_LVL4')
                        OW_CLOSURE_CD_LVL5  =  items.get('OW.CLOSURE_CD_LVL5')
                        OW_CREATED_BY  =  items.get('OW.CREATED_BY')
                        OW_CREATED_DT  =  items.get('OW.CREATED_DT')
                        OW_END_DT  =  items.get('OW.END_DT')
                        OW_IS_UCI_B  =  items.get('OW.IS_UCI_B')
                        OW_MODIFIED_BY  =  items.get('OW.MODIFIED_BY')
                        OW_MODIFIED_DT  =  items.get('OW.MODIFIED_DT')
                        OW_NAME  =  items.get('OW.NAME')
                        OW_REQUESTED_START_DT  =  items.get('OW.REQUESTED_START_DT')
                        OW_RESOLUTION_GRADE  =  items.get('OW.RESOLUTION_GRADE')
                        OW_START_DT  =  items.get('OW.START_DT')
                        OW_STATE  =  items.get('OW.STATE')
                        OW_UCI_DURATION_I  =  items.get('OW.UCI_DURATION_I')
                        SHI_SID  =  items.get('SHI.SID')
                        S_MAINT_QUEUE_NAME  =  items.get('S.MAINT_QUEUE_NAME')
                        S_SITE_ID  =  items.get('S.SITE_ID')
                        S_SITE_NAME  =  items.get('S.SITE_NAME')
                        S_X_SITE_SUBUSAGE  =  items.get('S.X_SITE_SUBUSAGE')
                        S_X_SITE_USAGE   =  items.get('S.X_SITE_USAGE')
                        outfile.write( str(AD_LMS_STATUS)+' |~|'+str(AD_S_ADDRESS)+' |~|'+str(AD_S_CITY)+' |~|'+str(AD_S_STATE)+' |~|'+str(AD_X_BLDG_LAT)+' |~|'+str(AD_X_BLDG_LAT_F)+' |~|'+str(AD_X_BLDG_LONG)+' |~|'+str(AD_X_BLDG_LONG_F)+' |~|'+str(AD_X_CLLI_CD)+' |~|'+str(AD_ZIPCODE)+' |~|'+str(AO_CREATED_BY)+' |~|'+str(AO_CREATED_DT)+' |~|'+str(AO_DEACTIVATED_BY)+' |~|'+str(AO_DEACTIVATED_DT)+' |~|'+str(AO_LEGACY_NETWORK)+' |~|'+str(AO_MODIFIED_BY)+' |~|'+str(AO_NAME)+' |~|'+str(AO_OUTAGE_DURATION_I)+' |~|'+str(AO_PROTECTED_OUTAGE_DUR_I)+' |~|'+str(AO_STATUS)+' |~|'+str(AO_TYPE)+' |~|'+str(AO_TYPE_OF_IMPACT)+' |~|'+str(C_ID_NUMBER)+' |~|'+str(CM_CLASSIFICATION)+' |~|'+str(CM_CREATED_BY)+' |~|'+str(CM_CREATED_DT)+' |~|'+str(CM_CUSTOMER_OUTAGE_B)+' |~|'+str(CM_IS_FIELD_SUPPORT_REQURIED_B)+' |~|'+str(CM_MAX_DUR_MINS_HR_I)+' |~|'+str(CM_MODIFIED_BY)+' |~|'+str(CM_MODIFIED_DT)+' |~|'+str(CM_MULTI_NIGHT_ALLOWED_B)+' |~|'+str(CM_NAME)+' |~|'+str(CM_NOTES)+' |~|'+str(CM_STATUS)+' |~|'+str(CM_SUMMARY)+' |~|'+str(CM_THIRD_PARTY)+' |~|'+str(CM_TYPE_LEVEL_1)+' |~|'+str(CM_TYPE_LEVEL_2)+' |~|'+str(CM_TYPE_LEVEL_3)+' |~|'+str(CM_TYPE_LEVEL_4)+' |~|'+str(CM_TYPE_LEVEL_5)+' |~|'+str(CM_VERSION_I)+' |~|'+str(C_OBJID_I)+' |~|'+str(COUNTRY_NAME)+' |~|'+str(C_OWNER)+' |~|'+str(C_QUEUE)+' |~|'+str(C_TITLE)+' |~|'+str(C_WIPBIN)+' |~|'+str(C_X_CASE_TYPE_LEVEL1)+' |~|'+str(C_X_CASE_TYPE_LEVEL2)+' |~|'+str(C_X_CASE_TYPE_LEVEL3)+' |~|'+str(C_X_CASE_TYPE_LEVEL4)+' |~|'+str(C_X_CASE_TYPE_LEVEL5)+' |~|'+str(GCR_CHANGEMODEL_I)+' |~|'+str(GCR_CLASSIFICATION)+' |~|'+str(GCR_COMBINE_RESCHD_INIT_EML_B)+' |~|'+str(GCR_CREATED_BY)+' |~|'+str(GCR_CREATED_DT)+' |~|'+str(GCR_DESCRIPTION)+' |~|'+str(GCR_DESIGNATION)+' |~|'+str(GCR_EID)+' |~|'+str(GCR_END_DT)+' |~|'+str(GCR_IMPL_GROUP)+' |~|'+str(GCR_INIT_NOTIF_SENT_B)+' |~|'+str(GCR_IS_BPMS_INTEGRATION_B)+' |~|'+str(GCR_IS_FIELD_SUP_REQ_B)+' |~|'+str(GCR_MODIFIED_BY)+' |~|'+str(GCR_MODIFIED_DT)+' |~|'+str(GCR_MULTI_NIGHT_B)+' |~|'+str(GCR_NOCDEMAND_B)+' |~|'+str(GCR_NOTIFICATION_DESIGNATION)+' |~|'+str(GCR_NOTIFICATIONS_REVIEWED_B)+' |~|'+str(GCR_NOTIFICATIONS_REVIEWED_BY)+' |~|'+str(GCR_NOTIFICATIONS_REVIEWED_DT)+' |~|'+str(GCR_NOTIFICATION_TEXT)+' |~|'+str(GCR_PROGRAM_CODE)+' |~|'+str(GCR_REGION)+' |~|'+str(GCR_RELATED_ORDER_ID)+' |~|'+str(GCR_REQUESTOR_DEPARTMENT_ID)+' |~|'+str(GCR_REQUESTOR_GROUP)+' |~|'+str(GCR_REQUESTOR_LOGIN)+' |~|'+str(GCR_REQUESTOR_PHONE)+' |~|'+str(GCR_SPECIAL_PROCESSING_TYPES)+' |~|'+str(GCR_START_DT)+' |~|'+str(GCR_STATUS)+' |~|'+str(GCR_VENDOR_MAINTENANCE_ID)+' |~|'+str(GCR_VENDOR_NAME)+' |~|'+str(GCR_VENDOR_REQ_RECEIVED_DT)+' |~|'+str(IM_AEND_CLLI)+' |~|'+str(IM_ALTERNATE_SID)+' |~|'+str(IM_BAN)+' |~|'+str(IM_BANDWIDTH)+' |~|'+str(IM_BUSORG_ID)+' |~|'+str(IM_BUSORG_NAME)+' |~|'+str(IM_CLASSIFICATION)+' |~|'+str(IM_CREATED_BY)+' |~|'+str(IM_CREATED_DT)+' |~|'+str(IM_HOLD_NOTIFICATION_B)+' |~|'+str(IM_IMPACT_TYPE)+' |~|'+str(IM_INITIAL_EMAIL_SENT_B)+' |~|'+str(IM_IS_PROTECTED_B)+' |~|'+str(IM_MODIFIED_BY)+' |~|'+str(IM_MODIFIED_DT)+' |~|'+str(IM_NOTIF_APPROVAL_DT)+' |~|'+str(IM_NOTIF_APPROVED_B)+' |~|'+str(IM_NOTIF_APPROVED_BY)+' |~|'+str(IM_NOTIFICATION_APPROVED)+' |~|'+str(IM_NOTIFICATION_NAME)+' |~|'+str(IM_ORDER_NUMBER)+' |~|'+str(IM_PRODUCT)+' |~|'+str(IM_PRODUCT_FAMILY)+' |~|'+str(IM_SID)+' |~|'+str(IM_STATUS)+' |~|'+str(IM_TSP_CODE)+' |~|'+str(IM_ZEND_CLLI)+' |~|'+str(OW_ALTERNATE_NIGHT_B)+' |~|'+str(OW_CLOSURE_CD_LVL1)+' |~|'+str(OW_CLOSURE_CD_LVL2)+' |~|'+str(OW_CLOSURE_CD_LVL3)+' |~|'+str(OW_CLOSURE_CD_LVL4)+' |~|'+str(OW_CLOSURE_CD_LVL5)+' |~|'+str(OW_CREATED_BY)+' |~|'+str(OW_CREATED_DT)+' |~|'+str(OW_END_DT)+' |~|'+str(OW_IS_UCI_B)+' |~|'+str(OW_MODIFIED_BY)+' |~|'+str(OW_MODIFIED_DT)+' |~|'+str(OW_NAME)+' |~|'+str(OW_REQUESTED_START_DT)+' |~|'+str(OW_RESOLUTION_GRADE)+' |~|'+str(OW_START_DT)+' |~|'+str(OW_STATE)+' |~|'+str(OW_UCI_DURATION_I)+' |~|'+str(SHI_SID)+' |~|'+str(S_MAINT_QUEUE_NAME)+' |~|'+str(S_SITE_ID)+' |~|'+str(S_SITE_NAME)+' |~|'+str(S_X_SITE_SUBUSAGE)+' |~|'+str(S_X_SITE_USAGE)+' '\n' )

#dataType+', '+header+', '+prevconcurrenteng+', '+prevstate+', '+timestamp+', '+agentloginname+', '+agentusername+', '+concurrenteng+', '+state+', '+maxconcurrenteng+', '+agentemployeeid+', '+agentid+', '+type+', '+agentgroupid+', '+agentnickname+',  '+schemaVersion+', '+endtime+', '+starttime+', '+accountId+', '+filepart+'\n')
       # logging.info("Script Complete.")

# Actually run the script if calling from the command line
if __name__ == '__main__':
    exit(main())
